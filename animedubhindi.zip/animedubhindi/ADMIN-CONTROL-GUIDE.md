# AnimeDubHindi Admin Control Guide

This website is connected to one MySQL database. Anything you update from the admin panel is shown automatically on the main website.

## Main admin sections

### Dashboard
- View total anime, episodes and links.
- Search and browse all anime with pagination.
- Open edit, episode manager and public preview quickly.

### Anime Posts
- Add, edit and delete anime/movie pages.
- Upload or set cover images.
- Control title, slug, synopsis, type, language, quality, status, genres, rating, year and SEO.
- Pin anime so they appear first on Latest Releases.
- Mark anime as featured for the sidebar slider.
- Turn ZIP pack section on/off per anime.

### Episode Links
- Add episodes under each anime.
- Add Watch Online links.
- Add multiple quality download links.
- Hide/show links without deleting them.
- Add multiple ZIP packs such as EP 01-06, EP 07-12 and Full Season.

### Header Menus
- Add main menu and submenu items.
- Use relative URLs like `movies.php`, `series.php`, `search.php?q=Action`.
- Active menu items show on the website header and sidebar copy-link box.

### Site Settings
- Control brand name, logo/icon, live website URL and description.
- Control Telegram strip and popup.
- Control WhatsApp/Telegram sidebar box.
- Control featured anime slider.
- Control advertisement on/off, image, URL or custom HTML.
- Control sidebar Site Menu box, submenu visibility and copy buttons.
- Control homepage Latest Releases count and related anime count.
- Control upcoming message and footer text.
- Turn analytics on/off.

### Analytics
- See a simple summary of views, anime views, watch clicks, downloads, ZIP clicks, requests and reports.
- Filter by Today, 7 Days, 30 Days or All Time.
- Download a CSV summary.

### Requests and Reports
- Read visitor anime requests and broken link reports.
- Search and paginate long lists.

### Password
- Change the admin password after first login.

## Live website URL
Set your live URL in Admin → Site Settings → Live Website URL:

```
https://www.animedubhindi.xyz
```

This is used for the copy buttons in the sidebar Site Menu box.


## SEO Control
Use Admin → SEO Control to manage robots.txt, sitemap.xml, Google/Bing/Yandex/Naver verification, AI crawler access, IndexNow, schema, Open Graph and search submission checklist.
