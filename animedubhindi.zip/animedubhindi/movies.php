<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Movies - ' . setting('site_name', 'AnimeDubHindi');
$heading = 'Anime Movies'; $kicker = 'Movie Library';
$anime = fetch_anime_list('type = ?', ['Movie'], 120);
require __DIR__ . '/list-template.php';
