<?php
require_once __DIR__ . '/includes/functions.php';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['ok'=>false]); exit; }
if (!simple_rate_limit('analytics_track', 120, 60)) { echo json_encode(['ok'=>false]); exit; }
$event = trim($_POST['event_type'] ?? 'page_view');
track_event($event, [
  'page_url' => $_POST['page_url'] ?? ($_SERVER['HTTP_REFERER'] ?? ''),
  'referrer' => $_POST['referrer'] ?? '',
  'title' => $_POST['title'] ?? '',
  'extra' => ['query'=>$_POST['query'] ?? '']
]);
echo json_encode(['ok'=>true]);
