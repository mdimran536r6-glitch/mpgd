# AnimeDubHindi Release Notes

This package is prepared for release. It includes the public website, admin panel, database installer/repair tool, sample anime posts, episodes, watch links, download links, ZIP packs, legal pages, analytics, ad placements, and admin controls.

After installing on live hosting:
1. Run /install.php once.
2. Log in at /admin/ using the default login.
3. Change the admin password immediately.
4. Update Site Settings, Ad Control, Header Menus, Featured Anime, and Legal pages if needed.
5. Delete or rename install.php when the live site is finished.

Default admin login:
Username: admin
Password: Admin@12345
