<?php
require_once __DIR__ . '/includes/functions.php';
$link_id = (int)($_GET['link_id'] ?? 0);
$stmt = db()->prepare("SELECT l.*, e.episode_number, e.upload_date, e.id AS episode_id, a.id AS anime_id, a.title AS anime_title, a.slug, a.cover_image, a.type AS anime_type FROM episode_links l JOIN episodes e ON e.id=l.episode_id JOIN anime a ON a.id=e.anime_id WHERE l.id=? AND l.is_active=1 AND e.is_active=1 LIMIT 1");
$stmt->execute([$link_id]);
$link = $stmt->fetch();
if (!$link || ($link['link_type'] ?? '') !== 'watch') {
    http_response_code(404);
    $page_title='Watch link not found';
    require __DIR__.'/includes/header.php';
    echo '<main class="container main-wrap no-sidebar"><section class="content-card"><div class="empty-state">Watch link is not available right now.</div></section></main>';
    require __DIR__.'/includes/footer.php';
    exit;
}
$altStmt = db()->prepare("SELECT * FROM episode_links WHERE episode_id=? AND link_type='watch' AND is_active=1 ORDER BY sort_order ASC, host_name ASC, id ASC");
$altStmt->execute([(int)$link['episode_id']]);
$watchOptions = $altStmt->fetchAll();
track_event('watch_click', ['anime_id'=>(int)($link['anime_id'] ?? 0), 'episode_id'=>(int)($link['episode_id'] ?? 0), 'link_id'=>(int)$link_id, 'title'=>($link['anime_title'] ?? '').' Episode '.($link['episode_number'] ?? ''), 'page_url'=>$_SERVER['REQUEST_URI'] ?? '']);
$player = player_source_from_url($link['url'] ?? '');
$returnUrl = trim($_GET['return'] ?? '');
if ($returnUrl === '') { $returnUrl = anime_link(['slug'=>$link['slug']]) . '#episode-' . (int)$link['episode_id']; }
if (preg_match('~^https?://~i', $returnUrl)) { $returnUrl = anime_link(['slug'=>$link['slug']]); }
$isMovie = strtolower((string)($link['anime_type'] ?? '')) === 'movie';
$itemLabel = $isMovie ? 'Movie' : ('Episode ' . str_pad((string)$link['episode_number'],2,'0',STR_PAD_LEFT));
$currentLabel = trim((string)($link['host_name'] ?? ''));
if ($currentLabel === '') $currentLabel = 'Watch Online';
$page_title = 'Watch ' . $itemLabel . ' - ' . $link['anime_title'];
require __DIR__.'/includes/header.php';
?>
<main class="container main-wrap no-sidebar">
  <section class="content-card watch-player-page">
    <div class="breadcrumb"><a href="<?= e(url('index.php')) ?>">Home</a><span>›</span><a href="<?= e($returnUrl) ?>"><?= e($link['anime_title']) ?></a><span>›</span><b>Watch Online</b></div>
    <h1><?= e($link['anime_title']) ?> — <?= e($itemLabel) ?></h1>
    <p class="watch-meta">Online player<?= $currentLabel ? ' • '.e($currentLabel) : '' ?><?= !empty($link['upload_date']) ? ' • Uploaded: '.e(date('F j, Y', strtotime($link['upload_date']))) : '' ?></p>
    <?php if (count($watchOptions) > 1): ?>
      <div class="watch-options-bar" aria-label="Watch language or server options">
        <?php foreach ($watchOptions as $opt):
          $optLabel = trim((string)($opt['host_name'] ?? ''));
          if ($optLabel === '' || preg_match('/^(watch online|online player|player|server)$/i', $optLabel)) $optLabel = 'Server ' . (int)$opt['id'];
        ?>
          <a class="watch-option-pill <?= (int)$opt['id'] === $link_id ? 'active' : '' ?>" href="<?= e(url('watch.php?link_id='.(int)$opt['id'].'&return='.rawurlencode($returnUrl))) ?>"><?= e($optLabel) ?></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <div class="player-shell">
      <?php if ($player['type'] === 'video'): ?>
        <video controls preload="metadata" playsinline src="<?= e($player['src']) ?>"></video>
      <?php elseif ($player['type'] === 'iframe'): ?>
        <iframe src="<?= e($player['src']) ?>" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen loading="lazy"></iframe>
      <?php else: ?>
        <div class="empty-state">Video server unavailable. Please try another server.</div>
      <?php endif; ?>
    </div>
    <div class="watch-actions"><a class="btn" href="<?= e($link['url']) ?>" target="_blank" rel="nofollow noopener">Open source link</a><a class="btn btn-light" href="<?= e($returnUrl) ?>">Back to episodes</a></div>
  </section>
</main>
<?php require __DIR__.'/includes/footer.php'; ?>
