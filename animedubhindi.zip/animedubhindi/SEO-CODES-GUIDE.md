# SEO Codes Guide

Use **Admin → SEO Control** to add multiple codes without editing files.

## Fields
- Google Search Console verification code
- Bing Webmaster verification code
- Yandex verification code
- Naver verification code
- Google Analytics GA4 Measurement ID: `G-XXXXXXXXXX`
- Google Tag Manager ID: `GTM-XXXXXXX`
- Microsoft Clarity Project ID
- Facebook/Meta Pixel ID
- Extra Head Codes for multiple meta/script tags
- After Body Start Codes for GTM noscript/body-start code
- Before Body End Codes for chat widgets or late-loading scripts

## Submit URLs
- `https://www.animedubhindi.xyz/sitemap.xml`
- `https://www.animedubhindi.xyz/robots.txt`

Submit sitemap to Google Search Console, Bing Webmaster Tools, Yandex Webmaster, Naver Search Advisor and other webmaster tools you use.
