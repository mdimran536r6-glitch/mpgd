<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Request Anime - ' . setting('site_name', 'AnimeDubHindi');
if (!public_feature_enabled('public_request_enabled','1')) render_public_closed_page('Request Anime', setting('request_page_message','Anime requests are temporarily closed. Please check again later.'));
$msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (!empty($_POST['website'])) { http_response_code(400); exit('Invalid request.'); }
    if (!simple_rate_limit('anime_request', 5, 600)) { $msg = 'Please wait a few minutes before sending another message.'; } else {
    $stmt = db()->prepare('INSERT INTO requests (name,email,anime_title,message,created_at) VALUES (?,?,?,?,NOW())');
    $stmt->execute([clean_text((string)($_POST['name'] ?? ''),120), clean_text((string)($_POST['email'] ?? ''),160), clean_text((string)($_POST['anime_title'] ?? ''),255), clean_text((string)($_POST['message'] ?? ''),2000)]);
    $msg = 'Your request has been submitted.';
    track_event('request_submit', ['title'=>($_POST['anime_title'] ?? 'Anime request'), 'page_url'=>$_SERVER['REQUEST_URI'] ?? '']);
    }
}
require __DIR__ . '/includes/header.php';
?>
<main class="container main-wrap"><section class="content-card form-card"><h1 class="section-title">Request Anime</h1><?php if($msg): ?><div class="notice success"><?= e($msg) ?></div><?php endif; ?><form method="post"><input type="text" name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;height:1px;width:1px;opacity:0" aria-hidden="true"><?= csrf_field() ?><label>Name</label><input name="name"><label>Email</label><input name="email" type="email"><label>Anime Title</label><input name="anime_title" required><label>Message</label><textarea name="message"></textarea><br><br><button class="btn">Submit Request</button></form></section><?php require __DIR__.'/includes/sidebar.php'; ?></main><?php require __DIR__.'/includes/footer.php'; ?>
