<?php
require_once __DIR__ . '/db.php';

function e($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }

function url($path = ''): string
{
    $base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    if (str_contains($base, '/admin')) $base = preg_replace('#/admin$#', '', $base);
    return ($base ?: '') . '/' . ltrim($path, '/');
}


function site_base_url(): string
{
    $base = trim(setting('site_url', 'https://www.animedubhindi.xyz'));
    if ($base === '') $base = 'https://www.animedubhindi.xyz';
    return rtrim($base, '/');
}

function absolute_site_url(string $path = ''): string
{
    $path = trim($path);
    if ($path === '' || $path === '#') return site_base_url() . '/';
    if (preg_match('#^https?://#i', $path)) return $path;
    $path = ltrim($path, '/');
    return site_base_url() . '/' . $path;
}

function brand_name_html(?string $name = null): string
{
    $name = trim((string)($name ?: setting('site_name', 'AnimeDubHindi')));
    if ($name === '') $name = 'AnimeDubHindi';

    // Professional segmented brand styling. Keep the full readable name intact.
    if (preg_match('/^animedubhindi$/i', $name)) {
        $nameHtml = '<span class="brand-part brand-anime">Anime</span><span class="brand-part brand-dub">Dub</span><span class="brand-part brand-hindi">Hindi</span>';
    } else {
        $nameHtml = e($name);
    }

    return '<span class="brand-word brand-word-pro">' . $nameHtml . '<span class="brand-domain-badge">.xyz</span></span>';
}

function current_url($path = ''): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = preg_replace('/[^A-Za-z0-9.:-]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
    if ($host === '') $host = 'localhost';
    return $scheme . '://' . $host . url($path);
}

function asset($path): string { return url('assets/' . ltrim($path, '/')); }

function cover_url(?string $file): string
{
    if ($file && (str_starts_with($file, 'http://') || str_starts_with($file, 'https://'))) return $file;
    if ($file && file_exists(BASE_PATH . '/' . ltrim($file, '/'))) return url($file);
    return asset('img/cover-placeholder.svg');
}

function setting(string $key, ?string $default = ''): string
{
    try {
        $stmt = db()->prepare('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $value = $stmt->fetchColumn();
        return $value !== false ? (string)$value : (string)$default;
    } catch (Throwable $e) { return (string)$default; }
}

function save_setting(string $key, string $value): void
{
    $stmt = db()->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    $stmt->execute([$key, $value]);
}

function setting_bool(string $key, string $default = '1'): bool
{
    return setting($key, $default) === '1';
}

function has_sidebar(): bool
{
    $featured = false;
    if (setting('sidebar_featured_enabled', '1') === '1') {
        try { $featured = (int)db()->query('SELECT COUNT(*) FROM sidebar_featured_anime WHERE is_active=1')->fetchColumn() > 0; }
        catch (Throwable $e) { $featured = false; }
    }
    $social = setting('social_box_enabled', '1') === '1';
    $legacyAd = setting('ad_enabled', '0') === '1' && (setting('ad_html', '') !== '' || setting('ad_image', '') !== '' || setting('show_empty_ad_box', '0') === '1');
    $adControl = function_exists('has_ad_control_sidebar') ? has_ad_control_sidebar() : false;
    $menu = setting('sidebar_menu_links_enabled', '1') === '1';
    return $featured || $social || $legacyAd || $adControl || $menu;
}

function fetch_featured_sidebar(int $limit = 5): array
{
    $limit = max(1, min(12, $limit));
    try {
        // Manual sidebar selection only. Nothing is auto-picked here.
        $stmt = db()->query("SELECT a.*
            FROM sidebar_featured_anime s
            INNER JOIN anime a ON a.id = s.anime_id
            WHERE s.is_active = 1 AND COALESCE(a.content_status,'published')='published'
            ORDER BY s.sort_order ASC, a.published_at DESC, a.id DESC
            LIMIT {$limit}");
        return $stmt->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}

function slugify(string $text): string
{
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = trim($text, '-');
    $text = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
    $text = strtolower($text);
    $text = preg_replace('~[^-a-z0-9]+~', '', $text);
    return $text ?: 'anime-' . time();
}

function unique_slug(string $title, string $table = 'anime', int $ignoreId = 0): string
{
    $base = slugify($title); $slug = $base; $i = 2;
    while (true) {
        $sql = "SELECT id FROM {$table} WHERE slug = ?" . ($ignoreId ? ' AND id != ?' : '') . ' LIMIT 1';
        $params = $ignoreId ? [$slug, $ignoreId] : [$slug];
        $stmt = db()->prepare($sql); $stmt->execute($params);
        if (!$stmt->fetch()) return $slug;
        $slug = $base . '-' . $i++;
    }
}

function get_menus(): array
{
    try { $items = db()->query('SELECT * FROM menus WHERE is_active = 1 ORDER BY parent_id ASC, sort_order ASC, label ASC')->fetchAll(); }
    catch (Throwable $e) { return []; }
    $tree = []; $children = [];
    foreach ($items as $item) {
        if ((int)$item['parent_id'] === 0) $tree[] = $item;
        else $children[(int)$item['parent_id']][] = $item;
    }
    foreach ($tree as &$item) $item['children'] = $children[(int)$item['id']] ?? [];
    return $tree;
}

function anime_link(array $anime): string { return url('anime.php?slug=' . urlencode($anime['slug'] ?? '')); }

function excerpt(string $text = null, int $length = 160): string
{
    $text = trim(strip_tags((string)$text));
    if (mb_strlen($text) <= $length) return $text;
    return mb_substr($text, 0, $length - 3) . '...';
}

function is_admin_logged_in(): bool
{
    if (empty($_SESSION['admin_id'])) return false;
    $now = time();
    // Re-check the admin account every 5 minutes so deleted/changed users cannot keep an old session forever.
    if (empty($_SESSION['admin_verified_at']) || ($now - (int)$_SESSION['admin_verified_at']) > 300) {
        try {
            $stmt = db()->prepare('SELECT id, username FROM admin_users WHERE id = ? LIMIT 1');
            $stmt->execute([(int)$_SESSION['admin_id']]);
            $user = $stmt->fetch();
            if (!$user) { $_SESSION = []; return false; }
            $_SESSION['admin_username'] = (string)$user['username'];
            $_SESSION['admin_verified_at'] = $now;
        } catch (Throwable $e) {
            return false;
        }
    }
    return true;
}
function require_admin(): void
{
    if (!is_admin_logged_in()) { header('Location: index.php'); exit; }
    if (empty($_SESSION['admin_regenerated_at']) || time() - (int)$_SESSION['admin_regenerated_at'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['admin_regenerated_at'] = time();
    }
}
function admin_url($path = ''): string { return url('admin/' . ltrim($path, '/')); }
function flash(string $message, string $type = 'success'): void { $_SESSION['flash'] = ['message' => $message, 'type' => $type]; }
function get_flash(): ?array { if (empty($_SESSION['flash'])) return null; $f = $_SESSION['flash']; unset($_SESSION['flash']); return $f; }


function csrf_token(): string
{
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['_csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_url(string $url): string
{
    $sep = str_contains($url, '?') ? '&' : '?';
    return $url . $sep . '_csrf=' . rawurlencode(csrf_token());
}

function verify_csrf(?string $token = null): bool
{
    $token = $token ?? (string)($_POST['_csrf'] ?? $_GET['_csrf'] ?? '');
    return isset($_SESSION['_csrf_token']) && hash_equals((string)$_SESSION['_csrf_token'], (string)$token);
}

function require_csrf(): void
{
    if (!verify_csrf()) {
        http_response_code(403);
        exit('Security check failed. Please go back, refresh the page and try again.');
    }
}

function require_admin_csrf_for_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') require_csrf();
}

function clean_text(string $value, int $max = 1000): string
{
    $value = trim(strip_tags($value));
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value) ?? $value;
    return mb_substr($value, 0, $max);
}

function safe_external_url(string $url): string
{
    $url = trim($url);
    if ($url === '') return '';
    if (!preg_match('#^https?://#i', $url)) return '';
    return mb_substr($url, 0, 2000);
}

function admin_safe_return(string $fallback = 'dashboard.php'): string
{
    $url = (string)($_POST['return_to'] ?? $_GET['return_to'] ?? $fallback);
    $parts = parse_url($url);
    if (!$parts || !empty($parts['scheme']) || !empty($parts['host']) || str_contains($url, "\n") || str_contains($url, "\r")) return $fallback;
    return $url ?: $fallback;
}

function rate_limit_key(string $scope): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'local';
    return '_rate_' . hash('sha256', $scope . '|' . $ip);
}

function simple_rate_limit(string $scope, int $maxAttempts, int $windowSeconds): bool
{
    $key = rate_limit_key($scope);
    $now = time();
    $bucket = $_SESSION[$key] ?? ['start'=>$now,'count'=>0];
    if (!is_array($bucket) || ($now - (int)($bucket['start'] ?? 0)) > $windowSeconds) $bucket = ['start'=>$now,'count'=>0];
    $bucket['count'] = (int)$bucket['count'] + 1;
    $_SESSION[$key] = $bucket;
    return $bucket['count'] <= $maxAttempts;
}



function login_attempts_table_ready(): void
{
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS login_attempts (id BIGINT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) NULL, ip_hash CHAR(64) NULL, success TINYINT(1) DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_login_attempts_date (created_at), INDEX idx_login_attempts_ip (ip_hash)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) {}
}

function login_ip_hash(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    return hash('sha256', $ip . '|' . DB_NAME . '|login');
}

function login_is_rate_limited(string $username = ''): bool
{
    try {
        login_attempts_table_ready();
        db()->exec('DELETE FROM login_attempts WHERE created_at < DATE_SUB(NOW(), INTERVAL 2 DAY)');
        $stmt = db()->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_hash=? AND success=0 AND created_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
        $stmt->execute([login_ip_hash()]);
        return (int)$stmt->fetchColumn() >= 8;
    } catch (Throwable $e) {
        return false;
    }
}

function record_login_attempt(string $username, bool $success): void
{
    try {
        login_attempts_table_ready();
        $stmt = db()->prepare('INSERT INTO login_attempts(username, ip_hash, success) VALUES(?,?,?)');
        $stmt->execute([mb_substr($username,0,80), login_ip_hash(), $success ? 1 : 0]);
        if ($success) db()->prepare('DELETE FROM login_attempts WHERE ip_hash=? AND success=0')->execute([login_ip_hash()]);
    } catch (Throwable $e) {}
}

function security_audit_log(string $event, string $detail = ''): void
{
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS security_logs (id BIGINT AUTO_INCREMENT PRIMARY KEY, event_type VARCHAR(80) NOT NULL, detail VARCHAR(255) NULL, ip_hash CHAR(64) NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_security_logs_date (created_at), INDEX idx_security_logs_event (event_type)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $hash = hash('sha256', $ip . '|' . DB_NAME);
        $stmt = db()->prepare('INSERT INTO security_logs(event_type, detail, ip_hash) VALUES(?,?,?)');
        $stmt->execute([mb_substr($event,0,80), mb_substr($detail,0,255), $hash]);
    } catch (Throwable $e) {}
}

function clean_external_cover_url(string $url): string
{
    $url = trim($url);
    if ($url === '') return '';
    if (strlen($url) > 2000) throw new RuntimeException('Cover image URL is too long.');
    if (!filter_var($url, FILTER_VALIDATE_URL)) throw new RuntimeException('Please enter a valid cover image URL.');
    $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
    if (!in_array($scheme, ['http','https'], true)) throw new RuntimeException('Cover image URL must start with http:// or https://');
    return $url;
}

function admin_language_options(): array
{
    $base = ['Hindi Dubbed','Hindi Multi Audio','English Dubbed','Japanese Subbed','Bangla Dubbed','Tamil Dubbed','Telugu Dubbed','Multi Audio'];
    try {
        $rows = db()->query("SELECT DISTINCT language FROM anime WHERE language IS NOT NULL AND language<>'' ORDER BY language ASC LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($rows as $r) { $r = trim((string)$r); if ($r !== '') $base[] = $r; }
    } catch (Throwable $e) {}
    $out = [];
    foreach ($base as $v) { $v = trim((string)$v); if ($v !== '' && !in_array($v, $out, true)) $out[] = $v; }
    return $out;
}

function upload_cover(string $field, ?string $old = null): ?string
{
    if (empty($_FILES[$field]['name']) || !is_uploaded_file($_FILES[$field]['tmp_name'])) return $old;
    if (!empty($_FILES[$field]['error'])) throw new RuntimeException('Cover upload failed. Please choose another image.');
    if ((int)($_FILES[$field]['size'] ?? 0) > 4 * 1024 * 1024) throw new RuntimeException('Cover image is too large. Maximum size is 4MB.');

    $info = @getimagesize($_FILES[$field]['tmp_name']);
    if (!$info || empty($info['mime'])) throw new RuntimeException('Invalid image file.');
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $mime = $info['mime'];
    if (!isset($allowed[$mime])) throw new RuntimeException('Only JPG, PNG or WEBP cover images are allowed.');

    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
    $name = 'cover-' . date('Ymd-His') . '-' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
    $dest = UPLOAD_DIR . $name;
    if (!move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) throw new RuntimeException('Cover upload failed. Check uploads/covers permission.');
    @chmod($dest, 0644);
    return UPLOAD_URL . $name;
}

function public_anime_condition(string $extra = '1'): string
{
    $extra = trim($extra) !== '' ? $extra : '1';
    return "({$extra}) AND COALESCE(content_status,'published')='published'";
}

function fetch_anime_list(string $where = '1', array $params = [], int $limit = 60, int $offset = 0): array
{
    $limit = max(1, min(300, $limit)); $offset = max(0, $offset);
    $where = public_anime_condition($where);
    $sql = "SELECT * FROM anime WHERE {$where} ORDER BY is_pinned DESC, published_at DESC, id DESC LIMIT {$limit} OFFSET {$offset}";
    $stmt = db()->prepare($sql); $stmt->execute($params); return $stmt->fetchAll();
}

function content_status_label(?string $status): string
{
    $status = strtolower((string)$status);
    return match($status) {
        'draft' => 'Draft',
        'unpublished' => 'Unpublished',
        default => 'Published',
    };
}

function content_status_badge_class(?string $status): string
{
    $status = strtolower((string)$status);
    return match($status) {
        'draft' => 'draft',
        'unpublished' => 'unpublished',
        default => 'published',
    };
}

function get_legal_page_data(string $page): array
{
    $site = setting('site_name', 'AnimeDubHindi');
    $pages = [
        'about' => [
            'title' => 'About Us',
            'intro' => "{$site} is a clean anime update website built for visitors who want simple release information, episode lists, download references, watch links and community updates in one organized place.",
            'sections' => [
                ['title' => 'What we do', 'body' => [
                    "We organize anime release pages with titles, cover images, synopsis, series information, episode lists, quality options, ZIP pack references and similar recommendations so visitors can find updates without confusion.",
                    "Our focus is a minimal reading experience: fast pages, clear buttons, mobile-friendly layout and simple navigation from home page to episode details."
                ]],
                ['title' => 'Content and external links', 'body' => [
                    "{$site} does not store video or archive files on its own server. Pages may include references or links to third-party websites, community sources, cloud storage pages or external players.",
                    "If a link is unavailable, broken or incorrect, visitors can report it through the broken link report page so the admin can review it."
                ]],
                ['title' => 'Community updates', 'body' => [
                    "Visitors can follow our Telegram and WhatsApp channels for release notices, site announcements and important updates.",
                    "Use the channel buttons below to open the official community pages without exposing long raw URLs on the page."
                ], 'cta' => true],
                ['title' => 'Our goals', 'list' => [
                    'Keep release pages clean and readable.',
                    'Make episode links easy to understand by quality and host name.',
                    'Support desktop and mobile users with a simple interface.',
                    'Respond to valid requests, reports and copyright concerns as quickly as possible.'
                ]],
            ],
        ],
        'privacy' => [
            'title' => 'Privacy Policy',
            'intro' => "This Privacy Policy explains what information {$site} may collect and how that information is used when you browse the website, submit a request, report a broken link or contact the admin.",
            'sections' => [
                ['title' => 'Information you submit', 'body' => [
                    'When you use request, report or contact forms, we may receive the name, email address, subject, page URL and message you choose to submit.',
                    'This information is used only to review your request, reply if necessary, fix reported issues or process copyright-related messages.'
                ]],
                ['title' => 'Basic technical information', 'body' => [
                    'Like most websites, basic server logs may include IP address, browser type, device information, date/time and visited pages. This helps with security, debugging and performance improvement.',
                    'We do not sell personal information to advertisers or unrelated third parties.'
                ]],
                ['title' => 'Cookies and local storage', 'body' => [
                    'The website may use cookies or browser local storage for simple features such as remembering whether a Telegram/WhatsApp popup was closed within a 24-hour period.',
                    'Third-party services, advertisements or external links may use their own cookies after you visit them. Their privacy rules are controlled by those third-party websites, not by {$site}.'
                ]],
                ['title' => 'Third-party links', 'body' => [
                    'Pages may contain links to external websites, file hosts, video players, social channels or advertisements. Once you leave {$site}, you are responsible for reviewing the privacy practices of that website.',
                    'We recommend avoiding suspicious popups, fake download buttons or pages asking for unnecessary personal information.'
                ]],
                ['title' => 'Data protection and removal', 'body' => [
                    'We keep submitted form data only for administration, support and abuse-prevention purposes. If you want a message you submitted removed from our records, contact us with enough details to locate it.',
                    'For copyright or legal notices, please use the DMCA/Copyright page so the request can be reviewed properly.'
                ]],
            ],
        ],
        'terms' => [
            'title' => 'Terms & Conditions',
            'intro' => "By using {$site}, you agree to follow these terms. If you do not agree with these terms, please stop using the website.",
            'sections' => [
                ['title' => 'Permitted use', 'list' => [
                    'Use the website for personal browsing, release updates, community notices and information.',
                    'Submit genuine anime requests and broken link reports.',
                    'Share public page links without modifying, scraping or abusing the website.'
                ]],
                ['title' => 'Prohibited use', 'list' => [
                    'Do not spam forms, submit fake reports or misuse request features.',
                    'Do not attempt to access the admin panel or database without permission.',
                    'Do not upload, submit or promote malware, phishing links or harmful content.',
                    'Do not impersonate copyright owners, staff members or official representatives.'
                ]],
                ['title' => 'External content', 'body' => [
                    '{$site} may index or reference third-party pages. We do not guarantee that external links will always work, remain safe, remain available or remain unchanged.',
                    'Visitors are responsible for their own actions on external websites. Use trusted browsers, blockers and security tools when visiting third-party hosts.'
                ]],
                ['title' => 'Changes to the website', 'body' => [
                    'We may update page layouts, links, features, policies, categories or community links at any time without prior notice.',
                    'If a feature is removed or changed, previously saved links or pages may stop working.'
                ]],
                ['title' => 'Limitation of responsibility', 'body' => [
                    'The website is provided as-is for information and community updates. We are not responsible for damage, loss, security issues or disputes caused by third-party websites or user actions outside our domain.'
                ]],
            ],
        ],
        'dmca' => [
            'title' => 'DMCA / Copyright Policy',
            'intro' => "{$site} respects copyright owners. We do not host anime files on our own server. If you believe a page or external reference should be removed, send a clear copyright request so it can be reviewed.",
            'sections' => [
                ['title' => 'Important notice', 'body' => [
                    'We are an update/index-style website. Our pages may contain information, descriptions, external references or community-submitted links. We do not claim ownership of anime titles, characters, logos, images or third-party media.',
                    'Valid copyright complaints are reviewed and, where appropriate, the listed reference or page content may be removed or updated.'
                ]],
                ['title' => 'What to include in a copyright request', 'list' => [
                    'Your full name and contact email.',
                    'The exact URL on our website that you want reviewed.',
                    'A clear description of the copyrighted work you own or represent.',
                    'Proof that you are the rights holder or authorized representative.',
                    'A statement that you believe the listed reference is not authorized.',
                    'A statement that the information in your notice is accurate.',
                    'Your physical or electronic signature.'
                ]],
                ['title' => 'How we handle reports', 'body' => [
                    'After receiving a complete notice, the admin may review the page, remove or disable the reference, ask for additional details, or reject incomplete/false requests.',
                    'Submitting false, misleading or abusive notices may result in ignored future requests.'
                ]],
                ['title' => 'Contact for copyright matters', 'body' => [
                    'Use the Contact page or Broken Link/Report page and clearly mark the subject as “Copyright Request” or “DMCA Notice”.',
                    'Please do not send vague requests such as “remove everything”. Exact URLs help us respond faster.'
                ]],
            ],
        ],
        'disclaimer' => [
            'title' => 'Disclaimer',
            'intro' => "The information on {$site} is provided for anime release updates, episode organization, community notices and general browsing convenience.",
            'sections' => [
                ['title' => 'No file hosting', 'body' => [
                    '{$site} does not store anime video files, ZIP archives or downloadable media on its own server. External links, if shown, point to third-party websites or services.',
                    'We do not control the availability, safety, speed, advertisements, redirects or policies of external websites.'
                ]],
                ['title' => 'Accuracy of information', 'body' => [
                    'We try to keep titles, dates, episode numbers, quality labels and descriptions accurate, but mistakes can happen. Information may change after publication.',
                    'Visitors can report wrong titles, broken links or incorrect details through the report page.'
                ]],
                ['title' => 'Third-party advertisements and links', 'body' => [
                    'Advertisements and external pages may be operated by unrelated third parties. Their claims, buttons, popups, downloads and privacy practices are not controlled by {$site}.',
                    'Always check the URL before clicking download or play buttons on external websites.'
                ]],
                ['title' => 'Copyright ownership', 'body' => [
                    'All anime names, artwork, characters, logos and related materials belong to their respective owners. {$site} uses information for identification, review, organization or update purposes only.',
                    'Rights holders can use the DMCA/Copyright page for removal requests.'
                ]],
            ],
        ],
        'contact' => [
            'title' => 'Contact Us',
            'intro' => "Use this page to reach the {$site} team for requests, reports, corrections, copyright matters or community questions.",
            'sections' => [
                ['title' => 'Best way to contact us', 'list' => [
                    'For anime requests, use the Request Anime page.',
                    'For broken or incorrect links, use the Report Broken Link page.',
                    'For copyright concerns, include the exact page URL and ownership details.',
                    'For quick community updates, use the official Telegram or WhatsApp channel links.'
                ]],
                ['title' => 'Response time', 'body' => [
                    'We try to review important messages as soon as possible. Requests with clear titles, URLs and details are easier to handle than short or incomplete messages.',
                    'Spam, abuse, fake copyright claims or unrelated promotion may be ignored.'
                ]],
                ['title' => 'Official channels', 'body' => [
                    'Use the buttons below to open our official Telegram and WhatsApp community channels.',
                    'For requests, broken links or copyright concerns, the website forms are still the best option because they keep your message organized for review.'
                ], 'cta' => true],
            ],
        ],
        'cookie' => [
            'title' => 'Cookie Policy',
            'intro' => "This Cookie Policy explains how {$site} may use cookies, browser storage and similar technologies to keep the website simple and functional.",
            'sections' => [
                ['title' => 'What cookies are', 'body' => [
                    'Cookies are small pieces of data stored by your browser. They help websites remember simple choices and improve basic functionality.'
                ]],
                ['title' => 'How we use them', 'list' => [
                    'Remember whether the Telegram/WhatsApp popup was closed for a limited time.',
                    'Improve search, menu and layout behavior on desktop and mobile.',
                    'Support security, analytics or performance features if enabled by the admin.'
                ]],
                ['title' => 'Third-party cookies', 'body' => [
                    'External links, video players, advertisements and social platforms may use their own cookies. We do not control cookies set by third-party websites after you leave our domain.'
                ]],
                ['title' => 'How to control cookies', 'body' => [
                    'You can clear or block cookies from your browser settings. Some features, such as popup timing or saved preferences, may reset if browser storage is cleared.'
                ]],
            ],
        ],
    ];

    return $pages[$page] ?? [
        'title' => 'Page',
        'intro' => 'This page will be updated soon.',
        'sections' => [],
    ];
}

function get_page_copy(string $page): array
{
    $data = get_legal_page_data($page);
    return [$data['title'], $data['intro']];
}


function public_feature_enabled(string $key, string $default = '1'): bool
{
    return setting($key, $default) === '1';
}

function render_public_closed_page(string $title, string $message): void
{
    $page_title = $title . ' - ' . setting('site_name', 'AnimeDubHindi');
    require __DIR__ . '/header.php';
    echo '<main class="container main-wrap no-sidebar"><section class="content-card form-card closed-page"><h1 class="section-title">' . e($title) . '</h1><p class="muted">' . e($message) . '</p><p><a class="btn" href="' . e(url('index.php')) . '">Back to Home</a></p></section></main>';
    require __DIR__ . '/footer.php';
    exit;
}

function player_source_from_url(string $url): array
{
    $url = safe_external_url($url);
    if ($url === '') return ['type'=>'none','src'=>''];

    // Pixeldrain share link: https://pixeldrain.com/u/FILEID
    // The API file endpoint can be used by the HTML5 video player when the file is a playable video.
    if (preg_match('~pixeldrain\.com/(?:u|file)/([A-Za-z0-9]+)~i', $url, $m)) {
        return ['type'=>'video','src'=>'https://pixeldrain.com/api/file/' . $m[1]];
    }
    if (preg_match('~pixeldrain\.com/api/file/([A-Za-z0-9]+)~i', $url)) {
        return ['type'=>'video','src'=>$url];
    }

    // Google Drive preview iframe link support.
    if (preg_match('~drive\.google\.com/file/d/([^/]+)~i', $url, $m)) {
        return ['type'=>'iframe','src'=>'https://drive.google.com/file/d/' . rawurlencode($m[1]) . '/preview'];
    }

    // Dropbox share links can usually be converted to raw delivery links.
    if (str_contains($url, 'dropbox.com/')) {
        $src = preg_replace('~[?&]dl=0~', '', $url);
        $src .= (str_contains($src, '?') ? '&' : '?') . 'raw=1';
        return ['type'=>'video','src'=>$src];
    }

    // Direct video files work best with the native HTML5 player.
    if (preg_match('~\.(mp4|webm|ogg)(\?.*)?$~i', $url)) return ['type'=>'video','src'=>$url];

    // Known embed/player URLs can be loaded in an iframe.
    if (preg_match('~(iframe\.mediadelivery\.net|player\.mediadelivery\.net|videodelivery\.net|cloudflarestream\.com|youtube\.com/embed|player\.vimeo\.com)~i', $url)) {
        return ['type'=>'iframe','src'=>$url];
    }

    // Fallback: try iframe. If the host blocks embedding, the page still offers the original link.
    return ['type'=>'iframe','src'=>$url];
}




function ad_control_enabled(): bool
{
    return setting('ad_code_master_enabled', '1') === '1';
}

function ad_control_code(string $placement): string
{
    if (!ad_control_enabled()) return '';
    $key = 'ad_code_' . $placement;
    $enabledKey = $key . '_enabled';
    if (setting($enabledKey, '0') !== '1') return '';
    return trim(setting($key, ''));
}

function render_ad_placement(string $placement): void
{
    $code = ad_control_code($placement);
    if ($code === '') return;
    echo "\n<!-- AnimeDubHindi Ad Control: " . e($placement) . " -->\n";
    echo $code . "\n";
    echo "<!-- /AnimeDubHindi Ad Control -->\n";
}

function has_ad_control_sidebar(): bool
{
    return ad_control_enabled() && setting('ad_code_sidebar_enabled', '0') === '1' && trim(setting('ad_code_sidebar', '')) !== '';
}

function client_device_type(): string
{
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (preg_match('/ipad|tablet|kindle|silk/', $ua)) return 'tablet';
    if (preg_match('/mobi|android|iphone|ipod|blackberry|phone/', $ua)) return 'mobile';
    return 'desktop';
}

function visitor_ip_hash(): string
{
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    if (str_contains($ip, ',')) $ip = trim(explode(',', $ip)[0]);
    return hash('sha256', $ip . '|' . (defined('DB_NAME') ? DB_NAME : 'animedubhindi'));
}

function track_event(string $eventType, array $data = []): void
{
    try {
        if (setting('analytics_enabled', '1') !== '1') return;
        $allowed = ['page_view','anime_view','watch_click','download_click','zip_click','search','request_submit','report_submit'];
        if (!in_array($eventType, $allowed, true)) $eventType = 'page_view';
        // Keep analytics useful without storing heavy/raw visitor details for too long.
        if (random_int(1, 100) === 1) {
            try { db()->exec('DELETE FROM analytics_events WHERE created_at < DATE_SUB(NOW(), INTERVAL 180 DAY)'); } catch (Throwable $e) {}
        }
        $stmt = db()->prepare('INSERT INTO analytics_events(event_type, anime_id, episode_id, link_id, zip_id, page_url, referrer, title, device_type, ip_hash, user_agent, extra_data, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,NOW())');
        $stmt->execute([
            $eventType,
            isset($data['anime_id']) ? (int)$data['anime_id'] : null,
            isset($data['episode_id']) ? (int)$data['episode_id'] : null,
            isset($data['link_id']) ? (int)$data['link_id'] : null,
            isset($data['zip_id']) ? (int)$data['zip_id'] : null,
            mb_substr((string)($data['page_url'] ?? ($_SERVER['REQUEST_URI'] ?? '')), 0, 500),
            '',
            mb_substr((string)($data['title'] ?? ''), 0, 255),
            client_device_type(),
            null,
            '',
            json_encode($data['extra'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        ]);
    } catch (Throwable $e) {
        // Analytics must never break the public website.
    }
}

function analytics_count(string $eventType = '', string $range = 'all'): int
{
    try {
        $where = [];
        $params = [];
        if ($eventType !== '') { $where[] = 'event_type = ?'; $params[] = $eventType; }
        if ($range === 'today') $where[] = 'DATE(created_at) = CURDATE()';
        elseif ($range === '7d') $where[] = 'created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
        elseif ($range === '30d') $where[] = 'created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
        $sql = 'SELECT COUNT(*) FROM analytics_events' . ($where ? ' WHERE '.implode(' AND ', $where) : '');
        $stmt = db()->prepare($sql); $stmt->execute($params); return (int)$stmt->fetchColumn();
    } catch (Throwable $e) { return 0; }
}



function seo_control_defaults(): array
{
    return [
        'seo_control_enabled' => '1',
        'seo_robots_enabled' => '1',
        'seo_allow_ai_bots' => '1',
        'seo_sitemap_enabled' => '1',
        'seo_sitemap_legal_enabled' => '1',
        'seo_sitemap_anime_enabled' => '1',
        'seo_sitemap_static_enabled' => '1',
        'seo_indexnow_enabled' => '0',
        'seo_indexnow_key' => '',
        'seo_google_verification' => '',
        'seo_bing_verification' => '',
        'seo_yandex_verification' => '',
        'seo_naver_verification' => '',
        'seo_default_robots_meta' => 'index,follow,max-image-preview:large',
        'seo_schema_enabled' => '1',
        'seo_og_enabled' => '1',
        'seo_twitter_enabled' => '1',
        'seo_auto_ping_enabled' => '0',
    ];
}

function seo_setting(string $key, string $default = ''): string
{
    $defaults = seo_control_defaults();
    return setting($key, $defaults[$key] ?? $default);
}

function seo_control_enabled(): bool
{
    return seo_setting('seo_control_enabled', '1') === '1';
}

function sitemap_pages(): array
{
    $base = site_base_url();
    $now = date('Y-m-d');
    $pages = [];
    if (seo_setting('seo_sitemap_static_enabled','1') === '1') {
        foreach ([
            ['/', 'daily', '1.0'],
            ['/movies.php', 'weekly', '0.8'],
            ['/series.php', 'weekly', '0.8'],
            ['/genres.php', 'weekly', '0.7'],
            ['/search.php', 'monthly', '0.5'],
        ] as $p) {
            $pages[] = ['loc'=>$base . $p[0], 'lastmod'=>$now, 'changefreq'=>$p[1], 'priority'=>$p[2]];
        }
    }
    if (seo_setting('seo_sitemap_anime_enabled','1') === '1') {
        try {
            $stmt = db()->query("SELECT slug, updated_at, published_at FROM anime WHERE COALESCE(content_status,'published')='published' ORDER BY updated_at DESC, id DESC LIMIT 50000");
            foreach ($stmt->fetchAll() as $a) {
                $last = $a['updated_at'] ?: ($a['published_at'] ?: date('Y-m-d H:i:s'));
                $pages[] = [
                    'loc'=>$base . '/anime.php?slug=' . rawurlencode((string)$a['slug']),
                    'lastmod'=>date('Y-m-d', strtotime($last)),
                    'changefreq'=>'weekly',
                    'priority'=>'0.9'
                ];
            }
        } catch (Throwable $e) {}
    }
    if (seo_setting('seo_sitemap_legal_enabled','1') === '1') {
        foreach (['about.php','privacy.php','terms.php','dmca.php','disclaimer.php','contact.php','cookie.php','request.php','report.php'] as $p) {
            $pages[] = ['loc'=>$base . '/' . $p, 'lastmod'=>$now, 'changefreq'=>'monthly', 'priority'=>'0.4'];
        }
    }
    return $pages;
}

function render_meta_verification_tags(): void
{
    if (!seo_control_enabled()) return;
    $map = [
        'seo_google_verification' => 'google-site-verification',
        'seo_bing_verification' => 'msvalidate.01',
        'seo_yandex_verification' => 'yandex-verification',
        'seo_naver_verification' => 'naver-site-verification',
    ];
    foreach ($map as $key=>$name) {
        $value = trim(seo_setting($key, ''));
        $value = preg_replace('/<[^>]+>/', '', $value);
        if ($value !== '') echo '  <meta name="' . e($name) . '" content="' . e($value) . '">' . "\n";
    }
}


function safe_tracking_id(string $value, string $pattern): string
{
    $value = trim($value);
    return preg_match($pattern, $value) ? $value : '';
}

function render_seo_custom_head_codes(): void
{
    if (!seo_control_enabled()) return;
    $ga = safe_tracking_id(seo_setting('seo_google_analytics_id',''), '/^G-[A-Z0-9_-]+$/i');
    if ($ga !== '') {
        echo "<!-- Google Analytics -->\n";
        echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . e($ga) . '"></script>' . "\n";
        echo "<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','" . e($ga) . "');</script>\n";
    }
    $gtm = safe_tracking_id(seo_setting('seo_google_tag_manager_id',''), '/^GTM-[A-Z0-9_-]+$/i');
    if ($gtm !== '') {
        echo "<!-- Google Tag Manager -->\n";
        echo "<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','" . e($gtm) . "');</script>\n";
    }
    $clarity = safe_tracking_id(seo_setting('seo_microsoft_clarity_id',''), '/^[A-Za-z0-9_-]{5,64}$/');
    if ($clarity !== '') {
        echo "<!-- Microsoft Clarity -->\n";
        echo "<script>(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src='https://www.clarity.ms/tag/'+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);})(window,document,'clarity','script','" . e($clarity) . "');</script>\n";
    }
    $pixel = safe_tracking_id(seo_setting('seo_facebook_pixel_id',''), '/^[0-9]{5,30}$/');
    if ($pixel !== '') {
        echo "<!-- Meta Pixel -->\n";
        echo "<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','" . e($pixel) . "');fbq('track','PageView');</script>\n";
    }
    $extra = trim(seo_setting('seo_custom_head_codes',''));
    if ($extra !== '') echo "<!-- Custom SEO head codes -->\n" . $extra . "\n";
}

function render_seo_body_start_codes(): void
{
    if (!seo_control_enabled()) return;
    $gtm = safe_tracking_id(seo_setting('seo_google_tag_manager_id',''), '/^GTM-[A-Z0-9_-]+$/i');
    if ($gtm !== '') {
        echo '<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=' . e($gtm) . '" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>' . "\n";
    }
    $extra = trim(seo_setting('seo_custom_body_start_codes',''));
    if ($extra !== '') echo "<!-- Custom body start SEO/tracking codes -->\n" . $extra . "\n";
}

function render_seo_body_end_codes(): void
{
    if (!seo_control_enabled()) return;
    $extra = trim(seo_setting('seo_custom_body_end_codes',''));
    if ($extra !== '') echo "<!-- Custom body end SEO/tracking codes -->\n" . $extra . "\n";
}

function canonical_url_for_current_page(): string
{
    $path = strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/';
    $query = [];
    if (isset($_GET['slug']) && preg_match('/^[a-z0-9-]+$/', (string)$_GET['slug'])) $query['slug'] = (string)$_GET['slug'];
    if (isset($_GET['q']) && trim((string)$_GET['q']) !== '') $query['q'] = trim((string)$_GET['q']);
    $url = site_base_url() . $path;
    if ($query) $url .= '?' . http_build_query($query);
    return $url;
}

function render_basic_seo_tags(?string $title = null, ?string $description = null, ?string $image = null): void
{
    if (!seo_control_enabled()) return;
    $title = trim((string)($title ?: setting('site_name','AnimeDubHindi')));
    $description = trim((string)($description ?: setting('site_description','Anime release updates, episode links and download pack information.')));
    $canonical = canonical_url_for_current_page();
    echo '  <meta name="robots" content="' . e(seo_setting('seo_default_robots_meta','index,follow,max-image-preview:large')) . '">' . "\n";
    echo '  <link rel="canonical" href="' . e($canonical) . '">' . "\n";
    if (seo_setting('seo_og_enabled','1') === '1') {
        echo '  <meta property="og:type" content="website">' . "\n";
        echo '  <meta property="og:title" content="' . e($title) . '">' . "\n";
        echo '  <meta property="og:description" content="' . e($description) . '">' . "\n";
        echo '  <meta property="og:url" content="' . e($canonical) . '">' . "\n";
        if ($image) echo '  <meta property="og:image" content="' . e(absolute_site_url($image)) . '">' . "\n";
    }
    if (seo_setting('seo_twitter_enabled','1') === '1') {
        echo '  <meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '  <meta name="twitter:title" content="' . e($title) . '">' . "\n";
        echo '  <meta name="twitter:description" content="' . e($description) . '">' . "\n";
    }
    render_meta_verification_tags();
}

function render_jsonld_schema(array $data): void
{
    if (!seo_control_enabled() || seo_setting('seo_schema_enabled','1') !== '1') return;
    echo '<script type="application/ld+json">' . json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
}

function render_website_schema(): void
{
    render_jsonld_schema([
        '@context'=>'https://schema.org',
        '@type'=>'WebSite',
        'name'=>setting('site_name','AnimeDubHindi'),
        'url'=>site_base_url() . '/',
        'potentialAction'=>[
            '@type'=>'SearchAction',
            'target'=>site_base_url() . '/search.php?q={search_term_string}',
            'query-input'=>'required name=search_term_string'
        ]
    ]);
}

function indexnow_key_file_name(): string
{
    $key = trim(seo_setting('seo_indexnow_key',''));
    if ($key === '') return '';
    $key = preg_replace('/[^A-Za-z0-9_-]/', '', $key);
    return $key !== '' ? $key . '.txt' : '';
}

function security_file_status(string $relativePath): bool
{
    $path = BASE_PATH . '/' . ltrim($relativePath, '/');
    return is_file($path) && filesize($path) > 0;
}

function security_quick_checks(): array
{
    $checks = [];
    $checks[] = ['Installer locked', security_file_status('storage/install.lock'), 'storage/install.lock should exist after install on live hosting.'];
    $checks[] = ['Root .htaccess present', security_file_status('.htaccess'), 'Apache rules protect sensitive files and disable listing.'];
    $checks[] = ['Includes protected', security_file_status('includes/.htaccess'), 'includes folder blocks direct web access.'];
    $checks[] = ['Database folder protected', security_file_status('database/.htaccess'), 'database folder blocks direct web access.'];
    $checks[] = ['Storage protected', security_file_status('storage/.htaccess'), 'storage folder blocks direct web access.'];
    $checks[] = ['Uploads hardened', security_file_status('uploads/.htaccess'), 'uploads folder blocks executable files.'];
    $checks[] = ['PHP errors hidden', ini_get('display_errors') === '0', 'Visitors should not see PHP warnings/errors.'];
    $checks[] = ['Strict sessions enabled', ini_get('session.use_strict_mode') === '1', 'Rejects uninitialized session IDs.'];
    $checks[] = ['HTTP-only session cookie', ini_get('session.cookie_httponly') === '1', 'JavaScript cannot read the session cookie.'];
    $checks[] = ['Only-cookie sessions', ini_get('session.use_only_cookies') === '1', 'Session IDs are not accepted from URLs.'];
    $defaultPasswordChanged = false;
    try {
        $hash = db()->query('SELECT password_hash FROM admin_users WHERE username=\'admin\' LIMIT 1')->fetchColumn();
        $defaultPasswordChanged = $hash ? !password_verify('Admin@12345', (string)$hash) : true;
    } catch (Throwable $e) { $defaultPasswordChanged = false; }
    $checks[] = ['Default admin password changed', $defaultPasswordChanged, 'Change Admin@12345 immediately after installation.'];
    $checks[] = ['Admin CSP active', true, 'Admin panel uses stricter frame and script policies.'];
    return $checks;
}

function security_status_badge(bool $ok): string
{
    return $ok ? '<span class="sec-badge ok">Protected</span>' : '<span class="sec-badge bad">Needs action</span>';
}
