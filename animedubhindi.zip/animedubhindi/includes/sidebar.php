<?php require_once __DIR__ . '/functions.php';
$showFeatured = setting('sidebar_featured_enabled', '1') === '1';
$featuredAnime = $showFeatured ? fetch_featured_sidebar((int)setting('sidebar_featured_limit','5')) : [];
$showFeatured = $showFeatured && !empty($featuredAnime);
$showSocial = setting('social_box_enabled', '1') === '1';
$showAd = setting('ad_enabled', '0') === '1' && (setting('ad_html', '') !== '' || setting('ad_image', '') !== '' || setting('show_empty_ad_box', '0') === '1');
$showAdControl = has_ad_control_sidebar();
$showMenuLinks = setting('sidebar_menu_links_enabled', '1') === '1';
$sidebarMenus = $showMenuLinks ? get_menus() : [];
$showSubmenuLinks = setting('sidebar_menu_children_enabled', '1') === '1';
$showCopyButtons = setting('sidebar_menu_copy_enabled', '1') === '1';

$sidebarBlocks = [];
$addSidebarBlock = function(string $key, int $order, string $html) use (&$sidebarBlocks) {
  $sidebarBlocks[] = ['key' => $key, 'order' => $order, 'html' => $html];
};

if ($showFeatured) {
  ob_start(); ?>
  <div class="side-card featured-side-card" data-featured-slider>
    <div class="featured-head"><span><?= e(setting('sidebar_featured_label','Featured')) ?></span><h3><?= e(setting('sidebar_featured_title','Top Picks')) ?></h3></div>
    <div class="featured-slider-track">
      <?php foreach ($featuredAnime as $idx => $fa): ?>
      <a class="featured-slide <?= $idx===0?'active':'' ?>" href="<?= e(anime_link($fa)) ?>">
        <img src="<?= e(cover_url($fa['cover_image'] ?? null)) ?>" alt="<?= e($fa['title']) ?>">
        <div><b><?= e($fa['title']) ?></b></div>
      </a>
      <?php endforeach; ?>
    </div>
    <?php if (count($featuredAnime) > 1): ?><div class="featured-dots"><?php foreach($featuredAnime as $idx=>$fa): ?><button type="button" class="<?= $idx===0?'active':'' ?>" data-featured-dot="<?= $idx ?>" aria-label="Featured <?= $idx+1 ?>"></button><?php endforeach; ?></div><?php endif; ?>
  </div>
  <?php $addSidebarBlock('featured', (int)setting('sidebar_order_featured','10'), ob_get_clean());
}

if ($showSocial) {
  ob_start(); ?>
  <div class="side-card social-side-card channel-card-clean">
    <h3>Join our channels</h3>
    <p>Fast release alerts and community notices.</p>
    <div class="channel-row-list">
      <a class="channel-row whatsapp" href="<?= e(setting('whatsapp_link','https://whatsapp.com/channel/0029VbCnnx96GcGDAZxFLZ2j')) ?>" target="_blank" rel="nofollow noopener">
        <span class="channel-logo"><img src="<?= e(asset('img/whatsapp-logo.svg')) ?>" alt="WhatsApp"></span>
        <span><b>WhatsApp Channel</b><small>Follow updates</small></span>
        <em>↗</em>
      </a>
      <a class="channel-row telegram" href="<?= e(setting('telegram_sidebar_link', setting('telegram_link','https://t.me/animedubhindixyz'))) ?>" target="_blank" rel="nofollow noopener">
        <span class="channel-logo"><img src="<?= e(asset('img/telegram-logo.svg')) ?>" alt="Telegram"></span>
        <span><b>Telegram Channel</b><small>Join community</small></span>
        <em>↗</em>
      </a>
    </div>
  </div>
  <?php $addSidebarBlock('channels', (int)setting('sidebar_order_channels','20'), ob_get_clean());
}

if ($showAdControl) {
  ob_start(); ?>
  <div class="side-card ad-control-side-card" data-ad-control-card>
    <h3><?= e(setting('ad_code_sidebar_title', 'Sponsored')) ?></h3>
    <div class="ad-control-render"><?php render_ad_placement('sidebar'); ?></div>
  </div>
  <?php $addSidebarBlock('ad_control', (int)setting('sidebar_order_ad_control','30'), ob_get_clean());
}

if ($showAd) {
  ob_start(); ?>
  <div class="side-card" data-ad-card data-refresh-enabled="<?= e(setting('ad_refresh_enabled','0')) ?>" data-refresh-seconds="<?= e(setting('ad_refresh_seconds','60')) ?>">
    <h3><?= e(setting('ad_title', 'Advertisement')) ?></h3>
    <?php if (setting('ad_html')): ?>
      <?= setting('ad_html') ?>
    <?php elseif (setting('ad_image')): ?>
      <a class="ad-box" href="<?= e(setting('ad_url', '#')) ?>" target="_blank" rel="nofollow noopener"><img src="<?= e(setting('ad_image')) ?>" alt="Advertisement"></a>
    <?php else: ?>
      <div class="ad-placeholder">Advertisement space</div>
    <?php endif; ?>
  </div>
  <?php $addSidebarBlock('advertisement', (int)setting('sidebar_order_advertisement','40'), ob_get_clean());
}

if ($showMenuLinks && !empty($sidebarMenus)) {
  ob_start(); ?>
  <div class="side-card side-menu-links-card">
    <div class="side-card-head">
      <h3>Site Menu</h3>
      <p>Quick public links for sharing or copying.</p>
    </div>
    <div class="site-link-list">
      <?php foreach ($sidebarMenus as $menu): ?>
        <?php $mainPath = $menu['url'] ?: ($menu['slug'] ?: '#'); $mainUrl = ($mainPath && $mainPath !== '#') ? absolute_site_url($mainPath) : ''; ?>
        <div class="site-link-item <?= !empty($menu['children']) ? 'has-children' : '' ?>">
          <div class="site-link-main">
            <?php if ($mainUrl): ?><a href="<?= e($mainUrl) ?>"><?= e($menu['label']) ?></a><?php else: ?><span class="site-link-label"><?= e($menu['label']) ?></span><?php endif; ?>
            <?php if ($mainUrl && $showCopyButtons): ?><button type="button" class="copy-link-btn" data-copy-link="<?= e($mainUrl) ?>" aria-label="Copy <?= e($menu['label']) ?> link">Copy</button><?php elseif (!$mainUrl): ?><em class="menu-only-pill">Menu</em><?php endif; ?>
          </div>
          <?php if ($showSubmenuLinks && !empty($menu['children'])): ?>
            <div class="site-sub-link-list">
              <?php foreach ($menu['children'] as $child): ?>
                <?php $childPath = $child['url'] ?: ($child['slug'] ?: '#'); $childUrl = ($childPath && $childPath !== '#') ? absolute_site_url($childPath) : ''; ?>
                <div class="site-sub-link-item">
                  <?php if ($childUrl): ?><a href="<?= e($childUrl) ?>"><?= e($child['label']) ?></a><?php else: ?><span><?= e($child['label']) ?></span><?php endif; ?>
                  <?php if ($childUrl && $showCopyButtons): ?><button type="button" class="copy-link-btn mini" data-copy-link="<?= e($childUrl) ?>" aria-label="Copy <?= e($child['label']) ?> link">Copy</button><?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php $addSidebarBlock('site_menu', (int)setting('sidebar_order_site_menu','50'), ob_get_clean());
}

usort($sidebarBlocks, function($a, $b) {
  if ($a['order'] === $b['order']) return strcmp($a['key'], $b['key']);
  return $a['order'] <=> $b['order'];
});
?>
<?php if (!empty($sidebarBlocks)): ?>
<aside class="sidebar" data-sidebar-order="custom">
  <?php foreach ($sidebarBlocks as $block): ?>
    <?= $block['html'] ?>
  <?php endforeach; ?>
</aside>
<?php endif; ?>
