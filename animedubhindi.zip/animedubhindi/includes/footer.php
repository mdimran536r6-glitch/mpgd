<?php require_once __DIR__ . '/functions.php'; ?>
<?php if (ad_control_code('before_footer') !== ''): ?><section class="ad-control-before-footer"><div class="container ad-control-render"><?php render_ad_placement('before_footer'); ?></div></section><?php endif; ?>
<?php $brandIcon = setting('brand_icon_url',''); $brandIcon = $brandIcon ?: asset('img/anime-logo-icon.svg'); ?>
<footer class="site-footer">
  <div class="container footer-main">
    <?php if(setting('footer_about_enabled','1')==='1'): ?><div class="footer-col footer-about">
      <div class="footer-logo-line footer-brand-pro"><span class="footer-art"><img src="<?= e($brandIcon) ?>" alt=""></span><div><div class="footer-brand"><?= brand_name_html(setting('site_name', 'AnimeDubHindi')) ?></div></div></div>
      <p><?= e(setting('footer_about', 'AnimeDubHindi is a clean anime update platform for release details, episode lists and community notices.')) ?></p>
    </div><?php endif; ?>
    <?php if(setting('footer_quick_links_enabled','1')==='1'): ?><div class="footer-col">
      <h4>Quick Links</h4>
      <a href="<?= e(url('index.php')) ?>">Home</a>
      <a href="<?= e(url('movies.php')) ?>">Movies</a>
      <a href="<?= e(url('series.php')) ?>">Series</a>
      <a href="<?= e(url('genres.php')) ?>">Genres</a>
      <a href="<?= e(url('search.php')) ?>">Search Anime</a>
    </div><?php endif; ?>
    <?php if(setting('footer_support_enabled','1')==='1'): ?><div class="footer-col">
      <h4>Support</h4>
      <a href="<?= e(url('request.php')) ?>">Request Anime</a>
      <a href="<?= e(url('report.php')) ?>">Report Broken Link</a>
      <a href="<?= e(url('contact.php')) ?>">Contact Us</a>
      <a href="<?= e(setting('telegram_link', '#')) ?>" target="_blank" rel="nofollow noopener">Telegram Channel</a>
      <a href="<?= e(setting('whatsapp_link', '#')) ?>" target="_blank" rel="nofollow noopener">WhatsApp Channel</a>
    </div><?php endif; ?>
    <?php if(setting('footer_legal_enabled','1')==='1'): ?><div class="footer-col">
      <h4>Legal</h4>
      <a href="<?= e(url('about.php')) ?>">About Us</a>
      <a href="<?= e(url('privacy.php')) ?>">Privacy Policy</a>
      <a href="<?= e(url('terms.php')) ?>">Terms & Conditions</a>
      <a href="<?= e(url('dmca.php')) ?>">DMCA / Copyright</a>
      <a href="<?= e(url('disclaimer.php')) ?>">Disclaimer</a>
      <a href="<?= e(url('cookie.php')) ?>">Cookie Policy</a>
    </div><?php endif; ?>
    <?php if(setting('footer_community_enabled','1')==='1'): ?><div class="footer-col footer-community-cta">
      <h4>Community</h4>
      <p>Follow the official channels for release alerts, requests and important notices.</p>
      <a class="footer-channel-btn telegram" href="<?= e(setting('telegram_link', '#')) ?>" target="_blank" rel="nofollow noopener"><img src="<?= e(asset('img/telegram-logo.svg')) ?>" alt="">Join Telegram</a>
      <a class="footer-channel-btn whatsapp" href="<?= e(setting('whatsapp_link', '#')) ?>" target="_blank" rel="nofollow noopener"><img src="<?= e(asset('img/whatsapp-logo.svg')) ?>" alt="">Follow WhatsApp</a>
    </div><?php endif; ?>
  </div>
  <div class="footer-bottom"><div class="container"><span><?= e(setting('footer_copyright_text', '') ?: ('Copyright © ' . date('Y') . ' ' . setting('site_name', 'AnimeDubHindi') . '. All rights reserved.')) ?></span></div></div>
</footer>
<?php if(setting('back_to_top_enabled','1')==='1'): ?><button class="back-top" type="button" aria-label="Back to top" onclick="window.scrollTo({top:0,behavior:'smooth'})">↑</button><?php endif; ?>
<?php if (setting('telegram_popup_enabled', '1') === '1'): ?>
<div class="telegram-popup community-popup" id="telegramPopup">
  <button class="popup-close" onclick="closeTelegramPopup()">×</button>
  <div class="popup-icon dual-icons"><img src="<?= e(asset('img/telegram-logo.svg')) ?>" alt="Telegram"><img src="<?= e(asset('img/whatsapp-logo.svg')) ?>" alt="WhatsApp"></div>
  <h3>Join official channels</h3>
  <p><?= e(setting('telegram_popup_text', 'Get new episode updates and announcements.')) ?></p>
  <div class="popup-actions">
    <a class="btn popup-telegram" href="<?= e(setting('telegram_link', '#')) ?>" target="_blank" rel="nofollow noopener">Telegram</a>
    <a class="btn popup-whatsapp" href="<?= e(setting('whatsapp_link', '#')) ?>" target="_blank" rel="nofollow noopener">WhatsApp</a>
  </div>
</div>
<?php endif; ?>
<?php render_ad_placement('popunder'); ?>
<?php render_ad_placement('socialbar'); ?>
<?php render_ad_placement('chat'); ?>
<?php render_ad_placement('body_end'); ?>
<?php render_seo_body_end_codes(); ?>
<script src="<?= e(asset('js/main.js')) ?>?v=share-button-final"></script>
</body>
</html>
