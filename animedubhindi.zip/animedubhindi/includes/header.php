<?php require_once __DIR__ . '/functions.php';
if (setting('maintenance_enabled', '0') === '1' && !str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/admin/')) {
  $brandIcon = setting('brand_icon_url','') ?: asset('img/anime-logo-icon.svg');
  ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maintenance - <?= e(setting('site_name','AnimeDubHindi')) ?></title><link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>?v=admin-control-final"></head><body><main class="maintenance-page"><div class="maintenance-card"><img src="<?= e($brandIcon) ?>" alt=""><h1><?= brand_name_html(setting('site_name','AnimeDubHindi')) ?></h1><p><?= e(setting('maintenance_message','We are updating the website. Please check back soon.')) ?></p></div></main></body></html><?php exit;
}
$menus = get_menus(); if (!$menus) { $menus = [['label'=>'Home','url'=>'index.php','slug'=>'','children'=>[]],['label'=>'Movie','url'=>'movies.php','slug'=>'','children'=>[]],['label'=>'Series','url'=>'series.php','slug'=>'','children'=>[]],['label'=>'Genres','url'=>'genres.php','slug'=>'','children'=>[]],['label'=>'Request Anime','url'=>'request.php','slug'=>'','children'=>[]]]; } $brandIcon = setting('brand_icon_url',''); $brandIcon = $brandIcon ?: asset('img/anime-logo-icon.svg'); ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($page_title ?? setting('site_name', 'AnimeDubHindi')) ?></title>
  <meta name="description" content="<?= e($page_description ?? setting('site_description', 'Anime release updates, episode links and download pack information.')) ?>">
<?php render_basic_seo_tags($page_title ?? null, $page_description ?? null, $page_image ?? null); ?>
<?php render_seo_custom_head_codes(); ?>
  <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>?v=share-button-final">
<?php render_ad_placement('head'); ?>
<?php render_website_schema(); ?>
<script>window.ADH_BASE_URL='<?= e(url('')) ?>';</script>
</head>
<body>
<?php render_seo_body_start_codes(); ?>
<?php render_ad_placement('body_start'); ?>
<div class="site-topbar" <?= setting('smart_header_enabled','1')==='1' ? 'data-smart-header' : '' ?>>
<header class="site-header">
  <div class="container header-inner">
    <button class="mobile-menu" type="button" aria-label="Open menu" onclick="openMobileMenu()"><span></span><span></span><span></span></button>
    <a class="brand brand-pro" href="<?= e(url('index.php')) ?>" aria-label="<?= e(setting('site_name', 'AnimeDubHindi')) ?> Home">
      <span class="brand-art" aria-hidden="true"><img src="<?= e($brandIcon) ?>" alt=""></span>
      <span class="brand-text"><b class="brand-name"><?= brand_name_html(setting('site_name', 'AnimeDubHindi')) ?></b></span>
    </a>
    <nav class="nav">
      <?php if ($menus): foreach ($menus as $menu): ?>
        <div class="nav-parent">
          <a class="nav-item" href="<?= e($menu['url'] ?: url($menu['slug'] ?: '#')) ?>"><?= e($menu['label']) ?><?= !empty($menu['children']) ? ' <span class="arrow">▾</span>' : '' ?></a>
          <?php if (!empty($menu['children'])): ?><div class="nav-dropdown">
            <?php foreach ($menu['children'] as $child): ?><a href="<?= e($child['url'] ?: url($child['slug'] ?: '#')) ?>"><?= e($child['label']) ?></a><?php endforeach; ?>
          </div><?php endif; ?>
        </div>
      <?php endforeach; else: ?>
        <a class="nav-item" href="<?= e(url('index.php')) ?>">Home</a>
        <a class="nav-item" href="<?= e(url('movies.php')) ?>">Movie</a>
        <a class="nav-item" href="<?= e(url('series.php')) ?>">Series</a>
        <a class="nav-item" href="<?= e(url('genres.php')) ?>">Genres</a>
        <a class="nav-item" href="<?= e(url('request.php')) ?>">Request Anime</a>
      <?php endif; ?>
    </nav>
    <?php if (setting('header_search_enabled','1') === '1'): ?>
    <form class="desktop-search suggest-search" action="<?= e(url('search.php')) ?>" method="get" data-suggest-url="<?= e(url('search-suggest.php')) ?>">
      <input class="suggest-input" name="q" autocomplete="off" placeholder="Search anime..." value="<?= e($_GET['q'] ?? '') ?>">
      <button class="icon-btn" type="submit" aria-label="Search">⌕</button>
      <div class="suggest-box" role="listbox"></div>
    </form>
    <button class="icon-btn mobile-search-btn" type="button" aria-label="Search" onclick="document.querySelector('.search-overlay').classList.add('open')">⌕</button>
    <?php endif; ?>
  </div>
</header>
</div>
<?php if (setting('header_telegram_strip_enabled','1') === '1'): ?>
<section class="telegram-strip telegram-strip-static">
  <div class="container">
    <span><?= e(setting('telegram_text', 'For more updates join our Telegram channel')) ?></span>
    <a class="btn" href="<?= e(setting('telegram_link', '#')) ?>" target="_blank" rel="nofollow noopener">Join Telegram</a>
  </div>
</section>
<?php endif; ?>
<?php if (ad_control_code('under_header') !== ''): ?><section class="ad-control-under-header"><div class="container ad-control-render"><?php render_ad_placement('under_header'); ?></div></section><?php endif; ?>
<aside class="mobile-panel">
  <button class="mobile-close" onclick="closeMobileMenu()">×</button>
  <div class="mobile-panel-title"><img src="<?= e($brandIcon) ?>" alt=""> <span><?= brand_name_html(setting('site_name','AnimeDubHindi')) ?></span></div>
  <div class="mobile-menu-scroll">
  <?php foreach ($menus as $menu): ?>
    <?php if (!empty($menu['children'])): ?>
      <div class="mobile-menu-group">
        <button type="button" class="mobile-parent" data-mobile-submenu><?= e($menu['label']) ?><span>▾</span></button>
        <div class="mobile-submenu">
          <?php foreach ($menu['children'] as $child): ?><a class="mobile-child" href="<?= e($child['url'] ?: url($child['slug'] ?: '#')) ?>"><?= e($child['label']) ?></a><?php endforeach; ?>
        </div>
      </div>
    <?php else: ?>
      <a class="mobile-parent-link" href="<?= e($menu['url'] ?: url($menu['slug'] ?: '#')) ?>"><?= e($menu['label']) ?></a>
    <?php endif; ?>
  <?php endforeach; ?>
  </div>
</aside>
<div class="mobile-backdrop" onclick="closeMobileMenu()" aria-hidden="true"></div>
<?php if (setting('header_search_enabled','1') === '1'): ?>
<div class="search-overlay">
  <div class="search-modal">
    <button class="close-search" onclick="document.querySelector('.search-overlay').classList.remove('open')">×</button>
    <h3>Search Anime</h3>
    <form class="search-box suggest-search" action="<?= e(url('search.php')) ?>" method="get" data-suggest-url="<?= e(url('search-suggest.php')) ?>">
      <input class="suggest-input" name="q" autocomplete="off" placeholder="Type anime title...">
      <button>Search</button>
      <div class="suggest-box" role="listbox"></div>
    </form>
  </div>
</div>
<?php endif; ?>
