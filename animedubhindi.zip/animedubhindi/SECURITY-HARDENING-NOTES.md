# Security hardening notes

This release includes practical hardening for shared hosting/cPanel PHP deployment. No public website can be guaranteed 100% unhackable, but these controls reduce common risks.

## Included
- Admin login rate limiting
- Admin session timeout, ID regeneration and user re-validation
- CSRF tokens on admin and public forms
- Upload validation for cover images only
- PHP execution blocked in uploads
- Sensitive folders blocked by .htaccess
- Direct access blocked for config, database, includes and storage
- Security headers
- Installer lock on live hosting
- Security Center page inside admin panel
- Security/login audit logs with hashed visitor data

## After live upload
1. Run install.php once.
2. Change the admin password.
3. Delete or rename install.php and install-check.php.
4. Enable HTTPS/SSL.
5. Use a strong database password.
6. Keep backups private and outside public_html.
