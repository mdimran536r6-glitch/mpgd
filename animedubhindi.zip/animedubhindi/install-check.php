<?php
require_once __DIR__ . '/config.php';
$checks = [];
$checks[] = ['PHP version', PHP_VERSION, version_compare(PHP_VERSION, '8.0.0', '>=')];
$checks[] = ['PDO MySQL extension', extension_loaded('pdo_mysql') ? 'Loaded' : 'Missing', extension_loaded('pdo_mysql')];
$checks[] = ['Uploads folder', is_dir(__DIR__.'/uploads/covers') ? 'Found' : 'Missing', is_dir(__DIR__.'/uploads/covers')];
try { require_once __DIR__ . '/includes/db.php'; $server = db_server(); $server->query('SELECT 1'); $checks[]=['MySQL connection','Connected',true]; } catch(Throwable $e) { $checks[]=['MySQL connection',$e->getMessage(),false]; }
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install Check</title><style>body{font-family:system-ui;background:#eef6f7;margin:0}.box{max-width:900px;margin:40px auto;background:#fff;border-radius:20px;padding:30px}.ok{color:#047857}.bad{color:#b91c1c}td{padding:10px;border-bottom:1px solid #ddd}.btn{display:inline-block;background:#0d8f88;color:white;padding:12px 18px;border-radius:12px;text-decoration:none;font-weight:800}</style></head><body><div class="box"><h1>AnimeDubHindi Install Check</h1><table><?php foreach($checks as $c): ?><tr><td><b><?= htmlspecialchars($c[0]) ?></b></td><td><?= htmlspecialchars($c[1]) ?></td><td class="<?= $c[2]?'ok':'bad' ?>"><?= $c[2]?'OK':'Fix needed' ?></td></tr><?php endforeach; ?></table><p><a class="btn" href="install.php">Open Installer</a> <a class="btn" href="admin/">Open Admin</a></p></div></body></html>
