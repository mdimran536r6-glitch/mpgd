# Watch Online Guide

## Admin panel থেকে link যোগ করার নিয়ম

1. Admin → Episode Links খুলুন।
2. Anime select করুন।
3. Episode না থাকলে আগে episode add করুন।
4. Add Episode Link ফর্মে:
   - Button Type: `Watch Online`
   - Quality: খালি রাখুন
   - Host Name: `Online Player` / `Pixeldrain` / `Bunny Stream`
   - External URL: ভিডিও link দিন
5. Save করুন।

Anime details page-এ প্রতিটা episode card-এর সবার উপরে মাঝখানে `Watch Online` button দেখাবে। Button click করলে `watch.php` player page খুলবে।

## কোন link দিলে player কাজ করবে

- Direct `.mp4`, `.webm`, `.ogg` video URL সবচেয়ে সহজে HTML5 player-এ চলে।
- Pixeldrain share URL যেমন `https://pixeldrain.com/u/FILEID` দিলে website এটাকে `https://pixeldrain.com/api/file/FILEID` হিসেবে player-এ চালানোর চেষ্টা করবে।
- Google Drive file link দিলে preview iframe হিসেবে চালানোর চেষ্টা করবে।
- Bunny Stream / Cloudflare Stream embed URL দিলে iframe player হিসেবে খুলবে।

কোনো host iframe বা hotlink block করলে player page-এ `Open source link` backup button থাকবে।
