# AnimeDubHindi Website

A cPanel/XAMPP ready PHP + MySQL anime update website with a connected admin panel.

## Main features

- Professional light/minimal frontend
- Header with polished AnimeDubHindi logo and original anime-style icon
- Header hides when scrolling down and returns when scrolling up
- Desktop search bar with live cover/title suggestions
- Mobile search icon and scrollable mobile menu with expandable submenus
- Latest Releases with pinned posts first and Load More
- Anime details page with synopsis, one-column anime information, episode links, ZIP packs and related anime
- Episode links support Download and Watch Online buttons
- ZIP/Pack section supports multiple parts such as EP 01-06, EP 07-12, Full Season
- Sidebar WhatsApp and Telegram channel cards with logo icons
- Advertisement section can be enabled/disabled from admin
- Footer has Telegram and WhatsApp community buttons
- Admin panel controls anime posts, episode links, ZIP packs, header menus, settings, requests and reports
- Admin episode manager is accordion/card based, not a wide table
- Admin keeps scroll position after saving forms

## Localhost installation

1. Delete old folder:

```text
C:\xampp\htdocs\animedubhindi
```

2. Extract ZIP and copy the new folder:

```text
C:\xampp\htdocs\animedubhindi
```

3. Start XAMPP Apache and MySQL.

4. Run installer:

```text
http://localhost/animedubhindi/install.php
```

5. Click **Install / Repair Database**.

6. Open website:

```text
http://localhost/animedubhindi/
```

7. Open admin:

```text
http://localhost/animedubhindi/admin/
```

Default login:

```text
Username: admin
Password: Admin@12345
```

Change the admin password after first login.

## Admin settings

Go to **Site Settings** to control:

- Site name
- Optional brand icon URL
- Telegram strip text/link
- WhatsApp channel link
- Telegram channel link
- Sidebar social box on/off
- Advertisement on/off
- Advertisement refresh timing
- Latest Releases visible count
- You May Also Like post count
- Upcoming message text
- Footer text

## Episode manager

Go to **Episode Links**:

1. Select anime from the anime list.
2. Add episode number and upload date.
3. Add Download or Watch Online links for each episode.
4. Add ZIP/Pack parts if needed.
5. Hide/show/delete episodes, links and ZIP packs anytime.

## Notes

This website stores only external links and information. It does not upload or host anime files on your server.


## Watch Online / Player links
Use Admin → Episode Links and add a link with Button Type = Watch Online. Pixeldrain file URLs and direct .mp4/.webm links will try to play inside the website player. If a host blocks embedding, visitors will still see an Open Original Link button.

## Sidebar Featured Anime
Mark any anime as Featured from Anime Posts. Then enable Sidebar Featured Anime from Site Settings to show a small rotating card above WhatsApp/Telegram and ads.


## Watch Online Player

See `WATCH-ONLINE-GUIDE.md` for supported video link types and admin setup.


## Demo anime content

The installer includes starter anime posts, sample covers, episodes, Watch Online links, download links and ZIP packs so the website has content after installation. You can edit, hide, pin or delete any post from the admin panel.


## Scroll Position Behavior

- Admin forms now keep the same scroll position after save, hide/show, pin/unpin, or delete actions.
- Anime details pages remember the episode area when you open Watch Online and return/back to the episode list.
- Use normal browser Back or the “Back to episodes” button on the player page.

## Smooth Back Navigation
This build includes site-wide scroll memory. When a visitor opens an anime post, watch page, search result, menu item, or legal page and then presses the browser Back button, the website returns them to the same scroll position instead of jumping to the top.


## Analytics Panel

Admin → Analytics shows a professional overview of website activity:

- Page views
- Anime detail views
- Watch Online clicks
- Episode download clicks
- ZIP/pack download clicks
- Search activity
- Requests and broken-link reports
- Top anime posts
- Top pages
- Device split
- Recent activity feed
- CSV export

Run `install.php` after uploading this version so the `analytics_events` table is created. Analytics can be turned on/off from Admin → Site Settings.

Privacy note: analytics stores a one-way IP hash for basic abuse/unique-visitor analysis. It does not store raw IP addresses.


## Live website URL

Default live URL is `https://www.animedubhindi.xyz`. Change it from Admin → Site Settings → Live Website URL if needed. Sidebar menu links use this URL for copy buttons.


## Ad Control

Use **Admin → Ad Control** to paste and enable/disable Adsterra, Monetag, popunder, social bar, sidebar/native ad, floating chat, head verification, and body-end scripts. See `AD-CONTROL-GUIDE.md` for placement instructions.
