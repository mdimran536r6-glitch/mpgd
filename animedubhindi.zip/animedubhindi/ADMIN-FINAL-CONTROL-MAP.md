# AnimeDubHindi Final Admin Control Map

This release keeps the public website and admin panel connected to the same MySQL database. Changes made in admin are reflected on the main website automatically.

## Main admin menus

- Dashboard: overview, anime list and quick actions.
- Control Center: fast website-wide switches for pages, header, homepage, details, sidebar, footer, analytics and defaults.
- Layout Control: change sidebar block order with up/down arrows and show/hide sidebar blocks.
- Anime Posts: add/edit anime, draft/publish/unpublish, pin, featured, ZIP section and SEO fields.
- Bulk Control: update many anime posts at once.
- Episode Links: add/edit/hide/show episodes, Watch Online links, download links and ZIP packs.
- Featured Anime: manually choose exactly which anime appears in the sidebar slider.
- Header Menus: control main menus and submenus.
- Advanced Settings: detailed settings and fine tuning.
- SEO Control: robots.txt, sitemap, verification, analytics scripts, schema and social preview settings.
- Ad Control: Adsterra/Monetag/social bar/popunder/native/sidebar/custom scripts by placement.
- Analytics: clean summary boxes only.
- Website Tools: exports, cleanup, robots/sitemap check and maintenance tools.
- Security: security checks and admin safety notes.
- Requests/Reports: visitor requests and broken link reports with pagination/search.
- Password: change the admin password.

## Bulk Control actions

Bulk Control lets you select many anime posts and apply one action:

- Publish selected
- Move selected to draft
- Unpublish selected
- Pin/unpin selected
- Add/remove selected posts from Featured Anime
- Show/hide ZIP section
- Mark anime status as Ongoing, Completed or Upcoming

## Release checklist

1. Upload files to `public_html` or the correct subfolder.
2. Run `install.php` once.
3. Change the default admin password immediately.
4. Set `Live Website URL` to `https://www.animedubhindi.xyz`.
5. Configure SEO Control and submit sitemap to Google/Bing.
6. Delete or rename installer files on live hosting.
7. Keep backups before bulk editing or deleting content.
