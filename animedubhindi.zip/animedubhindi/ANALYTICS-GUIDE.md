# Analytics Guide

The Analytics panel is intentionally kept clean and lightweight.

## What it shows

- 8 summary boxes at the top
- Event Breakdown
- Traffic Graph
- Date range filter: Today, 7 Days, 30 Days, All Time
- Compact large numbers such as 1.2K, 5.4M and 1.1B
- Download Summary CSV

## What is tracked

- Page views
- Anime details views
- Watch Online clicks
- Episode download clicks
- ZIP / pack download clicks
- Search activity
- Request submits
- Broken-link report submits

## Privacy

The analytics system does not store raw IP addresses. It keeps only simple event counts needed for the admin dashboard.

## Setup

After uploading the site, run:

`/install.php`

Then click **Install / Repair Database** to create or update the analytics table.
