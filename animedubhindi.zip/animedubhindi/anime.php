<?php
require_once __DIR__ . '/includes/functions.php';

$slug = trim($_GET['slug'] ?? '');
$id = (int)($_GET['id'] ?? 0);
$previewMode = !empty($_GET['preview']) && is_admin_logged_in();
$statusSql = $previewMode ? '1' : "COALESCE(content_status,'published')='published'";

if ($slug !== '') {
    $stmt = db()->prepare('SELECT * FROM anime WHERE slug = ? AND ' . $statusSql . ' LIMIT 1');
    $stmt->execute([$slug]);
} elseif ($id > 0) {
    $stmt = db()->prepare('SELECT * FROM anime WHERE id = ? AND ' . $statusSql . ' LIMIT 1');
    $stmt->execute([$id]);
} else {
    $stmt = db()->query("SELECT * FROM anime WHERE COALESCE(content_status,'published')='published' ORDER BY is_pinned DESC, published_at DESC, id DESC LIMIT 1");
}

$anime = $stmt->fetch();
if (!$anime) {
    http_response_code(404);
    $page_title = 'Anime not found';
    require __DIR__ . '/includes/header.php';
    echo '<main class="container main-wrap no-sidebar"><section class="content-card"><div class="empty-state">Anime not found. Please check the link or browse the latest releases.</div></section></main>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

db()->prepare('UPDATE anime SET views = views + 1 WHERE id = ?')->execute([(int)$anime['id']]);
track_event('anime_view', ['anime_id'=>(int)$anime['id'], 'title'=>$anime['title'] ?? '', 'page_url'=>$_SERVER['REQUEST_URI'] ?? '']);
$page_title = ($anime['seo_title'] ?: $anime['title']) . ' - ' . setting('site_name', 'AnimeDubHindi');
$page_description = $anime['seo_description'] ?: excerpt($anime['synopsis'] ?? '', 155);

$epStmt = db()->prepare('SELECT * FROM episodes WHERE anime_id = ? AND is_active = 1 ORDER BY sort_order ASC, episode_number ASC, id ASC');
$epStmt->execute([(int)$anime['id']]);
$episodes = $epStmt->fetchAll();

$linksByEpisode = [];
if ($episodes) {
    $episodeIds = array_column($episodes, 'id');
    $in = implode(',', array_fill(0, count($episodeIds), '?'));
    $lstmt = db()->prepare("SELECT * FROM episode_links WHERE is_active = 1 AND episode_id IN ($in) ORDER BY sort_order ASC, quality DESC, host_name ASC, id ASC");
    $lstmt->execute($episodeIds);
    foreach ($lstmt->fetchAll() as $link) {
        $linksByEpisode[(int)$link['episode_id']][] = $link;
    }
}

$zipStmt = db()->prepare('SELECT * FROM full_season_links WHERE anime_id = ? AND is_active = 1 ORDER BY sort_order ASC, id ASC');
$zipStmt->execute([(int)$anime['id']]);
$zipLinks = $zipStmt->fetchAll();
$showZipSection = (int)($anime['show_zip_section'] ?? 1) === 1;
$isMovie = strtolower((string)($anime['type'] ?? '')) === 'movie';

$watchLanguageLabels = [];
$downloadQualityLabels = [];
foreach ($linksByEpisode as $episodeLinkGroup) {
    foreach ($episodeLinkGroup as $oneLink) {
        if (($oneLink['link_type'] ?? 'download') === 'watch') {
            $label = trim((string)($oneLink['host_name'] ?? ''));
            $label = preg_replace('/\s+/', ' ', $label);
            $label = trim((string)$label);
            if ($label !== '' && !preg_match('/^(watch online|online player|player|server)$/i', $label)) {
                $watchLanguageLabels[] = $label;
            }
        } else {
            $quality = trim((string)($oneLink['quality'] ?? ''));
            if ($quality !== '' && !preg_match('/api/i', $quality)) $downloadQualityLabels[] = $quality;
        }
    }
}
$watchLanguageLabels = array_values(array_unique($watchLanguageLabels));
$downloadQualityLabels = array_values(array_unique($downloadQualityLabels));
$displayLanguages = $watchLanguageLabels ? implode(' | ', $watchLanguageLabels) : (trim((string)($anime['language'] ?? '')) ?: 'Not specified');
$displayQuality = $downloadQualityLabels ? implode(', ', $downloadQualityLabels) : trim((string)($anime['quality'] ?? ''));
if ($displayQuality === '' || preg_match('/api/i', $displayQuality)) $displayQuality = 'Online';
$releaseRaw = trim((string)($anime['release_year'] ?? ''));
$releaseTs = $releaseRaw !== '' ? strtotime($releaseRaw) : false;
$displayReleaseDate = $releaseTs ? date('F j, Y', $releaseTs) : ($releaseRaw !== '' ? $releaseRaw : 'N/A');
$displayPublishedDate = !empty($anime['published_at']) ? date('F j, Y', strtotime($anime['published_at'])) : 'N/A';

$similarLimit = max(3, min(12, (int)setting('similar_posts_limit','6')));
$similar = fetch_anime_list('id != ? AND (type = ? OR language = ? OR genres LIKE ?)', [(int)$anime['id'], $anime['type'] ?? '', $anime['language'] ?? '', '%' . trim((string)($anime['genres'] ?? '')) . '%'], $similarLimit);
$layoutClass = has_sidebar() ? '' : ' no-sidebar';
require __DIR__ . '/includes/header.php';
?>
<main class="container main-wrap detail-layout<?= e($layoutClass) ?>">
  <article class="content-card anime-detail-card">
    <?php if($previewMode): ?><div class="preview-notice"><b>Preview Mode</b><span>This post is visible only to admin until it is published.</span></div><?php endif; ?>
    <?php if (ad_control_code('before_anime_content') !== ''): ?><section class="ad-control-site-slot ad-before-anime-content"><div class="ad-control-render"><?php render_ad_placement('before_anime_content'); ?></div></section><?php endif; ?>
    <?php if(setting('details_breadcrumb_enabled','1')==='1'): ?><div class="breadcrumb"><a href="<?= e(url('index.php')) ?>">Home</a><span>›</span><a href="<?= e(url((($anime['type'] ?? 'Series') === 'Movie') ? 'movies.php' : 'series.php')) ?>"><?= e($anime['type'] ?: 'Series') ?></a><span>›</span><b><?= e($anime['title']) ?></b></div><?php endif; ?>

    <h1 class="detail-title"><?= e($anime['title']) ?></h1>
    <?php if(setting('details_meta_enabled','1')==='1'): ?><div class="detail-meta"><span>Posted by <?= e($anime['published_by'] ?: setting('site_name','AnimeDubHindi')) ?></span><span>/</span><span><?= e(date('M j, Y', strtotime($anime['published_at'] ?? 'now'))) ?></span></div><?php endif; ?>
    <?php if(setting('details_share_enabled','1')==='1'): $shareUrl = absolute_site_url('anime.php?slug=' . urlencode($anime['slug'] ?? '')); ?>
      <div class="detail-share-bar">
        <button type="button" class="share-anime-btn" data-share-title="<?= e($anime['title']) ?>" data-share-url="<?= e($shareUrl) ?>" data-share-text="<?= e('Check this anime on ' . setting('site_name','AnimeDubHindi')) ?>">
          <span class="share-icon">↗</span><span>Share Anime</span>
        </button>
      </div>
    <?php endif; ?>

    <div class="detail-cover"><img src="<?= e(cover_url($anime['cover_image'] ?? null)) ?>" alt="<?= e($anime['title']) ?>"></div>
    <?php if (ad_control_code('after_cover') !== ''): ?><section class="ad-control-site-slot ad-after-cover"><div class="ad-control-render"><?php render_ad_placement('after_cover'); ?></div></section><?php endif; ?>

    <?php if(setting('details_synopsis_enabled','1')==='1'): ?>
    <section class="synopsis-box">
      <h2>Synopsis</h2>
      <p><?= nl2br(e($anime['synopsis'] ?: 'Synopsis will be updated soon.')) ?></p>
    </section>
    <?php endif; ?>

    <?php if(setting('details_info_enabled','1')==='1'): ?>
    <section class="info-panel single-info-panel">
      <h2 class="info-title">Anime Information</h2>
      <div class="info-list info-list-single">
        <div class="info-row"><b>Title</b><span><?= e($anime['title'] ?? '') ?></span></div>
        <div class="info-row"><b>Type</b><span><?= e($anime['type'] ?: 'Series') ?></span></div>
        <div class="info-row"><b>Status</b><span><?= e($anime['status'] ?: 'Ongoing') ?></span></div>
        <div class="info-row"><b>Language</b><span><?= e($displayLanguages) ?></span></div>
        <div class="info-row"><b>Quality</b><span><?= e($displayQuality) ?></span></div>
        <div class="info-row"><b>Total Episodes</b><span><?= e($anime['total_episodes'] ?: 'N/A') ?></span></div>
        <div class="info-row"><b>Genres</b><span><?= e($anime['genres'] ?: 'Anime') ?></span></div>
        <div class="info-row"><b>Release Date</b><span><?= e($displayReleaseDate) ?></span></div>
        <?php if (!empty($anime['rating'])): ?><div class="info-row"><b>Rating</b><span><?= e($anime['rating']) ?></span></div><?php endif; ?>
        <?php if (!empty($anime['official_by'])): ?><div class="info-row"><b>Official By</b><span><?= e($anime['official_by']) ?></span></div><?php endif; ?>
        <?php if (!empty($anime['encoder'])): ?><div class="info-row"><b>Encoder</b><span><?= e($anime['encoder']) ?></span></div><?php endif; ?>
        <div class="info-row"><b>Published</b><span><?= e($displayPublishedDate) ?></span></div>
      </div>
    </section>
    <?php endif; ?>

    <?php if (ad_control_code('before_episodes') !== ''): ?><section class="ad-control-site-slot ad-before-episodes"><div class="ad-control-render"><?php render_ad_placement('before_episodes'); ?></div></section><?php endif; ?>
    <?php if(setting('details_episodes_enabled','1')==='1'): ?>
    <section class="episodes-section <?= $isMovie ? 'movie-links-section' : '' ?>">
      <div class="center-title"><span><?= $isMovie ? 'Movie Area' : 'Episode Area' ?></span><h2><?= $isMovie ? 'Movie Links' : 'Episode Links' ?></h2><p class="section-mini-note"><?= $isMovie ? 'Watch online or choose a movie download option below.' : 'Choose a watch or download option below.' ?></p></div>
      <?php if (!$episodes): ?><div class="upcoming-box"><div class="upcoming-icon">⏳</div><div><b><?= e(setting('upcoming_title','Upcoming')) ?></b><p><?= e($isMovie ? 'Movie links are being prepared. Please check back soon.' : setting('upcoming_message','Episode links are being prepared. Please check back soon.')) ?></p></div></div><?php endif; ?>
      <?php foreach ($episodes as $ep): $links = $linksByEpisode[(int)$ep['id']] ?? []; $watchLinks=[]; $downloadLinks=[]; foreach($links as $one){ if(($one['link_type'] ?? 'download') === 'watch') $watchLinks[]=$one; else $downloadLinks[]=$one; } ?>
        <section class="episode-card episode-card-clean" id="episode-<?= (int)$ep['id'] ?>">
          <div class="episode-top">
            <div class="episode-label-block">
              <div class="episode-name"><?= $isMovie ? 'Movie' : 'Episode ' . e(str_pad((string)($ep['episode_number'] ?? 1), 2, '0', STR_PAD_LEFT)) ?></div>
            </div>
            <div class="episode-date-block"><span>Uploaded</span><b><?= e(!empty($ep['upload_date']) ? date('M j, Y', strtotime($ep['upload_date'])) : 'N/A') ?></b></div>
          </div>

          <?php if ($watchLinks): ?>
          <div class="watch-online-box pro-watch-online single-watch-row">
            <div class="watch-buttons watch-buttons-clean">
              <?php foreach($watchLinks as $idx => $wl):
                $serverLabel = trim((string)($wl['host_name'] ?? ''));
                $buttonText = ($serverLabel !== '' && !preg_match('/^(watch online|online player|player|server)$/i', $serverLabel)) ? ('Watch Online - ' . $serverLabel) : 'Watch Online';
              ?>
                <a class="watch-btn watch-main-btn" href="<?= e(url('watch.php?link_id='.(int)$wl['id'].'&return='.rawurlencode(anime_link($anime).'#episode-'.(int)$ep['id']))) ?>" rel="nofollow"><?= e($buttonText) ?> <span>▶</span></a>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>

          <?php if ($downloadLinks): ?>
            <?php $grouped=[]; foreach($downloadLinks as $l){ $grouped[$l['quality'] ?: 'Link'][]=$l; } ?>
            <?php foreach ($grouped as $quality => $groupLinks): ?>
              <div class="quality-row compact-quality-row">
                <div class="quality-pill"><?= e($quality) ?></div>
                <div class="host-links">
                  <?php foreach($groupLinks as $l): ?>
                    <a class="host-link download-link" href="<?= e(url('out.php?type=episode&id='.(int)$l['id'])) ?>" target="_blank" rel="nofollow noopener"><span class="link-action">Download</span><b><?= e($l['host_name'] ?: 'Server') ?></b> <span>↗</span></a>
                  <?php endforeach; ?>
                </div>
              </div>
            <?php endforeach; ?>
          <?php elseif (!$watchLinks): ?><div class="quality-row empty-links"><span><?= $isMovie ? 'Movie links will be available soon.' : 'Download links will be available soon.' ?></span></div><?php endif; ?>
        </section>
      <?php endforeach; ?>
    </section>
    <?php endif; ?>
    <?php if (ad_control_code('after_episodes') !== ''): ?><section class="ad-control-site-slot ad-after-episodes"><div class="ad-control-render"><?php render_ad_placement('after_episodes'); ?></div></section><?php endif; ?>

    <?php if (ad_control_code('before_zip') !== ''): ?><section class="ad-control-site-slot ad-before-zip"><div class="ad-control-render"><?php render_ad_placement('before_zip'); ?></div></section><?php endif; ?>
    <?php if ($showZipSection && setting('details_zip_enabled','1')==='1'): ?>
    <section class="zip-section">
      <div class="center-title"><span><?= $isMovie ? 'Extra Files' : 'Batch Area' ?></span><h2><?= $isMovie ? 'Additional Downloads' : 'ZIP / Pack Downloads' ?></h2><p class="section-mini-note"><?= $isMovie ? 'Optional extra movie files appear here only when enabled from admin.' : 'Batch packs and split ZIP parts appear here when available.' ?></p></div>
      <?php if (!$zipLinks): ?><div class="empty-state small">ZIP / pack links will appear here when available.</div><?php else: ?>
        <div class="zip-grid pro-zip-grid">
          <?php foreach ($zipLinks as $z): ?>
          <article class="zip-card pro-zip-card">
            <div class="zip-icon">ZIP</div>
            <div class="zip-content">
              <b><?= e($z['pack_title'] ?: 'ZIP Pack') ?></b>
              <span><?= e($z['episode_range'] ?: 'Full / Batch') ?></span>
              <small><?= e($z['quality'] ?: 'HD') ?><?= $z['file_size'] ? ' • ' . e($z['file_size']) : '' ?><?= $z['host_name'] ? ' • ' . e($z['host_name']) : '' ?></small>
              <?php if (!empty($z['notes'])): ?><em><?= e($z['notes']) ?></em><?php endif; ?>
            </div>
            <a class="zip-download-btn" href="<?= e(url('out.php?type=zip&id='.(int)$z['id'])) ?>" target="_blank" rel="nofollow noopener">Download</a>
          </article>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
    <?php endif; ?>
    <?php if (ad_control_code('after_zip') !== ''): ?><section class="ad-control-site-slot ad-after-zip"><div class="ad-control-render"><?php render_ad_placement('after_zip'); ?></div></section><?php endif; ?>

    <?php if ($similar && setting('details_related_enabled','1')==='1'): ?>
    <section class="related-section">
      <div class="section-head related-head"><div><div class="section-kicker">More to watch</div><h2 class="section-title related-title">You may also like</h2></div></div>
      <div class="anime-grid related-grid">
        <?php foreach($similar as $item): ?>
          <article class="anime-card compact-related">
            <a class="thumb" href="<?= e(anime_link($item)) ?>"><img src="<?= e(cover_url($item['cover_image'] ?? null)) ?>" alt="<?= e($item['title']) ?>"></a>
            <div class="anime-card-body">
              <h3 class="anime-title"><a href="<?= e(anime_link($item)) ?>"><?= e($item['title']) ?></a></h3>
              <div class="meta-line">By <?= e($item['published_by'] ?: setting('site_name','AnimeDubHindi')) ?> <span>/</span> <?= e(date('M j, Y', strtotime($item['published_at'] ?? 'now'))) ?></div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>
  </article>
  <?php require __DIR__ . '/includes/sidebar.php'; ?>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
