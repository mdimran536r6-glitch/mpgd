<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Series - ' . setting('site_name', 'AnimeDubHindi');
$heading = 'Anime Series'; $kicker = 'Series Library';
$anime = fetch_anime_list('type != ?', ['Movie'], 120);
require __DIR__ . '/list-template.php';
