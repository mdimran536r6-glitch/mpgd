<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Report Broken Link - ' . setting('site_name', 'AnimeDubHindi');
if (!public_feature_enabled('public_report_enabled','1')) render_public_closed_page('Report Broken Link', setting('report_page_message','Broken link reports are temporarily closed. Please check again later.'));
$msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (!empty($_POST['website'])) { http_response_code(400); exit('Invalid request.'); }
    if (!simple_rate_limit('broken_report', 5, 600)) { $msg = 'Please wait a few minutes before sending another message.'; } else {
    $stmt = db()->prepare('INSERT INTO reports (name,email,page_url,message,created_at) VALUES (?,?,?,?,NOW())');
    $stmt->execute([clean_text((string)($_POST['name'] ?? ''),120), clean_text((string)($_POST['email'] ?? ''),160), mb_substr((string)($_POST['page_url'] ?? ''),0,255), clean_text((string)($_POST['message'] ?? ''),2000)]);
    $msg = 'Report submitted. Thank you.';
    track_event('report_submit', ['title'=>'Broken link report', 'page_url'=>($_POST['page_url'] ?? ($_SERVER['REQUEST_URI'] ?? ''))]);
    }
}
require __DIR__ . '/includes/header.php';
?>
<main class="container main-wrap"><section class="content-card form-card"><h1 class="section-title">Report Broken Link</h1><?php if($msg): ?><div class="notice success"><?= e($msg) ?></div><?php endif; ?><form method="post"><input type="text" name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;height:1px;width:1px;opacity:0" aria-hidden="true"><?= csrf_field() ?><label>Name</label><input name="name"><label>Email</label><input name="email" type="email"><label>Page URL</label><input name="page_url" value="<?= e($_GET['url'] ?? '') ?>"><label>Problem</label><textarea name="message" required></textarea><br><br><button class="btn">Submit Report</button></form></section><?php require __DIR__.'/includes/sidebar.php'; ?></main><?php require __DIR__.'/includes/footer.php'; ?>
