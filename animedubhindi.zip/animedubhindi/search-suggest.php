<?php
require_once __DIR__ . '/includes/functions.php';
if (!public_feature_enabled('public_search_enabled','1')) { header('Content-Type: application/json'); echo json_encode([]); exit; }
header('Content-Type: application/json; charset=utf-8');
$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 1) { echo json_encode([]); exit; }
$stmt = db()->prepare("SELECT title, slug, cover_image, type, published_at FROM anime WHERE COALESCE(content_status,'published')='published' AND (title LIKE ? OR genres LIKE ? OR language LIKE ?) ORDER BY is_pinned DESC, published_at DESC, id DESC LIMIT 8");
$like = '%' . $q . '%';
$stmt->execute([$like,$like,$like]);
$out = [];
foreach ($stmt->fetchAll() as $row) {
  $out[] = [
    'title' => $row['title'],
    'url' => anime_link($row),
    'cover' => cover_url($row['cover_image'] ?? null),
    'meta' => ($row['type'] ?: 'Anime') . ' • ' . date('M j, Y', strtotime($row['published_at'] ?? 'now')),
  ];
}
echo json_encode($out, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
