// main.js build: share-button-final

function openMobileMenu(){
  const panel = document.querySelector('.mobile-panel');
  const backdrop = document.querySelector('.mobile-backdrop');
  if(panel) panel.classList.add('open');
  if(backdrop) backdrop.classList.add('open');
  document.body.classList.add('mobile-nav-open');
}
function closeMobileMenu(){
  const panel = document.querySelector('.mobile-panel');
  const backdrop = document.querySelector('.mobile-backdrop');
  if(panel) panel.classList.remove('open');
  if(backdrop) backdrop.classList.remove('open');
  document.body.classList.remove('mobile-nav-open');
}

document.addEventListener('DOMContentLoaded', () => {

  // Site-wide scroll memory for a smoother Back-button experience.
  // It stores the current page position before the user opens another internal page,
  // then restores it only when the browser returns via Back/Forward navigation.
  (function siteWideScrollMemory(){
    const pageKey = 'adhSiteScroll:' + location.pathname + location.search;
    const navEntry = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
    const isBackForward = (navEntry && navEntry.type === 'back_forward');
    const currentY = () => window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
    const saveCurrent = () => {
      try { sessionStorage.setItem(pageKey, String(currentY())); } catch(e) {}
    };
    let saveTimer = null;
    const scheduleSave = () => {
      if (saveTimer) return;
      saveTimer = setTimeout(() => { saveTimer = null; saveCurrent(); }, 180);
    };
    const restore = () => {
      if (!isBackForward) return;
      const raw = sessionStorage.getItem(pageKey);
      const y = parseInt(raw || '0', 10);
      if (!y) return;
      const jump = () => window.scrollTo({ top: y, left: 0, behavior: 'auto' });
      jump();
      requestAnimationFrame(jump);
      [120, 300, 650, 1100].forEach(t => setTimeout(jump, t));
    };
    try { if ('scrollRestoration' in history) history.scrollRestoration = 'manual'; } catch(e) {}
    window.addEventListener('scroll', scheduleSave, { passive: true });
    window.addEventListener('pagehide', saveCurrent, { passive: true });
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveCurrent(); });
    document.addEventListener('click', (event) => {
      const link = event.target.closest && event.target.closest('a[href]');
      if (!link) return;
      const href = link.getAttribute('href') || '';
      if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
      if (link.target && link.target !== '_self') return;
      let url;
      try { url = new URL(href, location.href); } catch(e) { return; }
      if (url.origin !== location.origin) return;
      saveCurrent();
    }, true);
    window.addEventListener('pageshow', restore);
    setTimeout(restore, 80);
  })();


  // Preserve anime-details scroll position when opening Watch Online and coming back.
  const detailScrollKey = 'adhDetailScroll:' + location.pathname + location.search;
  const restoreDetailScroll = () => {
    const saved = parseInt(sessionStorage.getItem(detailScrollKey) || '0', 10);
    if (!saved) return;
    const run = () => window.scrollTo({ top: saved, left: 0, behavior: 'auto' });
    run();
    requestAnimationFrame(run);
    [120, 320, 700].forEach(t => setTimeout(run, t));
    setTimeout(() => sessionStorage.removeItem(detailScrollKey), 1000);
  };
  if (document.querySelector('.anime-detail-card')) {
    window.addEventListener('pageshow', restoreDetailScroll);
    setTimeout(restoreDetailScroll, 80);
    document.querySelectorAll('.watch-main-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        sessionStorage.setItem(detailScrollKey, String(window.scrollY || document.documentElement.scrollTop || 0));
      });
    });
  }


  // Episode cards should not navigate when the empty/card area is tapped.
  // Only explicit buttons/links inside the card should open watch or download pages.
  document.querySelectorAll('.episode-card').forEach(card => {
    card.addEventListener('click', (event) => {
      const interactive = event.target.closest && event.target.closest('a,button,input,select,textarea,label,summary,details');
      if (!interactive) event.preventDefault();
    });
  });

  const mobileBackdrop = document.querySelector('.mobile-backdrop');
  if (mobileBackdrop) mobileBackdrop.addEventListener('click', closeMobileMenu);
  document.querySelectorAll('.mobile-panel a').forEach(a => a.addEventListener('click', closeMobileMenu));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMobileMenu(); });

  const smartHeader = document.querySelector('[data-smart-header]') || document.querySelector('.site-topbar') || document.querySelector('.site-header');
  if (smartHeader) {
    const root = document.documentElement;
    const body = document.body;
    let lastY = Math.max(window.scrollY || document.documentElement.scrollTop || 0, 0);
    let hidden = false;
    let raf = false;

    const measureSmartHeader = () => {
      const h = Math.ceil(smartHeader.offsetHeight || smartHeader.getBoundingClientRect().height || 86);
      root.style.setProperty('--smart-header-height', h + 'px');
      body.classList.add('smart-header-ready','telegram-static-ready');
      smartHeader.classList.add('smart-header-fixed', 'smart-header-show');
      smartHeader.classList.remove('smart-header-hide', 'header-hidden');
    };

    const showSmartHeader = () => {
      hidden = false;
      smartHeader.classList.remove('smart-header-hide', 'header-hidden');
      smartHeader.classList.add('smart-header-show', 'header-visible');
    };

    const hideSmartHeader = () => {
      hidden = true;
      smartHeader.classList.add('smart-header-hide', 'header-hidden');
      smartHeader.classList.remove('smart-header-show', 'header-visible');
    };

    const menuOrSearchOpen = () => Boolean(
      document.querySelector('.mobile-panel.open') ||
      document.querySelector('.search-overlay.open')
    );

    const updateSmartHeader = () => {
      const y = Math.max(window.scrollY || document.documentElement.scrollTop || 0, 0);
      const delta = y - lastY;

      if (menuOrSearchOpen() || y <= 8) {
        showSmartHeader();
      } else if (delta > 3 && y > 90 && !hidden) {
        hideSmartHeader();
      } else if (delta < -1 && hidden) {
        // YouTube style: even a small upward pull brings the header back.
        showSmartHeader();
      }

      lastY = y;
      raf = false;
    };

    const onSmartScroll = () => {
      if (!raf) {
        raf = true;
        requestAnimationFrame(updateSmartHeader);
      }
    };

    measureSmartHeader();
    showSmartHeader();
    window.addEventListener('resize', measureSmartHeader, { passive: true });
    window.addEventListener('orientationchange', () => setTimeout(measureSmartHeader, 250), { passive: true });
    window.addEventListener('scroll', onSmartScroll, { passive: true });
    window.addEventListener('wheel', onSmartScroll, { passive: true });
    window.addEventListener('touchmove', onSmartScroll, { passive: true });
  }

  document.querySelectorAll('[data-mobile-submenu]').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('.mobile-menu-group');
      group.classList.toggle('open');
    });
  });

  const btn = document.querySelector('[data-load-more]');
  if (btn) {
    btn.addEventListener('click', () => {
      const hidden = Array.from(document.querySelectorAll('.anime-card.hidden-card'));
      if (!hidden.length) {
        btn.textContent = 'All Posts Loaded';
        btn.classList.add('is-done');
        return;
      }
      hidden.slice(0, 18).forEach(card => card.classList.remove('hidden-card'));
      if (!document.querySelector('.anime-card.hidden-card')) {
        btn.textContent = 'All Posts Loaded';
        btn.classList.add('is-done');
      }
    });
  }

  document.querySelectorAll('.suggest-search').forEach(form => {
    const input = form.querySelector('.suggest-input');
    const box = form.querySelector('.suggest-box');
    const endpoint = form.dataset.suggestUrl;
    if (!input || !box || !endpoint) return;
    let timer;
    const close = () => { box.classList.remove('show'); box.innerHTML = ''; };
    input.addEventListener('input', () => {
      clearTimeout(timer);
      const q = input.value.trim();
      if (q.length < 1) { close(); return; }
      timer = setTimeout(async () => {
        try {
          const res = await fetch(endpoint + '?q=' + encodeURIComponent(q), {headers:{'Accept':'application/json'}});
          const items = await res.json();
          if (!items.length) { close(); return; }
          box.innerHTML = items.map(item => `
            <a class="suggest-item" href="${item.url}">
              <img src="${item.cover}" alt="">
              <span><b>${escapeHtml(item.title)}</b><small>${escapeHtml(item.meta || '')}</small></span>
            </a>`).join('');
          box.classList.add('show');
        } catch (e) { close(); }
      }, 180);
    });
    document.addEventListener('click', (e) => { if (!form.contains(e.target)) close(); });
  });

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[s]));
  }



  document.querySelectorAll('[data-featured-slider]').forEach(slider => {
    const slides = Array.from(slider.querySelectorAll('.featured-slide'));
    const dots = Array.from(slider.querySelectorAll('[data-featured-dot]'));
    if (slides.length <= 1) return;
    let index = 0;
    const show = (i) => {
      index = (i + slides.length) % slides.length;
      slides.forEach((slide, n) => slide.classList.toggle('active', n === index));
      dots.forEach((dot, n) => dot.classList.toggle('active', n === index));
    };
    dots.forEach((dot, n) => dot.addEventListener('click', () => show(n)));
    setInterval(() => show(index + 1), 4500);
  });

  const pop = document.getElementById('telegramPopup');
  if (pop) {
    const key = 'animedubhindiTelegramPopupClosedAt';
    const last = parseInt(localStorage.getItem(key) || '0', 10);
    const now = Date.now();
    if (!last || now - last > 24 * 60 * 60 * 1000) {
      setTimeout(() => pop.classList.add('show'), 1200);
    }
    window.closeTelegramPopup = function () {
      localStorage.setItem(key, String(Date.now()));
      pop.classList.remove('show');
    };
  }

  const topBtn = document.querySelector('.back-top');
  if (topBtn) {
    const toggleTop = () => {
      topBtn.classList.toggle('show', window.scrollY > 450);
      const footer = document.querySelector('.site-footer');
      if (footer) {
        const rect = footer.getBoundingClientRect();
        topBtn.classList.toggle('near-footer', rect.top < window.innerHeight - 80);
      }
    };
    window.addEventListener('scroll', toggleTop, {passive:true});
    toggleTop();
  }



  document.querySelectorAll('[data-copy-link]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const link = btn.getAttribute('data-copy-link') || '';
      try {
        await navigator.clipboard.writeText(link);
        btn.textContent = 'Copied';
        btn.classList.add('copied');
        setTimeout(() => { btn.textContent = 'Copy'; btn.classList.remove('copied'); }, 1400);
      } catch (e) {
        const input = document.createElement('input');
        input.value = link;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        input.remove();
        btn.textContent = 'Copied';
        btn.classList.add('copied');
        setTimeout(() => { btn.textContent = 'Copy'; btn.classList.remove('copied'); }, 1400);
      }
    });
  });


  // Anime details share button: native mobile share, professional desktop fallback.
  function showSiteShareToast(message) {
    let toast = document.querySelector('.site-share-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'site-share-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => toast.classList.remove('show'), 1800);
  }
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    return new Promise((resolve, reject) => {
      try {
        const input = document.createElement('textarea');
        input.value = text;
        input.setAttribute('readonly','');
        input.style.position = 'fixed';
        input.style.left = '-9999px';
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        input.remove();
        resolve();
      } catch (e) { reject(e); }
    });
  }
  let shareModal;
  function closeShareModal(){ if (shareModal) shareModal.classList.remove('open'); }
  function openShareModal(data){
    if (!shareModal) {
      shareModal = document.createElement('div');
      shareModal.className = 'share-modal-backdrop';
      shareModal.innerHTML = `
        <div class="share-modal" role="dialog" aria-modal="true" aria-labelledby="shareModalTitle">
          <button type="button" class="share-modal-close" aria-label="Close share menu">×</button>
          <div class="share-modal-head">
            <span class="share-modal-icon">↗</span>
            <div><h3 id="shareModalTitle">Share Anime</h3><p>Share this page with your friends.</p></div>
          </div>
          <div class="share-modal-actions">
            <a class="share-action whatsapp" target="_blank" rel="nofollow noopener">WhatsApp</a>
            <a class="share-action telegram" target="_blank" rel="nofollow noopener">Telegram</a>
            <a class="share-action facebook" target="_blank" rel="nofollow noopener">Facebook</a>
            <button type="button" class="share-action copy">Copy Link</button>
          </div>
        </div>`;
      document.body.appendChild(shareModal);
      shareModal.addEventListener('click', e => { if (e.target === shareModal) closeShareModal(); });
      shareModal.querySelector('.share-modal-close').addEventListener('click', closeShareModal);
      document.addEventListener('keydown', e => { if (e.key === 'Escape') closeShareModal(); });
    }
    const encodedUrl = encodeURIComponent(data.url);
    const encodedText = encodeURIComponent((data.title ? data.title + ' - ' : '') + data.url);
    shareModal.querySelector('.whatsapp').href = 'https://api.whatsapp.com/send?text=' + encodedText;
    shareModal.querySelector('.telegram').href = 'https://t.me/share/url?url=' + encodedUrl + '&text=' + encodeURIComponent(data.title || 'Anime');
    shareModal.querySelector('.facebook').href = 'https://www.facebook.com/sharer/sharer.php?u=' + encodedUrl;
    shareModal.querySelector('.copy').onclick = async () => {
      try { await copyText(data.url); showSiteShareToast('Link copied'); closeShareModal(); }
      catch(e) { showSiteShareToast('Copy failed'); }
    };
    shareModal.classList.add('open');
  }
  document.querySelectorAll('.share-anime-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const data = { title: btn.dataset.shareTitle || document.title, text: btn.dataset.shareText || '', url: btn.dataset.shareUrl || location.href };
      if (window.ADHTrack) window.ADHTrack({event_type:'share_click', page_url:location.pathname + location.search, title:data.title});
      if (navigator.share) {
        try { await navigator.share(data); return; } catch(e) { if (e && e.name === 'AbortError') return; }
      }
      openShareModal(data);
    });
  });

  document.querySelectorAll('[data-ad-card]').forEach(card => {
    if (card.dataset.refreshEnabled !== '1') return;
    const seconds = Math.max(30, parseInt(card.dataset.refreshSeconds || '60', 10));
    setInterval(() => {
      card.style.opacity = '0.55';
      setTimeout(() => { card.style.opacity = '1'; }, 250);
    }, seconds * 1000);
  });
});


// Admin anime filter and better accordions
(function(){
  const filter = document.querySelector('[data-admin-anime-filter]');
  if(filter){
    const items = Array.from(document.querySelectorAll('[data-anime-pick]'));
    filter.addEventListener('input', () => {
      const q = filter.value.trim().toLowerCase();
      items.forEach(item => {
        const hay = (item.dataset.title || item.textContent || '').toLowerCase();
        item.style.display = hay.includes(q) ? '' : 'none';
      });
    });
  }
})();


// Analytics: lightweight, privacy-friendly event tracking. Never blocks the UI.
(function(){
  const endpoint = (window.ADH_BASE_URL || '') + 'analytics-track.php';
  const send = (payload) => {
    try {
      const data = new FormData();
      Object.entries(payload || {}).forEach(([k,v]) => data.append(k, v == null ? '' : String(v)));
      if (navigator.sendBeacon) { navigator.sendBeacon(endpoint, data); return; }
      fetch(endpoint, {method:'POST', body:data, keepalive:true}).catch(()=>{});
    } catch(e) {}
  };
  window.ADHTrack = send;
  if (!sessionStorage.getItem('adhPageTracked:' + location.pathname + location.search)) {
    sessionStorage.setItem('adhPageTracked:' + location.pathname + location.search, '1');
    send({event_type:'page_view', page_url:location.pathname + location.search, title:document.title, referrer:document.referrer});
  }
  let searchTimer = null;
  document.addEventListener('input', function(e){
    const t = e.target;
    if (!t || !t.matches('input[name="q"], .site-search input, [data-search-input]')) return;
    const q = (t.value || '').trim();
    if (q.length < 2) return;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(()=>send({event_type:'search', query:q, page_url:location.pathname + location.search, title:'Search: '+q}), 900);
  }, true);
})();
