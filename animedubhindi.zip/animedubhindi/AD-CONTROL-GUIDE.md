# AnimeDubHindi Ad Control Guide

The admin panel includes **Admin → Ad Control** so you can paste ad network scripts without editing PHP files.

## Available placements

1. **Head / Verification Code** — verification meta tags or scripts that networks require inside `<head>`.
2. **After Body Start** — scripts that must load immediately after `<body>`.
3. **Under Header** — banner/native ad below the top Telegram strip.
4. **Before Latest Releases** — homepage ad above the latest anime grid.
5. **After Latest Releases** — homepage ad below the latest anime grid and Load More button.
6. **Sidebar / Native Box** — right sidebar ad box near Featured, Channels, Site Menu and legacy ad area.
7. **Before Anime Details** — anime details page, above the post title/content.
8. **After Cover Image** — anime details page, below the cover image and above Synopsis.
9. **Before Episode Links** — anime details page, above the episode section.
10. **After Episode Links** — anime details page, below the episode section.
11. **Before ZIP / Pack Downloads** — above ZIP / pack downloads.
12. **After ZIP / Pack Downloads** — below ZIP / pack downloads.
13. **Before Footer** — site-wide slot above the footer.
14. **Popunder** — paste Adsterra/Monetag popunder script.
15. **Social Bar** — paste social bar/floating ad network script.
16. **Floating Chat / Widget** — chat widgets or support/community floating scripts.
17. **Body End / Custom Script** — any script that should load before `</body>`.

## Recommended setup

Start with verification code first. Then enable one visible placement, such as Sidebar or Under Header. Test desktop and mobile. After that, enable popunder/social scripts if you need them.

## Important

Only paste scripts from accounts you own. Too many scripts can slow the website or affect mobile UI, so keep placements minimal.

## Clearing or deleting ad codes

Open **Admin → Ad Control**.

- Use **Clear** beside any placement to remove only that placement's saved code and turn it off.
- Use **Clear All Ad Codes** to empty every ad placement, turn every ad placement off, reset the sidebar ad title, and clear private notes.
- Clearing ad codes does not delete anime posts, episodes, ZIP links, requests, reports, menus, or website settings.
- A confirmation dialog appears before any clear action runs.
