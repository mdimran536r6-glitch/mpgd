<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

function featured_pager(string $base, int $page, int $pages, array $keep = []): void {
    if ($pages <= 1) return;
    echo '<nav class="admin-pager" aria-label="Pagination">';
    if ($page > 1) { $qs = array_merge($keep, ['page'=>$page-1]); echo '<a href="'.e($base.'?'.http_build_query($qs)).'">Prev</a>'; }
    $start=max(1,$page-2); $end=min($pages,$page+2);
    if($start>1){ $qs=array_merge($keep,['page'=>1]); echo '<a href="'.e($base.'?'.http_build_query($qs)).'">1</a>'; if($start>2) echo '<span>…</span>'; }
    for($i=$start;$i<=$end;$i++){ $qs=array_merge($keep,['page'=>$i]); echo '<a class="'.($i===$page?'active':'').'" href="'.e($base.'?'.http_build_query($qs)).'">'.$i.'</a>'; }
    if($end<$pages){ if($end<$pages-1) echo '<span>…</span>'; $qs=array_merge($keep,['page'=>$pages]); echo '<a href="'.e($base.'?'.http_build_query($qs)).'">'.$pages.'</a>'; }
    if ($page < $pages) { $qs = array_merge($keep, ['page'=>$page+1]); echo '<a href="'.e($base.'?'.http_build_query($qs)).'">Next</a>'; }
    echo '</nav>';
}

try {
    db()->exec("CREATE TABLE IF NOT EXISTS sidebar_featured_anime (id INT AUTO_INCREMENT PRIMARY KEY, anime_id INT NOT NULL UNIQUE, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_sidebar_featured_active (is_active, sort_order), INDEX idx_sidebar_featured_anime (anime_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Throwable $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $ids = array_values(array_unique(array_map('intval', $_POST['featured_ids'] ?? [])));
        $orders = $_POST['sort_order'] ?? [];
        $pdo = db();
        $pdo->beginTransaction();
        $pdo->exec('DELETE FROM sidebar_featured_anime');
        $pdo->exec('UPDATE anime SET is_featured = 0');
        $insert = $pdo->prepare('INSERT INTO sidebar_featured_anime(anime_id, sort_order, is_active) VALUES(?,?,1)');
        $mark = $pdo->prepare('UPDATE anime SET is_featured = 1 WHERE id = ?');
        $pos = 1;
        foreach ($ids as $animeId) {
            if ($animeId <= 0) continue;
            $sort = isset($orders[$animeId]) ? (int)$orders[$animeId] : $pos;
            if ($sort <= 0) $sort = $pos;
            $insert->execute([$animeId, $sort]);
            $mark->execute([$animeId]);
            $pos++;
        }
        $pdo->commit();
        flash('Featured anime selection saved. Sidebar will now show only the selected anime.');
        header('Location: featured.php'); exit;
    } catch (Throwable $e) {
        if (db()->inTransaction()) db()->rollBack();
        flash('Could not save featured anime: '.$e->getMessage(), 'error');
        header('Location: featured.php'); exit;
    }
}

$q = trim($_GET['q'] ?? '');
$contentFilter = trim($_GET['content_status'] ?? '');
$typeFilter = trim($_GET['type'] ?? '');
$statusFilter = trim($_GET['anime_status'] ?? '');
$languageFilter = trim($_GET['language'] ?? '');
$languageOptions = admin_language_options();
$selectedFilter = trim($_GET['selected_state'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;
$params = [];
$whereParts = ['1'];
if ($q !== '') { $whereParts[] = '(a.title LIKE ? OR a.genres LIKE ? OR a.type LIKE ? OR a.status LIKE ? OR a.language LIKE ?)'; $like = '%'.$q.'%'; array_push($params,$like,$like,$like,$like,$like); }
if(in_array($contentFilter, ['draft','published','unpublished'], true)){ $whereParts[]="COALESCE(a.content_status,'published')=?"; $params[]=$contentFilter; }
if(in_array($typeFilter, ['Series','Movie'], true)){ $whereParts[]='a.type=?'; $params[]=$typeFilter; }
if(in_array($statusFilter, ['Ongoing','Completed','Upcoming'], true)){ $whereParts[]='a.status=?'; $params[]=$statusFilter; }
if($languageFilter !== ''){ $whereParts[]='a.language=?'; $params[]=$languageFilter; }
if($selectedFilter === 'selected'){ $whereParts[]='sf.anime_id IS NOT NULL'; }
if($selectedFilter === 'not_selected'){ $whereParts[]='sf.anime_id IS NULL'; }
$where = 'WHERE '.implode(' AND ', $whereParts);
$countSt = db()->prepare("SELECT COUNT(*) FROM anime a LEFT JOIN sidebar_featured_anime sf ON sf.anime_id = a.id $where");
$countSt->execute($params);
$total = (int)$countSt->fetchColumn();
$pages = max(1, (int)ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;
$sql = "SELECT a.*, sf.sort_order AS featured_order, sf.is_active AS selected_featured
        FROM anime a
        LEFT JOIN sidebar_featured_anime sf ON sf.anime_id = a.id
        $where
        ORDER BY (sf.anime_id IS NULL) ASC, sf.sort_order ASC, a.published_at DESC, a.id DESC
        LIMIT ? OFFSET ?";
$st = db()->prepare($sql);
$i=1; foreach($params as $p){ $st->bindValue($i++,$p); }
$st->bindValue($i++,$perPage,PDO::PARAM_INT); $st->bindValue($i++,$offset,PDO::PARAM_INT); $st->execute();
$rows = $st->fetchAll();
$selected = db()->query('SELECT a.id, a.title, a.cover_image, a.slug, sf.sort_order FROM sidebar_featured_anime sf INNER JOIN anime a ON a.id=sf.anime_id WHERE sf.is_active=1 ORDER BY sf.sort_order ASC, a.published_at DESC')->fetchAll();
$selectedIds = array_map(fn($r)=>(int)$r['id'], $selected);
$visibleIds = array_map(fn($r)=>(int)$r['id'], $rows);
$keep = []; foreach(['q'=>$q,'content_status'=>$contentFilter,'type'=>$typeFilter,'anime_status'=>$statusFilter,'selected_state'=>$selectedFilter,'language'=>$languageFilter] as $k=>$v){ if($v!=='') $keep[$k]=$v; }
require __DIR__ . '/_header.php';
?>
<div class="admin-top"><div><h1>Featured Anime</h1><p>Choose exactly which anime will show in the sidebar featured slider. Nothing is selected automatically.</p></div><a class="btn secondary" href="<?= e(admin_url('settings.php')) ?>">Sidebar Settings</a></div>

<section class="card featured-control-summary">
  <div class="card-title-row"><div><h2>Selected for Sidebar</h2><p class="help">These posts will appear in the website sidebar in this order.</p></div><span class="badge"><?= count($selected) ?> selected</span></div>
  <?php if(!$selected): ?>
    <div class="empty-admin-state">No featured anime selected yet. Select anime below and save.</div>
  <?php else: ?>
    <div class="featured-selected-strip">
      <?php foreach($selected as $s): ?>
        <a href="<?= e('../anime.php?slug='.$s['slug']) ?>" target="_blank"><img src="<?= e(cover_url($s['cover_image'] ?? null)) ?>" alt=""><span><?= e($s['sort_order']) ?>. <?= e($s['title']) ?></span></a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<section class="card anime-list-card featured-select-card">
  <div class="admin-content-toolbar admin-filter-toolbar">
    <form class="admin-filter-grid admin-filter-grid-featured" method="get" action="featured.php">
      <input class="input" name="q" value="<?= e($q) ?>" placeholder="Search anime to feature...">
      <select name="selected_state"><option value="">Selection: All</option><option value="selected" <?= $selectedFilter==='selected'?'selected':'' ?>>Selected only</option><option value="not_selected" <?= $selectedFilter==='not_selected'?'selected':'' ?>>Not selected</option></select>
      <select name="content_status"><option value="">All visibility</option><option value="draft" <?= $contentFilter==='draft'?'selected':'' ?>>Draft</option><option value="published" <?= $contentFilter==='published'?'selected':'' ?>>Published</option><option value="unpublished" <?= $contentFilter==='unpublished'?'selected':'' ?>>Unpublished</option></select>
      <select name="type"><option value="">All types</option><option value="Series" <?= $typeFilter==='Series'?'selected':'' ?>>Series</option><option value="Movie" <?= $typeFilter==='Movie'?'selected':'' ?>>Movie</option></select>
      <select name="anime_status"><option value="">All statuses</option><option value="Ongoing" <?= $statusFilter==='Ongoing'?'selected':'' ?>>Ongoing</option><option value="Completed" <?= $statusFilter==='Completed'?'selected':'' ?>>Completed</option><option value="Upcoming" <?= $statusFilter==='Upcoming'?'selected':'' ?>>Upcoming</option></select>
      <select name="language"><option value="">All languages</option><?php foreach($languageOptions as $lo): ?><option value="<?= e($lo) ?>" <?= $languageFilter===$lo?'selected':'' ?>><?= e($lo) ?></option><?php endforeach; ?></select>
      <button class="btn small" type="submit">Filter</button>
      <a class="btn small secondary" href="featured.php">Reset</a>
    </form>
    <div class="admin-result-count"><b><?= $total ?></b> posts · Page <?= $page ?> of <?= $pages ?></div>
  </div>

  <form method="post" class="featured-select-form"><?= csrf_field() ?>
    <?php foreach($selected as $hiddenSelected): if(!in_array((int)$hiddenSelected['id'], $visibleIds, true)): ?>
      <input type="hidden" name="featured_ids[]" value="<?= (int)$hiddenSelected['id'] ?>">
      <input type="hidden" name="sort_order[<?= (int)$hiddenSelected['id'] ?>]" value="<?= (int)$hiddenSelected['sort_order'] ?>">
    <?php endif; endforeach; ?>
    <div class="featured-select-list">
      <?php foreach($rows as $a):
        $isSelected = in_array((int)$a['id'], $selectedIds, true);
        $orderValue = $isSelected ? (int)($a['featured_order'] ?? 0) : '';
      ?>
      <article class="featured-select-row <?= $isSelected ? 'is-selected' : '' ?>">
        <label class="featured-check"><input type="checkbox" name="featured_ids[]" value="<?= (int)$a['id'] ?>" <?= $isSelected?'checked':'' ?>><span></span></label>
        <img src="<?= e(cover_url($a['cover_image'] ?? null)) ?>" alt="">
        <div class="featured-select-info"><b><?= e($a['title']) ?></b><small><?= e($a['type'] ?: 'Series') ?> · <?= e($a['status'] ?: 'Ongoing') ?> · <?= e(!empty($a['published_at']) ? date('M j, Y', strtotime($a['published_at'])) : '-') ?></small></div>
        <div class="featured-order-field"><label>Order</label><input class="input" type="number" min="1" max="99" name="sort_order[<?= (int)$a['id'] ?>]" value="<?= e($orderValue) ?>" placeholder="Auto"></div>
      </article>
      <?php endforeach; ?>
    </div>
    <?php featured_pager('featured.php', $page, $pages, $keep); ?>
    <div class="settings-savebar"><a class="btn secondary" href="<?= e(admin_url('settings.php')) ?>">Cancel</a><button class="btn" type="submit">Save Featured Selection</button></div>
  </form>
</section>
<?php require __DIR__ . '/_footer.php'; ?>
