<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

$textKeys = [
  'site_name','site_url','brand_icon_url','site_description','maintenance_message',
  'telegram_text','telegram_link','telegram_popup_text','whatsapp_link','telegram_sidebar_link',
  'sidebar_featured_title','sidebar_featured_label','ad_title','ad_image','ad_url','ad_html',
  'footer_about','footer_credit','homepage_kicker','homepage_title','load_more_label',
  'upcoming_title','upcoming_message'
];
$checkboxKeys = [
  'maintenance_enabled','smart_header_enabled','header_search_enabled','header_telegram_strip_enabled',
  'telegram_popup_enabled','social_box_enabled','sidebar_menu_links_enabled','sidebar_menu_children_enabled','sidebar_menu_copy_enabled',
  'sidebar_featured_enabled','ad_enabled','show_empty_ad_box','ad_refresh_enabled',
  'load_more_enabled','show_pinned_badge','card_meta_enabled','card_author_enabled','card_date_enabled',
  'details_breadcrumb_enabled','details_meta_enabled','details_share_enabled','details_synopsis_enabled','details_info_enabled','details_episodes_enabled','details_zip_enabled','details_related_enabled',
  'footer_about_enabled','footer_quick_links_enabled','footer_support_enabled','footer_legal_enabled','footer_community_enabled','back_to_top_enabled','analytics_enabled'
];
$numberKeys = [
  'ad_refresh_seconds'=>[30,3600,60], 'latest_initial_limit'=>[6,60,18], 'similar_posts_limit'=>[3,18,6], 'sidebar_featured_limit'=>[1,12,5],
  'admin_anime_page_size'=>[5,50,10], 'admin_dashboard_page_size'=>[5,50,8], 'admin_message_page_size'=>[5,50,10], 'analytics_retention_days'=>[30,3650,180]
];
if($_SERVER['REQUEST_METHOD']==='POST'){
  foreach($textKeys as $k){ save_setting($k, (string)($_POST[$k] ?? '')); }
  foreach($checkboxKeys as $k){ save_setting($k, !empty($_POST[$k])?'1':'0'); }
  foreach($numberKeys as $k=>$rule){ [$min,$max,$def]=$rule; save_setting($k, (string)max($min, min($max, (int)($_POST[$k] ?? $def)))); }
  flash('Settings saved.');
  header('Location: settings.php'); exit;
}
function chk($key,$default='1'){ return setting($key,$default)==='1'?'checked':''; }
function val($key,$default=''){ return e(setting($key,$default)); }
require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero"><div><h1>Advanced Settings</h1><p>Fine-tune public website sections, sidebar blocks, footer, analytics and admin list behavior from one place. Use Control Center for the main quick controls.</p></div><a class="btn secondary" href="control-center.php">Control Center</a><a class="btn secondary" href="guide.php">Open Admin Guide</a><a class="btn secondary" href="seo-control.php">SEO Control</a></div>
<form class="settings-pro-grid" method="post"><?= csrf_field() ?>
  <section class="card settings-panel">
    <h2>Brand & Website</h2>
    <div class="form-row"><div class="field"><label>Site Name</label><input class="input" name="site_name" value="<?= val('site_name','AnimeDubHindi') ?>"></div><div class="field"><label>Live Website URL</label><input class="input" name="site_url" value="<?= val('site_url','https://www.animedubhindi.xyz') ?>"></div></div>
    <div class="field"><label>Brand Icon URL</label><input class="input" name="brand_icon_url" value="<?= val('brand_icon_url','') ?>" placeholder="Optional image URL"><small>Leave blank to use the built-in mascot. Use only images you own or have permission to use.</small></div>
    <div class="field"><label>Site Description / SEO Default</label><input class="input" name="site_description" value="<?= val('site_description','Anime release updates, episode links and download pack information.') ?>"></div>
    <label class="check"><input type="checkbox" name="maintenance_enabled" <?= chk('maintenance_enabled','0') ?>> Enable maintenance mode for visitors</label>
    <div class="field"><label>Maintenance Message</label><input class="input" name="maintenance_message" value="<?= val('maintenance_message','We are updating the website. Please check back soon.') ?>"></div>
  </section>

  <section class="card settings-panel">
    <h2>Header & Search</h2>
    <label class="check"><input type="checkbox" name="smart_header_enabled" <?= chk('smart_header_enabled','1') ?>> Smart header hide/show on scroll</label>
    <label class="check"><input type="checkbox" name="header_search_enabled" <?= chk('header_search_enabled','1') ?>> Show header search and mobile search</label>
    <label class="check"><input type="checkbox" name="header_telegram_strip_enabled" <?= chk('header_telegram_strip_enabled','1') ?>> Show Telegram join strip below header</label>
    <div class="field"><label>Telegram Strip Text</label><input class="input" name="telegram_text" value="<?= val('telegram_text','For more updates join our Telegram channel') ?>"></div>
    <div class="field"><label>Main Telegram Link</label><input class="input" name="telegram_link" value="<?= val('telegram_link','https://t.me/animedubhindixyz') ?>"></div>
    <label class="check"><input type="checkbox" name="telegram_popup_enabled" <?= chk('telegram_popup_enabled','1') ?>> Show community popup once every 24 hours</label>
    <div class="field"><label>Popup Text</label><input class="input" name="telegram_popup_text" value="<?= val('telegram_popup_text','Join the official channels for latest anime updates, watch notices and download pack alerts.') ?>"></div>
  </section>

  <section class="card settings-panel">
    <h2>Homepage Cards</h2>
    <div class="form-row"><div class="field"><label>Small Label</label><input class="input" name="homepage_kicker" value="<?= val('homepage_kicker','Fresh Updates') ?>"></div><div class="field"><label>Section Title</label><input class="input" name="homepage_title" value="<?= val('homepage_title','Latest Releases') ?>"></div></div>
    <div class="form-row"><div class="field"><label>First visible posts</label><input class="input" type="number" min="6" max="60" name="latest_initial_limit" value="<?= val('latest_initial_limit','18') ?>"></div><div class="field"><label>Load More Label</label><input class="input" name="load_more_label" value="<?= val('load_more_label','Load More') ?>"></div></div>
    <label class="check"><input type="checkbox" name="load_more_enabled" <?= chk('load_more_enabled','1') ?>> Show Load More button</label>
    <label class="check"><input type="checkbox" name="show_pinned_badge" <?= chk('show_pinned_badge','1') ?>> Show pinned badge on cards</label>
    <label class="check"><input type="checkbox" name="card_meta_enabled" <?= chk('card_meta_enabled','1') ?>> Show card meta row</label>
    <label class="check"><input type="checkbox" name="card_author_enabled" <?= chk('card_author_enabled','1') ?>> Show author/publisher on cards</label>
    <label class="check"><input type="checkbox" name="card_date_enabled" <?= chk('card_date_enabled','1') ?>> Show published date on cards</label>
  </section>

  <section class="card settings-panel">
    <h2>Anime Details Page</h2>
    <label class="check"><input type="checkbox" name="details_breadcrumb_enabled" <?= chk('details_breadcrumb_enabled','1') ?>> Show breadcrumb</label>
    <label class="check"><input type="checkbox" name="details_meta_enabled" <?= chk('details_meta_enabled','1') ?>> Show published by/date</label>
    <label class="check"><input type="checkbox" name="details_share_enabled" <?= chk('details_share_enabled','1') ?>> Show Share Anime button</label>
    <label class="check"><input type="checkbox" name="details_synopsis_enabled" <?= chk('details_synopsis_enabled','1') ?>> Show Synopsis</label>
    <label class="check"><input type="checkbox" name="details_info_enabled" <?= chk('details_info_enabled','1') ?>> Show Anime Information</label>
    <label class="check"><input type="checkbox" name="details_episodes_enabled" <?= chk('details_episodes_enabled','1') ?>> Show Episode Links section</label>
    <label class="check"><input type="checkbox" name="details_zip_enabled" <?= chk('details_zip_enabled','1') ?>> Show ZIP / Pack section globally</label>
    <label class="check"><input type="checkbox" name="details_related_enabled" <?= chk('details_related_enabled','1') ?>> Show You May Also Like</label>
    <div class="field"><label>You May Also Like Count</label><input class="input" type="number" min="3" max="18" name="similar_posts_limit" value="<?= val('similar_posts_limit','6') ?>"></div>
    <div class="form-row"><div class="field"><label>Upcoming Title</label><input class="input" name="upcoming_title" value="<?= val('upcoming_title','Upcoming') ?>"></div><div class="field"><label>Upcoming Text</label><input class="input" name="upcoming_message" value="<?= val('upcoming_message','Episode links are being prepared. Please check back soon.') ?>"></div></div>
  </section>

  <section class="card settings-panel">
    <h2>Sidebar Blocks</h2>
    <label class="check"><input type="checkbox" name="sidebar_featured_enabled" <?= chk('sidebar_featured_enabled','1') ?>> Show Featured Anime slider</label>
    <div class="form-row"><div class="field"><label>Featured Label</label><input class="input" name="sidebar_featured_label" value="<?= val('sidebar_featured_label','Featured') ?>"></div><div class="field"><label>Featured Title</label><input class="input" name="sidebar_featured_title" value="<?= val('sidebar_featured_title','Top Picks') ?>"></div></div>
    <div class="form-row"><div class="field"><label>Featured Count</label><input class="input" type="number" min="1" max="12" name="sidebar_featured_limit" value="<?= val('sidebar_featured_limit','5') ?>"></div><div class="field"><label>Manual Selection</label><a class="btn secondary" href="<?= e(admin_url('featured.php')) ?>">Choose Featured Anime</a><small>Only selected anime will appear. No automatic posts will be shown.</small></div></div>
    <label class="check"><input type="checkbox" name="social_box_enabled" <?= chk('social_box_enabled','1') ?>> Show WhatsApp/Telegram channel box</label>
    <div class="form-row"><div class="field"><label>WhatsApp Channel Link</label><input class="input" name="whatsapp_link" value="<?= val('whatsapp_link','https://whatsapp.com/channel/0029VbCnnx96GcGDAZxFLZ2j') ?>"></div><div class="field"><label>Sidebar Telegram Link</label><input class="input" name="telegram_sidebar_link" value="<?= val('telegram_sidebar_link','https://t.me/animedubhindixyz') ?>"></div></div>
    <label class="check"><input type="checkbox" name="sidebar_menu_links_enabled" <?= chk('sidebar_menu_links_enabled','1') ?>> Show Sidebar Site Menu</label>
    <label class="check"><input type="checkbox" name="sidebar_menu_children_enabled" <?= chk('sidebar_menu_children_enabled','1') ?>> Show submenu links</label>
    <label class="check"><input type="checkbox" name="sidebar_menu_copy_enabled" <?= chk('sidebar_menu_copy_enabled','1') ?>> Show Copy buttons beside links</label>
  </section>

  <section class="card settings-panel">
    <h2>Advertisement</h2>
    <label class="check"><input type="checkbox" name="ad_enabled" <?= chk('ad_enabled','0') ?>> Enable advertisement box</label>
    <label class="check"><input type="checkbox" name="show_empty_ad_box" <?= chk('show_empty_ad_box','0') ?>> Show placeholder when ad is empty</label>
    <label class="check"><input type="checkbox" name="ad_refresh_enabled" <?= chk('ad_refresh_enabled','0') ?>> Auto refresh ad box</label>
    <div class="field"><label>Refresh Seconds</label><input class="input" type="number" min="30" max="3600" name="ad_refresh_seconds" value="<?= val('ad_refresh_seconds','60') ?>"></div>
    <div class="form-row"><div class="field"><label>Ad Title</label><input class="input" name="ad_title" value="<?= val('ad_title','Advertisement') ?>"></div><div class="field"><label>Ad Image URL</label><input class="input" name="ad_image" value="<?= val('ad_image','') ?>"></div></div>
    <div class="field"><label>Ad Click URL</label><input class="input" name="ad_url" value="<?= val('ad_url','#') ?>"></div>
    <div class="field"><label>Custom Ad HTML</label><textarea name="ad_html"><?= e(setting('ad_html','')) ?></textarea></div>
  </section>

  <section class="card settings-panel">
    <h2>Footer</h2>
    <label class="check"><input type="checkbox" name="footer_about_enabled" <?= chk('footer_about_enabled','1') ?>> Show footer brand/about column</label>
    <label class="check"><input type="checkbox" name="footer_quick_links_enabled" <?= chk('footer_quick_links_enabled','1') ?>> Show Quick Links column</label>
    <label class="check"><input type="checkbox" name="footer_support_enabled" <?= chk('footer_support_enabled','1') ?>> Show Support column</label>
    <label class="check"><input type="checkbox" name="footer_legal_enabled" <?= chk('footer_legal_enabled','1') ?>> Show Legal column</label>
    <label class="check"><input type="checkbox" name="footer_community_enabled" <?= chk('footer_community_enabled','1') ?>> Show Community buttons</label>
    <label class="check"><input type="checkbox" name="back_to_top_enabled" <?= chk('back_to_top_enabled','1') ?>> Show back-to-top button</label>
    <div class="field"><label>Footer About Text</label><textarea name="footer_about"><?= e(setting('footer_about','AnimeDubHindi is a clean anime update platform for release details, episode lists and community notices.')) ?></textarea></div>
    <div class="field"><label>Footer Credit</label><input class="input" name="footer_credit" value="<?= val('footer_credit','') ?>"></div>
  </section>

  <section class="card settings-panel">
    <h2>Admin Panel Behavior</h2>
    <div class="form-row"><div class="field"><label>Anime Posts per page</label><input class="input" type="number" min="5" max="50" name="admin_anime_page_size" value="<?= val('admin_anime_page_size','10') ?>"></div><div class="field"><label>Dashboard posts per page</label><input class="input" type="number" min="5" max="50" name="admin_dashboard_page_size" value="<?= val('admin_dashboard_page_size','8') ?>"></div></div>
    <div class="field"><label>Requests/Reports per page</label><input class="input" type="number" min="5" max="50" name="admin_message_page_size" value="<?= val('admin_message_page_size','10') ?>"></div>
  </section>

  <section class="card settings-panel">
    <h2>Analytics</h2>
    <label class="check"><input type="checkbox" name="analytics_enabled" <?= chk('analytics_enabled','1') ?>> Enable lightweight analytics</label>
    <div class="field"><label>Keep analytics for days</label><input class="input" type="number" min="30" max="3650" name="analytics_retention_days" value="<?= val('analytics_retention_days','180') ?>"><small>Old analytics can be cleaned automatically. Raw IP and user-agent are not stored.</small></div>
  </section>

  <div class="settings-savebar"><button class="btn">Save All Settings</button><a class="btn secondary" href="<?= e(url('index.php')) ?>" target="_blank">Preview Website</a></div>
</form>
<?php require __DIR__ . '/_footer.php'; ?>
