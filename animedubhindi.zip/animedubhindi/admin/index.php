<?php
require_once __DIR__ . '/../includes/functions.php';
if (!headers_sent()) { header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0'); header('Pragma: no-cache'); }
if (is_admin_logged_in()) { header('Location: dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (login_is_rate_limited((string)($_POST['username'] ?? '')) || !simple_rate_limit('admin_login', 8, 900)) {
        $error = 'Too many login attempts. Please wait and try again.';
        security_audit_log('login_rate_limited', 'admin');
    } else {
    $stmt = db()->prepare('SELECT * FROM admin_users WHERE username = ? LIMIT 1');
    $stmt->execute([$_POST['username'] ?? '']);
    $user = $stmt->fetch();
    if ($user && password_verify($_POST['password'] ?? '', $user['password_hash'])) {
        record_login_attempt((string)$user['username'], true); session_regenerate_id(true); $_SESSION['admin_id'] = $user['id']; $_SESSION['admin_username'] = $user['username']; $_SESSION['admin_login_time'] = time(); security_audit_log('login_success', (string)$user['username']); if (password_verify('Admin@12345', (string)$user['password_hash'])) { flash('Security warning: change the default admin password now.', 'error'); header('Location: password.php'); exit; } header('Location: dashboard.php'); exit;
    }
    record_login_attempt((string)($_POST['username'] ?? ''), false); security_audit_log('login_failed', (string)($_POST['username'] ?? ''));
    $error = 'Wrong username or password.';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title><link rel="stylesheet" href="<?= e(asset('css/admin.css')) ?>"></head><body><div class="login-wrap"><div class="login-card"><h1>Admin Login</h1><p>Manage website, anime posts, episode links and settings.</p><?php if($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?><form method="post"><?= csrf_field() ?><div class="field"><label>Username</label><input class="input" name="username" autocomplete="username" required></div><div class="field"><label>Password</label><input class="input" type="password" name="password" required></div><button class="btn">Login</button></form><p class="help">Use your admin credentials. Change the default password immediately after installation.</p></div></div></body></html>
