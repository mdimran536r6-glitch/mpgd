<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

$textKeys = [
  'site_name','site_url','site_description','brand_icon_url',
  'default_publisher','default_language','default_quality','request_page_message','report_page_message','contact_page_message',
  'maintenance_message','telegram_text','telegram_link','telegram_popup_text','whatsapp_link','telegram_sidebar_link',
  'homepage_kicker','homepage_title','load_more_label','upcoming_title','upcoming_message'
];
$checkboxKeys = [
  'maintenance_enabled','public_search_enabled','public_request_enabled','public_report_enabled','public_contact_enabled',
  'header_search_enabled','smart_header_enabled','header_telegram_strip_enabled','telegram_popup_enabled',
  'load_more_enabled','show_pinned_badge','card_meta_enabled','card_author_enabled','card_date_enabled',
  'details_breadcrumb_enabled','details_meta_enabled','details_share_enabled','details_synopsis_enabled','details_info_enabled','details_episodes_enabled','details_zip_enabled','details_related_enabled',
  'sidebar_featured_enabled','social_box_enabled','sidebar_menu_links_enabled','sidebar_menu_children_enabled','sidebar_menu_copy_enabled',
  'ad_code_master_enabled','footer_about_enabled','footer_quick_links_enabled','footer_support_enabled','footer_legal_enabled','footer_community_enabled','back_to_top_enabled',
  'analytics_enabled'
];
$numberKeys = [
  'latest_initial_limit'=>[6,60,18], 'similar_posts_limit'=>[3,18,6], 'sidebar_featured_limit'=>[1,12,5],
  'admin_anime_page_size'=>[5,50,10], 'admin_dashboard_page_size'=>[5,50,8], 'admin_message_page_size'=>[5,50,10],
  'admin_session_timeout_minutes'=>[15,720,60], 'analytics_retention_days'=>[30,3650,180]
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  foreach ($textKeys as $k) save_setting($k, (string)($_POST[$k] ?? ''));
  foreach ($checkboxKeys as $k) save_setting($k, !empty($_POST[$k]) ? '1' : '0');
  foreach ($numberKeys as $k=>$rule) {
    [$min,$max,$def] = $rule;
    save_setting($k, (string)max($min, min($max, (int)($_POST[$k] ?? $def))));
  }
  flash('Control Center settings saved. Public website and admin panel will use these values automatically.');
  header('Location: control-center.php'); exit;
}
function cc_chk($key,$default='1'){ return setting($key,$default)==='1'?'checked':''; }
function cc_val($key,$default=''){ return e(setting($key,$default)); }
require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero">
  <div>
    <h1>Control Center</h1>
    <p>Manage the important website, content, community, ad, analytics and admin behavior controls from one clean page.</p>
  </div>
  <div class="admin-actions"><a class="btn secondary" href="<?= e(admin_url('settings.php')) ?>">Full Settings</a><a class="btn secondary" href="<?= e(admin_url('tools.php')) ?>">Website Tools</a><a class="btn" href="<?= e(url('index.php')) ?>" target="_blank">Preview Website</a></div>
</div>

<form method="post" class="settings-pro-grid control-center-form"><?= csrf_field() ?>
  <section class="card settings-panel control-panel-wide">
    <h2>Website Identity</h2>
    <p class="muted">These values are used by header, footer, SEO defaults, sidebar copy links and admin labels.</p>
    <div class="form-row"><div class="field"><label>Website Name</label><input class="input" name="site_name" value="<?= cc_val('site_name','AnimeDubHindi') ?>"></div><div class="field"><label>Live Website URL</label><input class="input" name="site_url" value="<?= cc_val('site_url','https://www.animedubhindi.xyz') ?>"></div></div>
    <div class="field"><label>Default SEO Description</label><input class="input" name="site_description" value="<?= cc_val('site_description','Anime release updates, episode links and download pack information.') ?>"></div>
    <div class="field"><label>Brand Icon URL</label><input class="input" name="brand_icon_url" value="<?= cc_val('brand_icon_url','') ?>" placeholder="Optional image URL"></div>
  </section>

  <section class="card settings-panel">
    <h2>Public Access</h2>
    <label class="check"><input type="checkbox" name="maintenance_enabled" <?= cc_chk('maintenance_enabled','0') ?>> Enable maintenance mode</label>
    <div class="field"><label>Maintenance Message</label><input class="input" name="maintenance_message" value="<?= cc_val('maintenance_message','We are updating the website. Please check back soon.') ?>"></div>
    <label class="check"><input type="checkbox" name="public_search_enabled" <?= cc_chk('public_search_enabled','1') ?>> Enable search page and search suggestions</label>
    <label class="check"><input type="checkbox" name="public_request_enabled" <?= cc_chk('public_request_enabled','1') ?>> Enable Request Anime page</label>
    <label class="check"><input type="checkbox" name="public_report_enabled" <?= cc_chk('public_report_enabled','1') ?>> Enable Broken Link Report page</label>
    <label class="check"><input type="checkbox" name="public_contact_enabled" <?= cc_chk('public_contact_enabled','1') ?>> Enable Contact page</label>
  </section>

  <section class="card settings-panel">
    <h2>Default Texts</h2>
    <div class="field"><label>Default Publisher</label><input class="input" name="default_publisher" value="<?= cc_val('default_publisher','AnimeDubHindi Team') ?>"></div>
    <div class="form-row"><div class="field"><label>Default Language</label><input class="input" name="default_language" value="<?= cc_val('default_language','Hindi Dubbed') ?>"></div><div class="field"><label>Default Quality</label><input class="input" name="default_quality" value="<?= cc_val('default_quality','480p, 720p, 1080p') ?>"></div></div>
    <div class="field"><label>Request Closed Message</label><input class="input" name="request_page_message" value="<?= cc_val('request_page_message','Anime requests are temporarily closed. Please check again later.') ?>"></div>
    <div class="field"><label>Report Closed Message</label><input class="input" name="report_page_message" value="<?= cc_val('report_page_message','Broken link reports are temporarily closed. Please check again later.') ?>"></div>
    <div class="field"><label>Contact Closed Message</label><input class="input" name="contact_page_message" value="<?= cc_val('contact_page_message','Contact messages are temporarily unavailable. Please use our community channels for urgent updates.') ?>"></div>
  </section>

  <section class="card settings-panel">
    <h2>Header & Community</h2>
    <label class="check"><input type="checkbox" name="smart_header_enabled" <?= cc_chk('smart_header_enabled','1') ?>> Smart header hide/show</label>
    <label class="check"><input type="checkbox" name="header_search_enabled" <?= cc_chk('header_search_enabled','1') ?>> Show header search</label>
    <label class="check"><input type="checkbox" name="header_telegram_strip_enabled" <?= cc_chk('header_telegram_strip_enabled','1') ?>> Show join strip below header</label>
    <label class="check"><input type="checkbox" name="telegram_popup_enabled" <?= cc_chk('telegram_popup_enabled','1') ?>> Show community popup</label>
    <div class="field"><label>Join Strip Text</label><input class="input" name="telegram_text" value="<?= cc_val('telegram_text','For more updates join our Telegram channel') ?>"></div>
    <div class="form-row"><div class="field"><label>Telegram Link</label><input class="input" name="telegram_link" value="<?= cc_val('telegram_link','https://t.me/animedubhindixyz') ?>"></div><div class="field"><label>WhatsApp Link</label><input class="input" name="whatsapp_link" value="<?= cc_val('whatsapp_link','https://whatsapp.com/channel/0029VbCnnx96GcGDAZxFLZ2j') ?>"></div></div>
    <div class="field"><label>Popup Text</label><input class="input" name="telegram_popup_text" value="<?= cc_val('telegram_popup_text','Join the official channels for latest anime updates, watch notices and download pack alerts.') ?>"></div>
  </section>

  <section class="card settings-panel">
    <h2>Homepage</h2>
    <div class="form-row"><div class="field"><label>Small Label</label><input class="input" name="homepage_kicker" value="<?= cc_val('homepage_kicker','Fresh Updates') ?>"></div><div class="field"><label>Section Title</label><input class="input" name="homepage_title" value="<?= cc_val('homepage_title','Latest Releases') ?>"></div></div>
    <div class="form-row"><div class="field"><label>First visible posts</label><input class="input" type="number" min="6" max="60" name="latest_initial_limit" value="<?= cc_val('latest_initial_limit','18') ?>"></div><div class="field"><label>Load More Label</label><input class="input" name="load_more_label" value="<?= cc_val('load_more_label','Load More') ?>"></div></div>
    <label class="check"><input type="checkbox" name="load_more_enabled" <?= cc_chk('load_more_enabled','1') ?>> Show Load More</label>
    <label class="check"><input type="checkbox" name="show_pinned_badge" <?= cc_chk('show_pinned_badge','1') ?>> Show pinned badge</label>
    <label class="check"><input type="checkbox" name="card_meta_enabled" <?= cc_chk('card_meta_enabled','1') ?>> Show card meta</label>
    <label class="check"><input type="checkbox" name="card_author_enabled" <?= cc_chk('card_author_enabled','1') ?>> Show author</label>
    <label class="check"><input type="checkbox" name="card_date_enabled" <?= cc_chk('card_date_enabled','1') ?>> Show date</label>
  </section>

  <section class="card settings-panel">
    <h2>Anime Details</h2>
    <label class="check"><input type="checkbox" name="details_breadcrumb_enabled" <?= cc_chk('details_breadcrumb_enabled','1') ?>> Breadcrumb</label>
    <label class="check"><input type="checkbox" name="details_meta_enabled" <?= cc_chk('details_meta_enabled','1') ?>> Published by/date</label>
    <label class="check"><input type="checkbox" name="details_share_enabled" <?= cc_chk('details_share_enabled','1') ?>> Share Anime button</label>
    <label class="check"><input type="checkbox" name="details_synopsis_enabled" <?= cc_chk('details_synopsis_enabled','1') ?>> Synopsis</label>
    <label class="check"><input type="checkbox" name="details_info_enabled" <?= cc_chk('details_info_enabled','1') ?>> Anime information</label>
    <label class="check"><input type="checkbox" name="details_episodes_enabled" <?= cc_chk('details_episodes_enabled','1') ?>> Episode links</label>
    <label class="check"><input type="checkbox" name="details_zip_enabled" <?= cc_chk('details_zip_enabled','1') ?>> ZIP / Pack downloads</label>
    <label class="check"><input type="checkbox" name="details_related_enabled" <?= cc_chk('details_related_enabled','1') ?>> You May Also Like</label>
    <div class="field"><label>Related Anime Count</label><input class="input" type="number" min="3" max="18" name="similar_posts_limit" value="<?= cc_val('similar_posts_limit','6') ?>"></div>
    <div class="field"><label>Upcoming Title</label><input class="input" name="upcoming_title" value="<?= cc_val('upcoming_title','Upcoming') ?>"></div>
    <div class="field"><label>Upcoming Message</label><input class="input" name="upcoming_message" value="<?= cc_val('upcoming_message','Episode links are being prepared. Please check back soon.') ?>"></div>
  </section>

  <section class="card settings-panel">
    <h2>Sidebar & Ads</h2>
    <label class="check"><input type="checkbox" name="sidebar_featured_enabled" <?= cc_chk('sidebar_featured_enabled','1') ?>> Show manual Featured Anime</label>
    <label class="check"><input type="checkbox" name="social_box_enabled" <?= cc_chk('social_box_enabled','1') ?>> Show channel box</label>
    <label class="check"><input type="checkbox" name="sidebar_menu_links_enabled" <?= cc_chk('sidebar_menu_links_enabled','1') ?>> Show Sidebar Site Menu</label>
    <label class="check"><input type="checkbox" name="sidebar_menu_children_enabled" <?= cc_chk('sidebar_menu_children_enabled','1') ?>> Show submenu links</label>
    <label class="check"><input type="checkbox" name="sidebar_menu_copy_enabled" <?= cc_chk('sidebar_menu_copy_enabled','1') ?>> Show copy buttons</label>
    <label class="check"><input type="checkbox" name="ad_code_master_enabled" <?= cc_chk('ad_code_master_enabled','1') ?>> Enable Ad Control scripts/placements</label>
    <div class="form-row"><a class="btn secondary" href="<?= e(admin_url('featured.php')) ?>">Select Featured Anime</a><a class="btn secondary" href="<?= e(admin_url('bulk-control.php')) ?>">Bulk Control</a><a class="btn secondary" href="<?= e(admin_url('ad-control.php')) ?>">Open Ad Control</a><a class="btn secondary" href="<?= e(admin_url('layout-control.php')) ?>">Layout Control</a></div>
  </section>

  <section class="card settings-panel">
    <h2>Footer</h2>
    <label class="check"><input type="checkbox" name="footer_about_enabled" <?= cc_chk('footer_about_enabled','1') ?>> About column</label>
    <label class="check"><input type="checkbox" name="footer_quick_links_enabled" <?= cc_chk('footer_quick_links_enabled','1') ?>> Quick links</label>
    <label class="check"><input type="checkbox" name="footer_support_enabled" <?= cc_chk('footer_support_enabled','1') ?>> Support links</label>
    <label class="check"><input type="checkbox" name="footer_legal_enabled" <?= cc_chk('footer_legal_enabled','1') ?>> Legal links</label>
    <label class="check"><input type="checkbox" name="footer_community_enabled" <?= cc_chk('footer_community_enabled','1') ?>> Community buttons</label>
    <label class="check"><input type="checkbox" name="back_to_top_enabled" <?= cc_chk('back_to_top_enabled','1') ?>> Back-to-top button</label>
  </section>

  <section class="card settings-panel">
    <h2>Admin Behavior</h2>
    <div class="form-row"><div class="field"><label>Session timeout minutes</label><input class="input" type="number" min="15" max="720" name="admin_session_timeout_minutes" value="<?= cc_val('admin_session_timeout_minutes','60') ?>"></div><div class="field"><label>Anime Posts per page</label><input class="input" type="number" min="5" max="50" name="admin_anime_page_size" value="<?= cc_val('admin_anime_page_size','10') ?>"></div></div>
    <div class="form-row"><div class="field"><label>Dashboard posts per page</label><input class="input" type="number" min="5" max="50" name="admin_dashboard_page_size" value="<?= cc_val('admin_dashboard_page_size','8') ?>"></div><div class="field"><label>Requests/Reports per page</label><input class="input" type="number" min="5" max="50" name="admin_message_page_size" value="<?= cc_val('admin_message_page_size','10') ?>"></div></div>
    <label class="check"><input type="checkbox" name="analytics_enabled" <?= cc_chk('analytics_enabled','1') ?>> Enable analytics tracking</label>
    <div class="field"><label>Analytics retention days</label><input class="input" type="number" min="30" max="3650" name="analytics_retention_days" value="<?= cc_val('analytics_retention_days','180') ?>"></div>
  </section>

  <div class="settings-savebar"><button class="btn">Save Control Center</button><a class="btn secondary" href="<?= e(admin_url('guide.php')) ?>">Admin Guide</a></div>
</form>
<?php require __DIR__ . '/_footer.php'; ?>
