<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

function analytics_table_ready(): bool {
  try { db()->query('SELECT 1 FROM analytics_events LIMIT 1'); return true; } catch (Throwable $e) { return false; }
}
function analytics_range_sql(string $range, array &$params): string {
  if ($range === 'today') return 'created_at >= CURDATE()';
  if ($range === '7d') return 'created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
  if ($range === '30d') return 'created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
  return '1=1';
}
function fetch_rows(string $sql, array $params=[]): array {
  try { $st=db()->prepare($sql); $st->execute($params); return $st->fetchAll(); } catch(Throwable $e){ return []; }
}
function fetch_value(string $sql, array $params=[]): int {
  try { $st=db()->prepare($sql); $st->execute($params); return (int)$st->fetchColumn(); } catch(Throwable $e){ return 0; }
}
function one_count(string $event, string $where, array $params): int {
  try { $st=db()->prepare("SELECT COUNT(*) FROM analytics_events WHERE $where AND event_type=?"); $st->execute([...$params,$event]); return (int)$st->fetchColumn(); } catch(Throwable $e){ return 0; }
}
function compact_number($number): string {
  $n = (float)$number;
  $abs = abs($n);
  if ($abs >= 1000000000000) return rtrim(rtrim(number_format($n / 1000000000000, 1), '0'), '.') . 'T';
  if ($abs >= 1000000000) return rtrim(rtrim(number_format($n / 1000000000, 1), '0'), '.') . 'B';
  if ($abs >= 1000000) return rtrim(rtrim(number_format($n / 1000000, 1), '0'), '.') . 'M';
  if ($abs >= 1000) return rtrim(rtrim(number_format($n / 1000, 1), '0'), '.') . 'K';
  return (string)(int)$n;
}
function analytics_url(array $changes = []): string {
  $qs = $_GET;
  foreach($changes as $k=>$v) {
    if ($v === null) unset($qs[$k]); else $qs[$k] = $v;
  }
  return 'analytics.php' . ($qs ? '?' . http_build_query($qs) : '');
}
function pager(string $param, int $page, int $pages): void {
  if ($pages <= 1) return;
  echo '<div class="admin-pager analytics-pager">';
  if ($page > 1) echo '<a class="wide" href="'.e(analytics_url([$param=>$page-1])).'">‹ Prev</a>';
  $shown = [];
  foreach ([1, $page-1, $page, $page+1, $pages] as $p) {
    if ($p >= 1 && $p <= $pages) $shown[$p] = true;
  }
  $last = 0;
  foreach (array_keys($shown) as $p) {
    if ($last && $p > $last + 1) echo '<span>…</span>';
    echo '<a class="'.($p===$page?'active':'').'" href="'.e(analytics_url([$param=>$p])).'">'.$p.'</a>';
    $last = $p;
  }
  if ($page < $pages) echo '<a class="wide" href="'.e(analytics_url([$param=>$page+1])).'">Next ›</a>';
  echo '</div>';
}
$range = $_GET['range'] ?? '30d';
if (!in_array($range, ['today','7d','30d','all'], true)) $range = '30d';
$params = [];
$where = analytics_range_sql($range, $params);

if (isset($_GET['export']) && analytics_table_ready()) {
  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="animedubhindi-analytics-summary-'.date('Y-m-d').'.csv"');
  $out = fopen('php://output', 'w');
  fputcsv($out, ['Metric','Value']);
  foreach(['page_view','anime_view','watch_click','download_click','zip_click','search','request_submit','report_submit'] as $ev) {
    fputcsv($out, [$ev, one_count($ev, $where, $params)]);
  }
  exit;
}

$ready = analytics_table_ready();
$counts = [
  'page_view' => $ready ? one_count('page_view',$where,$params) : 0,
  'anime_view' => $ready ? one_count('anime_view',$where,$params) : 0,
  'watch_click' => $ready ? one_count('watch_click',$where,$params) : 0,
  'download_click' => $ready ? one_count('download_click',$where,$params) : 0,
  'zip_click' => $ready ? one_count('zip_click',$where,$params) : 0,
  'search' => $ready ? one_count('search',$where,$params) : 0,
  'request_submit' => $ready ? one_count('request_submit',$where,$params) : 0,
  'report_submit' => $ready ? one_count('report_submit',$where,$params) : 0,
];
$totalEvents = array_sum($counts);
$actionClicks = $counts['watch_click']+$counts['download_click']+$counts['zip_click'];
$engagement = $counts['anime_view'] ? round(($actionClicks / max(1,$counts['anime_view'])) * 100, 1) : 0;
$rangeLabel = ['today'=>'Today','7d'=>'Last 7 days','30d'=>'Last 30 days','all'=>'All time'][$range];

require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero analytics-hero">
  <div><h1>Analytics</h1><p>Clean overview of traffic, anime views, watches, downloads, searches, requests and reports.</p></div>
  <div class="admin-top-actions"><a class="btn secondary" href="analytics.php?range=<?= e($range) ?>&export=1">Download Summary</a><a class="btn" href="settings.php">Analytics Settings</a></div>
</div>

<?php if(!$ready): ?>
  <div class="notice error">Analytics table is not installed yet. Run <b>install.php</b> and click <b>Install / Repair Database</b>.</div>
<?php else: ?>
  <div class="analytics-filter card">
    <div><b>Current range:</b> <?= e($rangeLabel) ?></div>
    <div class="range-tabs">
      <?php foreach(['today'=>'Today','7d'=>'7 Days','30d'=>'30 Days','all'=>'All Time'] as $key=>$label): ?>
        <a class="<?= $range===$key?'active':'' ?>" href="analytics.php?range=<?= e($key) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="analytics-kpis">
    <div class="analytics-kpi"><span>Total Events</span><b title="<?= (int)$totalEvents ?>"><?= e(compact_number($totalEvents)) ?></b><small>All tracked actions</small></div>
    <div class="analytics-kpi"><span>Page Views</span><b title="<?= (int)$counts['page_view'] ?>"><?= e(compact_number($counts['page_view'])) ?></b><small>General page traffic</small></div>
    <div class="analytics-kpi"><span>Anime Views</span><b title="<?= (int)$counts['anime_view'] ?>"><?= e(compact_number($counts['anime_view'])) ?></b><small>Details page opens</small></div>
    <div class="analytics-kpi"><span>Watch Clicks</span><b title="<?= (int)$counts['watch_click'] ?>"><?= e(compact_number($counts['watch_click'])) ?></b><small>Online player opens</small></div>
    <div class="analytics-kpi"><span>Downloads</span><b title="<?= (int)$counts['download_click'] ?>"><?= e(compact_number($counts['download_click'])) ?></b><small>Episode download clicks</small></div>
    <div class="analytics-kpi"><span>ZIP Clicks</span><b title="<?= (int)$counts['zip_click'] ?>"><?= e(compact_number($counts['zip_click'])) ?></b><small>Batch pack clicks</small></div>
    <div class="analytics-kpi"><span>Requests / Reports</span><b><?= e(compact_number($counts['request_submit'] + $counts['report_submit'])) ?></b><small><?= e(compact_number($counts['request_submit'])) ?> requests · <?= e(compact_number($counts['report_submit'])) ?> reports</small></div>
    <div class="analytics-kpi"><span>Action Rate</span><b><?= e((string)$engagement) ?>%</b><small>Clicks per anime view</small></div>
  </div>


<?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
