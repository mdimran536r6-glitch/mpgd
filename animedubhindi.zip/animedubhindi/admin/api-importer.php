<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

function api_imp_setting(string $key, string $default = ''): string { return setting($key, $default); }
function api_imp_bool(string $key, string $default = '1'): bool { return setting($key, $default) === '1'; }

function api_importer_request_json(string $url, int $timeout = 18): array
{
    $url = trim($url);
    if (!preg_match('#^https?://#i', $url)) {
        return ['ok' => false, 'error' => 'Invalid API URL.', 'status' => 0, 'json' => null];
    }
    $body = null; $status = 0; $error = '';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'User-Agent: AnimeDubHindi-Importer/1.0'],
        ]);
        $body = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        if ($body === false) $error = curl_error($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => ['timeout' => $timeout, 'header' => "Accept: application/json\r\nUser-Agent: AnimeDubHindi-Importer/1.0\r\n"]]);
        $body = @file_get_contents($url, false, $ctx);
        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) $status = (int)$m[1];
        if ($body === false) $error = 'Request failed. Enable cURL for more reliable imports.';
    }
    if ($body === false || $body === null || trim((string)$body) === '') return ['ok'=>false, 'error'=>$error ?: 'Empty API response.', 'status'=>$status, 'json'=>null];
    $json = json_decode((string)$body, true);
    if (!is_array($json)) return ['ok'=>false, 'error'=>'API did not return valid JSON.', 'status'=>$status, 'json'=>null];
    return ['ok'=>($status === 0 || ($status >= 200 && $status < 300)), 'error'=>'', 'status'=>$status, 'json'=>$json];
}

function api_first_value(array $data, array $keys, string $default = ''): string
{
    foreach ($keys as $key) {
        if (!array_key_exists($key, $data)) continue;
        $v = $data[$key];
        if (is_string($v) || is_numeric($v)) { $v = trim((string)$v); if ($v !== '') return $v; }
        if (is_array($v)) {
            $flat = api_first_scalar_from_array($v);
            if ($flat !== '') return $flat;
        }
    }
    return $default;
}

function api_first_scalar_from_array(array $arr): string
{
    foreach ($arr as $v) {
        if (is_string($v) || is_numeric($v)) { $v = trim((string)$v); if ($v !== '') return $v; }
        if (is_array($v)) { $x = api_first_scalar_from_array($v); if ($x !== '') return $x; }
    }
    return '';
}

function api_clean_url_candidate($value): string
{
    if (is_string($value) && preg_match('#^https?://#i', trim($value))) return trim($value);
    if (is_array($value)) {
        foreach (['url','src','image','large','medium','original','poster','cover','thumbnail'] as $k) {
            if (isset($value[$k])) { $u = api_clean_url_candidate($value[$k]); if ($u !== '') return $u; }
        }
        foreach ($value as $v) { $u = api_clean_url_candidate($v); if ($u !== '') return $u; }
    }
    return '';
}

function api_cover_from_item(array $item, array $anime = []): string
{
    foreach ([$anime, $item] as $data) {
        foreach (['poster','poster_url','cover','cover_image','coverImage','image','image_url','thumbnail','thumbnail_url','banner','banner_image'] as $k) {
            if (isset($data[$k])) { $u = api_clean_url_candidate($data[$k]); if ($u !== '') return $u; }
        }
    }
    return '';
}

function api_extract_recent_items(array $json): array
{
    foreach ([['data'], ['results'], ['anime'], ['items'], ['recent'], ['rows']] as $path) {
        $node = $json;
        foreach ($path as $p) { if (is_array($node) && array_key_exists($p, $node)) $node = $node[$p]; else { $node = null; break; } }
        if (is_array($node) && array_is_list($node)) return $node;
    }
    if (isset($json['data']) && is_array($json['data'])) {
        foreach (['anime','results','items','rows','recent'] as $k) if (isset($json['data'][$k]) && is_array($json['data'][$k]) && array_is_list($json['data'][$k])) return $json['data'][$k];
    }
    if (array_is_list($json)) return $json;
    return [];
}

function api_extract_detail_anime(array $json): array
{
    foreach ([['anime'], ['data','anime'], ['data'], ['series']] as $path) {
        $node = $json;
        foreach ($path as $p) { if (is_array($node) && array_key_exists($p, $node)) $node = $node[$p]; else { $node = null; break; } }
        if (is_array($node) && !array_is_list($node)) return $node;
    }
    return [];
}

function api_extract_episodes(array $json): array
{
    foreach ([['episodes'], ['data','episodes'], ['anime','episodes'], ['data','anime','episodes']] as $path) {
        $node = $json;
        foreach ($path as $p) { if (is_array($node) && array_key_exists($p, $node)) $node = $node[$p]; else { $node = null; break; } }
        if (is_array($node) && array_is_list($node)) return $node;
    }
    return [];
}

function api_extract_genres(array $item, array $anime = []): string
{
    $values = [];
    foreach ([$anime, $item] as $data) {
        foreach (['genres','genre','categories','tags'] as $k) {
            if (!isset($data[$k])) continue;
            $v = $data[$k];
            if (is_string($v)) $values[] = $v;
            if (is_array($v)) {
                foreach ($v as $g) {
                    if (is_string($g)) $values[] = $g;
                    elseif (is_array($g)) $values[] = api_first_value($g, ['name','title','label']);
                }
            }
        }
        if (isset($data['terms_by_type']) && is_array($data['terms_by_type'])) {
            foreach (['genre','genres','category'] as $k) {
                if (!empty($data['terms_by_type'][$k]) && is_array($data['terms_by_type'][$k])) {
                    foreach ($data['terms_by_type'][$k] as $g) $values[] = is_array($g) ? api_first_value($g, ['name','title','label']) : (string)$g;
                }
            }
        }
    }
    $values = array_values(array_unique(array_filter(array_map(fn($x)=>clean_text((string)$x, 40), $values))));
    return mb_substr(implode(' | ', $values), 0, 240);
}

function api_embed_urls_from_episode(array $ep): array
{
    $out = [];
    $embed = $ep['embed_url'] ?? $ep['embedUrl'] ?? $ep['embed'] ?? $ep['embeds'] ?? null;
    if (is_string($embed) && preg_match('#^https?://#i', $embed)) $out[] = ['label'=>'Watch Online', 'url'=>$embed, 'lang'=>''];
    if (is_array($embed)) {
        foreach (['sub'=>'Sub', 'dub'=>'Dub', 'hindi'=>'Hindi', 'hi'=>'Hindi', 'eng'=>'English'] as $key=>$label) {
            if (isset($embed[$key])) { $u = api_clean_url_candidate($embed[$key]); if ($u !== '') $out[] = ['label'=>$label, 'url'=>$u, 'lang'=>$label]; }
        }
        foreach ($embed as $key=>$value) {
            $u = api_clean_url_candidate($value);
            if ($u !== '') $out[] = ['label'=>is_string($key)?ucfirst($key):'Watch Online', 'url'=>$u, 'lang'=>is_string($key)?ucfirst($key):''];
        }
    }
    foreach (['watch_url','watchUrl','player_url','playerUrl','iframe','url'] as $k) {
        if (isset($ep[$k])) { $u = api_clean_url_candidate($ep[$k]); if ($u !== '') $out[] = ['label'=>'Watch Online', 'url'=>$u, 'lang'=>'']; }
    }
    $seen = []; $clean = [];
    foreach ($out as $o) { if (empty($o['url']) || isset($seen[$o['url']])) continue; $seen[$o['url']] = true; $clean[] = $o; }
    return $clean;
}

function api_language_from_links(array $episodes): string
{
    $labels = [];
    foreach ($episodes as $ep) {
        foreach (api_embed_urls_from_episode($ep) as $u) {
            $lang = trim((string)($u['lang'] ?? ''));
            $label = trim((string)($u['label'] ?? ''));
            $value = $lang !== '' ? $lang : $label;
            if ($value !== '' && !preg_match('/^(watch online|online player|player|server)$/i', $value)) $labels[] = $value;
        }
    }
    $clean = [];
    foreach ($labels as $label) {
        $key = strtolower($label);
        if ($key === 'hi') $label = 'Hindi';
        if ($key === 'eng') $label = 'English';
        if (!in_array($label, $clean, true)) $clean[] = $label;
    }
    return $clean ? implode(' | ', $clean) : 'Not specified';
}

function api_release_value(array $item, array $animeData): string
{
    foreach ([$animeData, $item] as $data) {
        foreach (['release_date','released_at','aired','aired_from','start_date','published_at','date','year','release_year','released'] as $key) {
            $value = api_first_value($data, [$key]);
            if ($value !== '') return clean_text($value, 40);
        }
    }
    return '';
}

function api_import_one_anikoto(array $item, string $baseUrl, bool $updateExisting = false): array
{
    $sourceName = 'anikoto';
    $sourceId = api_first_value($item, ['id','anime_id','series_id','slug']);
    if ($sourceId === '') return ['status'=>'skipped', 'message'=>'Skipped one item: missing source id.'];

    $map = db()->prepare('SELECT anime_id FROM api_import_map WHERE source_name=? AND source_id=? LIMIT 1');
    $map->execute([$sourceName, $sourceId]);
    $mappedId = (int)$map->fetchColumn();
    if ($mappedId > 0 && !$updateExisting) return ['status'=>'duplicate', 'message'=>'Already imported source id ' . $sourceId . '.'];

    $detail = api_importer_request_json(rtrim($baseUrl, '/') . '/series/' . rawurlencode($sourceId));
    if (!$detail['ok']) return ['status'=>'failed', 'message'=>'Series failed for id ' . $sourceId . ': ' . $detail['error']];
    $animeData = api_extract_detail_anime($detail['json'] ?: []);
    $episodes = api_extract_episodes($detail['json'] ?: []);

    $title = api_first_value($animeData, ['title','name','anime_title'], api_first_value($item, ['title','name','anime_title'], ''));
    $title = clean_text($title, 240);
    if ($title === '') return ['status'=>'skipped', 'message'=>'Skipped source id ' . $sourceId . ': missing title.'];

    $existingByTitle = db()->prepare('SELECT id FROM anime WHERE slug=? OR title=? LIMIT 1');
    $slug = unique_slug($title);
    $existingByTitle->execute([slugify($title), $title]);
    $existingId = (int)$existingByTitle->fetchColumn();
    if ($existingId > 0 && !$updateExisting && $mappedId <= 0) {
        db()->prepare('INSERT IGNORE INTO api_import_map(source_name,source_id,anime_id,source_url,import_status,last_seen_at) VALUES(?,?,?,?,?,NOW())')->execute([$sourceName,$sourceId,$existingId,rtrim($baseUrl,'/').'/series/'.$sourceId,'duplicate']);
        return ['status'=>'duplicate', 'message'=>'Duplicate title skipped: ' . $title];
    }

    $description = clean_text(api_first_value($animeData, ['description','synopsis','summary'], api_first_value($item, ['description','synopsis','summary'], '')), 6000);
    $cover = safe_external_url(api_cover_from_item($item, $animeData));
    $genres = api_extract_genres($item, $animeData);
    $type = api_first_value($animeData, ['type','format'], api_first_value($item, ['type','format'], 'Series'));
    $type = preg_match('/movie/i', $type) ? 'Movie' : 'Series';
    $status = api_first_value($animeData, ['status'], api_first_value($item, ['status'], 'Ongoing'));
    $status = clean_text($status ?: 'Ongoing', 60);
    $year = api_release_value($item, $animeData);
    $totalEpisodes = (string)(count($episodes) ?: api_first_value($animeData, ['total_episodes','episodes','episode_count'], api_first_value($item, ['total_episodes','episodes','episode_count'], '')));
    $language = api_language_from_links($episodes);
    $quality = 'Online';
    $publishedBy = setting('default_publisher','AnimeDubHindi Team') ?: 'AnimeDubHindi Team';
    $seoTitle = mb_substr($title . ' Watch Online - ' . setting('site_name','AnimeDubHindi'), 0, 250);
    $seoDesc = mb_substr($description ?: ($title . ' watch links and episode list.'), 0, 250);

    if ($mappedId > 0 || $existingId > 0) {
        $animeId = $mappedId ?: $existingId;
        if ($updateExisting) {
            $stmt = db()->prepare('UPDATE anime SET title=?, cover_image=COALESCE(NULLIF(?,\'\'), cover_image), type=?, status=?, language=?, quality=?, total_episodes=?, release_year=?, genres=?, synopsis=COALESCE(NULLIF(?,\'\'), synopsis), seo_title=?, seo_description=?, updated_at=NOW() WHERE id=?');
            $stmt->execute([$title,$cover,$type,$status,$language,$quality,$totalEpisodes,$year,$genres,$description,$seoTitle,$seoDesc,$animeId]);
        }
    } else {
        $stmt = db()->prepare('INSERT INTO anime(title,slug,cover_image,type,status,language,quality,total_episodes,release_year,genres,synopsis,published_by,content_status,show_zip_section,is_pinned,is_featured,seo_title,seo_description,published_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())');
        $stmt->execute([$title,$slug,$cover,$type,$status,$language,$quality,$totalEpisodes,$year,$genres,$description,$publishedBy,'draft',0,0,0,$seoTitle,$seoDesc]);
        $animeId = (int)db()->lastInsertId();
    }

    db()->prepare('INSERT INTO api_import_map(source_name,source_id,anime_id,source_url,import_status,last_seen_at) VALUES(?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE anime_id=VALUES(anime_id), import_status=VALUES(import_status), last_seen_at=NOW()')->execute([$sourceName,$sourceId,$animeId,rtrim($baseUrl,'/').'/series/'.$sourceId,'imported']);

    $epCount = 0; $linkCount = 0;
    foreach ($episodes as $i => $ep) {
        $epNoRaw = api_first_value($ep, ['episode_number','episode','number','ep'], (string)($i + 1));
        $epNo = max(1, (int)preg_replace('/[^0-9]/', '', $epNoRaw));
        $titleEp = clean_text(api_first_value($ep, ['title','name'], ''), 240);
        $epFind = db()->prepare('SELECT id FROM episodes WHERE anime_id=? AND episode_number=? LIMIT 1');
        $epFind->execute([$animeId,$epNo]);
        $episodeId = (int)$epFind->fetchColumn();
        if (!$episodeId) {
            db()->prepare('INSERT INTO episodes(anime_id,title,episode_number,upload_date,sort_order,is_active) VALUES(?,?,?,?,?,1)')->execute([$animeId,$titleEp,$epNo,date('Y-m-d'),$epNo]);
            $episodeId = (int)db()->lastInsertId(); $epCount++;
        }
        foreach (api_embed_urls_from_episode($ep) as $idx => $embed) {
            $u = safe_external_url($embed['url'] ?? '');
            if ($u === '') continue;
            $exists = db()->prepare('SELECT id FROM episode_links WHERE episode_id=? AND url=? AND link_type=\'watch\' LIMIT 1');
            $exists->execute([$episodeId,$u]);
            if ($exists->fetchColumn()) continue;
            $hostName = clean_text(($embed['label'] ?: 'Watch Online'), 100);
            db()->prepare('INSERT INTO episode_links(episode_id,quality,host_name,url,link_type,sort_order,is_active) VALUES(?,?,?,?,?,?,1)')->execute([$episodeId,'',$hostName,$u,'watch',$idx]);
            $linkCount++;
        }
    }
    return ['status'=>'imported', 'message'=>'Imported draft: ' . $title . ' (' . $epCount . ' new episodes, ' . $linkCount . ' watch links).'];
}

function api_importer_page_url(array $overrides=[]): string
{
    $params = array_merge($_GET, $overrides);
    return 'api-importer.php?' . http_build_query($params);
}

$resultLog = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $baseUrl = rtrim(trim($_POST['anikoto_base_url'] ?? setting('api_import_anikoto_base_url','http://anikotoapi.site')), '/');
    if ($baseUrl === '') $baseUrl = 'http://anikotoapi.site';
    save_setting('api_import_anikoto_base_url', $baseUrl);
    if ($action === 'test_anikoto') {
        $test = api_importer_request_json($baseUrl . '/recent-anime?page=1&per_page=1');
        flash($test['ok'] ? 'Anikoto API responded successfully.' : ('Anikoto API test failed: ' . $test['error']), $test['ok'] ? 'success' : 'error');
        header('Location: api-importer.php'); exit;
    }
    if ($action === 'reset_anikoto_cursor') {
        save_setting('api_import_anikoto_next_page', '1');
        flash('Anikoto import cursor reset to page 1.');
        header('Location: api-importer.php'); exit;
    }
    if ($action === 'import_anikoto') {
        $start = max(1, (int)($_POST['start_page'] ?? setting('api_import_anikoto_next_page','1')));
        $pages = max(1, min(10, (int)($_POST['pages'] ?? '2')));
        $perPage = max(1, min(30, (int)($_POST['per_page'] ?? setting('api_import_anikoto_per_page','10'))));
        $updateExisting = !empty($_POST['update_existing']);
        save_setting('api_import_anikoto_per_page', (string)$perPage);
        $imported = $duplicates = $failed = $episodes = 0;
        for ($page = $start; $page < $start + $pages; $page++) {
            $url = $baseUrl . '/recent-anime?page=' . $page . '&per_page=' . $perPage;
            $res = api_importer_request_json($url, 20);
            if (!$res['ok']) { $resultLog[] = 'Page ' . $page . ' failed: ' . $res['error']; $failed++; break; }
            $items = api_extract_recent_items($res['json'] ?: []);
            if (!$items) { $resultLog[] = 'Page ' . $page . ': no items returned. Import stopped.'; break; }
            foreach ($items as $item) {
                if (!is_array($item)) continue;
                $one = api_import_one_anikoto($item, $baseUrl, $updateExisting);
                $resultLog[] = $one['message'];
                if ($one['status'] === 'imported') $imported++;
                elseif ($one['status'] === 'duplicate') $duplicates++;
                else $failed++;
            }
            save_setting('api_import_anikoto_next_page', (string)($page + 1));
            usleep(350000); // Keep the public API from being hit too aggressively.
        }
        $_SESSION['api_import_log'] = array_slice($resultLog, -100);
        flash('Import finished. Imported: ' . $imported . ', duplicates: ' . $duplicates . ', skipped/failed: ' . $failed . '.');
        header('Location: api-importer.php'); exit;
    }
}

$log = $_SESSION['api_import_log'] ?? [];
unset($_SESSION['api_import_log']);
$nextPage = (int)setting('api_import_anikoto_next_page','1');
$perPage = (int)setting('api_import_anikoto_per_page','10');
$base = setting('api_import_anikoto_base_url','http://anikotoapi.site');
$totalImported = 0;
try { $totalImported = (int)db()->query("SELECT COUNT(*) FROM api_import_map WHERE source_name='anikoto'")->fetchColumn(); } catch (Throwable $e) {}
include __DIR__ . '/_header.php';
?>
<section class="admin-card hero-admin-card">
  <div>
    <h1>API Importer</h1>
    <p>Import anime as drafts using verified free API sources. Design and public layout stay unchanged.</p>
  </div>
  <a class="btn" href="anime.php?content_status=draft">View Drafts</a>
</section>

<div class="stats-grid compact-stats">
  <div class="stat-card"><span>Source</span><b>Anikoto</b></div>
  <div class="stat-card"><span>Imported map</span><b><?= e((string)$totalImported) ?></b></div>
  <div class="stat-card"><span>Next page</span><b><?= e((string)$nextPage) ?></b></div>
  <div class="stat-card"><span>Status</span><b>Draft-only</b></div>
</div>

<section class="admin-card">
  <h2>Anikoto API Import</h2>
  <p class="muted">Uses <code>/recent-anime</code> for listings and <code>/series/{id}</code> for episode watch embeds. Imported posts stay <b>Draft</b> until you publish them manually.</p>
  <form method="post" class="admin-form-grid">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="import_anikoto">
    <div class="field"><label>Base URL</label><input class="input" name="anikoto_base_url" value="<?= e($base) ?>"><small>Default: http://anikotoapi.site</small></div>
    <div class="field"><label>Start page</label><input class="input" type="number" min="1" name="start_page" value="<?= e((string)$nextPage) ?>"><small>Use the saved next page to continue without duplicates.</small></div>
    <div class="field"><label>Pages this run</label><input class="input" type="number" min="1" max="10" name="pages" value="2"><small>Keep small to avoid timeout/rate limit.</small></div>
    <div class="field"><label>Per page</label><input class="input" type="number" min="1" max="30" name="per_page" value="<?= e((string)$perPage) ?>"><small>Anikoto docs support page and per_page.</small></div>
    <label class="check-row"><input type="checkbox" name="update_existing" value="1"> Update existing imported drafts when source changes</label>
    <div class="form-actions wide-actions"><button class="btn" type="submit">Import Draft Anime</button></div>
  </form>
  <div class="inline-actions">
    <form method="post" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="test_anikoto"><input type="hidden" name="anikoto_base_url" value="<?= e($base) ?>"><button class="btn btn-light" type="submit">Test API</button></form>
    <form method="post" class="inline-form" data-confirm-title="Reset import cursor?" data-confirm-message="This will start the next import from page 1 again. Duplicates are still skipped."><?= csrf_field() ?><input type="hidden" name="action" value="reset_anikoto_cursor"><button class="btn btn-danger-soft" type="submit">Reset Cursor</button></form>
  </div>
</section>

<section class="admin-card">
  <h2>Importer Rules</h2>
  <div class="guide-grid small-guide-grid">
    <div><b>Draft only</b><p>Nothing imported here appears publicly until you publish it.</p></div>
    <div><b>No redesign</b><p>It uses your existing anime, episode, and watch tables only.</p></div>
    <div><b>Deduplication</b><p>Duplicates are blocked by source id and by title/slug.</p></div>
    <div><b>Cover source</b><p>Cover image is saved from anime/list/detail data, not from episode video.</p></div>
    <div><b>Watch source</b><p>Episode embeds become Watch Online links in the existing player.</p></div>
    <div><b>No download bypass</b><p>Importer does not create download links from this source.</p></div>
  </div>
</section>

<?php if ($log): ?>
<section class="admin-card">
  <h2>Last Import Log</h2>
  <div class="log-list">
    <?php foreach($log as $line): ?><div class="log-line"><?= e($line) ?></div><?php endforeach; ?>
  </div>
</section>
<?php endif; ?>
<?php include __DIR__ . '/_footer.php'; ?>
