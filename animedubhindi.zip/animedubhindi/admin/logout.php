<?php
require_once __DIR__ . '/../includes/functions.php';
if (!empty($_SESSION['admin_id']) && !verify_csrf()) { http_response_code(403); exit('Security check failed. Please go back and try again.'); }
security_audit_log('logout', (string)($_SESSION['admin_username'] ?? 'admin'));
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();
header('Location: index.php');
exit;
