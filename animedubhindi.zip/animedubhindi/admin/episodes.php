<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

$anime_id = (int)($_REQUEST['anime_id'] ?? 0);
function back_to_episodes(int $anime_id): void { header('Location: episodes.php?anime_id=' . $anime_id); exit; }

try {
  if (isset($_GET['toggle_ep'])) {
    require_csrf();
    $id=(int)$_GET['toggle_ep'];
    $s=db()->prepare('SELECT is_active FROM episodes WHERE id=?'); $s->execute([$id]);
    $cur=(int)$s->fetchColumn();
    db()->prepare('UPDATE episodes SET is_active=? WHERE id=?')->execute([$cur?0:1,$id]);
    flash($cur?'Episode hidden from website.':'Episode shown on website.'); back_to_episodes($anime_id);
  }
  if (isset($_GET['toggle_link'])) {
    require_csrf();
    $id=(int)$_GET['toggle_link'];
    $s=db()->prepare('SELECT is_active FROM episode_links WHERE id=?'); $s->execute([$id]);
    $cur=(int)$s->fetchColumn();
    db()->prepare('UPDATE episode_links SET is_active=? WHERE id=?')->execute([$cur?0:1,$id]);
    flash($cur?'Link hidden from website.':'Link shown on website.'); back_to_episodes($anime_id);
  }
  if (isset($_GET['toggle_zip'])) {
    require_csrf();
    $id=(int)$_GET['toggle_zip'];
    $s=db()->prepare('SELECT is_active FROM full_season_links WHERE id=?'); $s->execute([$id]);
    $cur=(int)$s->fetchColumn();
    db()->prepare('UPDATE full_season_links SET is_active=? WHERE id=?')->execute([$cur?0:1,$id]);
    flash($cur?'ZIP/pack hidden from website.':'ZIP/pack shown on website.'); back_to_episodes($anime_id);
  }
  if (isset($_GET['delete_ep'])) {
    require_csrf();
    $epId=(int)$_GET['delete_ep'];
    db()->prepare('DELETE FROM episode_links WHERE episode_id=?')->execute([$epId]);
    db()->prepare('DELETE FROM episodes WHERE id=?')->execute([$epId]);
    flash('Episode and its links deleted.'); back_to_episodes($anime_id);
  }
  if (isset($_GET['delete_link'])) {
    require_csrf(); db()->prepare('DELETE FROM episode_links WHERE id=?')->execute([(int)$_GET['delete_link']]); flash('Link deleted.'); back_to_episodes($anime_id); }
  if (isset($_GET['delete_zip'])) {
    require_csrf(); db()->prepare('DELETE FROM full_season_links WHERE id=?')->execute([(int)$_GET['delete_zip']]); flash('ZIP / pack deleted.'); back_to_episodes($anime_id); }
} catch (Throwable $e) { flash($e->getMessage(),'error'); back_to_episodes($anime_id); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
  try {
    if ($anime_id<=0) throw new RuntimeException('Select an anime first.');
    $type=$_POST['form_type'] ?? '';
    if ($type==='episode') {
      $episodeId=(int)($_POST['episode_id'] ?? 0);
      $data=[trim($_POST['title'] ?? ''),(int)($_POST['episode_number'] ?? 1),$_POST['upload_date'] ?: date('Y-m-d'),trim($_POST['notes'] ?? ''),(int)($_POST['sort_order'] ?? 0),!empty($_POST['is_active'])?1:0];
      if($episodeId>0){$data[]=$episodeId; db()->prepare('UPDATE episodes SET title=?, episode_number=?, upload_date=?, notes=?, sort_order=?, is_active=? WHERE id=?')->execute($data); flash('Episode updated.');}
      else{array_unshift($data,$anime_id); db()->prepare('INSERT INTO episodes(anime_id,title,episode_number,upload_date,notes,sort_order,is_active) VALUES(?,?,?,?,?,?,?)')->execute($data); flash('Episode added.');}
    }
    if ($type==='link') {
      $linkId=(int)($_POST['link_id'] ?? 0); $episodeId=(int)($_POST['episode_id'] ?? 0);
      if($episodeId<=0) throw new RuntimeException('Select an episode before adding a link.');
      $url=safe_external_url((string)($_POST['url'] ?? '')); if($url==='') throw new RuntimeException('A valid https/http external URL is required.');
      $linkType=($_POST['link_type'] ?? 'download')==='watch'?'watch':'download';
      $quality=$linkType==='watch'?'':trim($_POST['quality'] ?? '');
      $host=trim($_POST['host_name'] ?? '');
      $data=[$episodeId,$quality,$host,$url,$linkType,(int)($_POST['sort_order'] ?? 0),!empty($_POST['is_active'])?1:0];
      if($linkId>0){$data[]=$linkId; db()->prepare('UPDATE episode_links SET episode_id=?, quality=?, host_name=?, url=?, link_type=?, sort_order=?, is_active=? WHERE id=?')->execute($data); flash('Episode link updated.');}
      else{db()->prepare('INSERT INTO episode_links(episode_id,quality,host_name,url,link_type,sort_order,is_active) VALUES(?,?,?,?,?,?,?)')->execute($data); flash($linkType==='watch'?'Watch Online link added.':'Download link added.');}
    }
    if ($type==='zip') {
      $zipId=(int)($_POST['zip_id'] ?? 0); $url=safe_external_url((string)($_POST['zip_url'] ?? '')); if($url==='') throw new RuntimeException('A valid https/http ZIP / pack URL is required.');
      $data=[$anime_id,trim($_POST['pack_title'] ?? 'ZIP Pack'),trim($_POST['episode_range'] ?? ''),trim($_POST['zip_quality'] ?? ''),trim($_POST['zip_host_name'] ?? ''),trim($_POST['file_size'] ?? ''),$url,(int)($_POST['zip_sort_order'] ?? 0),trim($_POST['zip_notes'] ?? ''),!empty($_POST['is_active'])?1:0];
      if($zipId>0){array_shift($data); $data[]=$zipId; db()->prepare('UPDATE full_season_links SET pack_title=?, episode_range=?, quality=?, host_name=?, file_size=?, url=?, sort_order=?, notes=?, is_active=? WHERE id=?')->execute($data); flash('ZIP / pack updated.');}
      else{db()->prepare('INSERT INTO full_season_links(anime_id,pack_title,episode_range,quality,host_name,file_size,url,sort_order,notes,is_active) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute($data); flash('ZIP / pack added.');}
    }
  } catch(Throwable $e) { flash($e->getMessage(),'error'); }
  back_to_episodes($anime_id);
}

$episodeSearch = trim($_GET['q'] ?? '');
$episodeTypeFilter = trim($_GET['type'] ?? '');
$episodeContentFilter = trim($_GET['content_status'] ?? '');
$episodeStatusFilter = trim($_GET['anime_status'] ?? '');
$episodeLanguageFilter = trim($_GET['language'] ?? '');
$languageOptions = admin_language_options();
$animeWhere = ['1']; $animeParams = [];
if($episodeSearch !== ''){ $animeWhere[] = '(title LIKE ? OR genres LIKE ? OR language LIKE ? OR published_by LIKE ?)'; $like='%'.$episodeSearch.'%'; array_push($animeParams,$like,$like,$like,$like); }
if(in_array($episodeTypeFilter, ['Series','Movie'], true)){ $animeWhere[]='type=?'; $animeParams[]=$episodeTypeFilter; }
if(in_array($episodeContentFilter, ['draft','published','unpublished'], true)){ $animeWhere[]="COALESCE(content_status,'published')=?"; $animeParams[]=$episodeContentFilter; }
if(in_array($episodeStatusFilter, ['Ongoing','Completed','Upcoming'], true)){ $animeWhere[]='status=?'; $animeParams[]=$episodeStatusFilter; }
if($episodeLanguageFilter !== ''){ $animeWhere[]='language=?'; $animeParams[]=$episodeLanguageFilter; }
$animeSql = 'SELECT id,title,type,status,content_status,is_pinned,published_at FROM anime WHERE '.implode(' AND ', $animeWhere).' ORDER BY is_pinned DESC, published_at DESC, title ASC';
$animeStmt = db()->prepare($animeSql); $animeStmt->execute($animeParams); $allAnime = $animeStmt->fetchAll();
if(!$anime_id && $allAnime) $anime_id=(int)$allAnime[0]['id'];
$anime=null; if($anime_id){$s=db()->prepare('SELECT * FROM anime WHERE id=?');$s->execute([$anime_id]);$anime=$s->fetch();}
$isMovie = $anime && strtolower((string)($anime['type'] ?? '')) === 'movie';
$episodes=[];$links=[];$zipLinks=[];$counts=[];
foreach($allAnime as $a){
  $cs=db()->prepare('SELECT COUNT(*) FROM episodes WHERE anime_id=?');$cs->execute([(int)$a['id']]);
  $ls=db()->prepare('SELECT COUNT(*) FROM episode_links WHERE episode_id IN (SELECT id FROM episodes WHERE anime_id=?)');$ls->execute([(int)$a['id']]);
  $zs=db()->prepare('SELECT COUNT(*) FROM full_season_links WHERE anime_id=?');$zs->execute([(int)$a['id']]);
  $counts[(int)$a['id']]=['episodes'=>(int)$cs->fetchColumn(),'links'=>(int)$ls->fetchColumn(),'zips'=>(int)$zs->fetchColumn()];
}
if($anime){
  $s=db()->prepare('SELECT * FROM episodes WHERE anime_id=? ORDER BY sort_order ASC, episode_number ASC, id ASC');$s->execute([$anime_id]);$episodes=$s->fetchAll();
  foreach($episodes as $ep){$l=db()->prepare('SELECT * FROM episode_links WHERE episode_id=? ORDER BY sort_order ASC, link_type DESC, quality DESC, id ASC');$l->execute([(int)$ep['id']]);$links[(int)$ep['id']]=$l->fetchAll();}
  $z=db()->prepare('SELECT * FROM full_season_links WHERE anime_id=? ORDER BY sort_order ASC, id ASC');$z->execute([$anime_id]);$zipLinks=$z->fetchAll();
}
require __DIR__ . '/_header.php';
?>
<div class="admin-top">
  <div><h1>Episode / Movie Link Manager</h1><p>Search an anime, then open only the movie, episode, link or pack item you want to edit.</p></div>
  <a class="btn secondary" href="anime.php">Back to Anime</a>
</div>

<div class="card anime-manager-card">
  <div class="card-title-row"><h2>Anime List</h2><small><?= count($allAnime) ?> posts</small></div>
  <form class="admin-filter-grid episode-filter-grid" method="get" action="episodes.php">
    <input class="input" name="q" value="<?= e($episodeSearch) ?>" placeholder="Search anime title, genre, language...">
    <select name="type"><option value="">All types</option><option value="Series" <?= $episodeTypeFilter==='Series'?'selected':'' ?>>Series</option><option value="Movie" <?= $episodeTypeFilter==='Movie'?'selected':'' ?>>Movie</option></select>
    <select name="content_status"><option value="">All visibility</option><option value="draft" <?= $episodeContentFilter==='draft'?'selected':'' ?>>Draft</option><option value="published" <?= $episodeContentFilter==='published'?'selected':'' ?>>Published</option><option value="unpublished" <?= $episodeContentFilter==='unpublished'?'selected':'' ?>>Unpublished</option></select>
    <select name="anime_status"><option value="">All statuses</option><option value="Ongoing" <?= $episodeStatusFilter==='Ongoing'?'selected':'' ?>>Ongoing</option><option value="Completed" <?= $episodeStatusFilter==='Completed'?'selected':'' ?>>Completed</option><option value="Upcoming" <?= $episodeStatusFilter==='Upcoming'?'selected':'' ?>>Upcoming</option></select>
    <select name="language"><option value="">All languages</option><?php foreach($languageOptions as $lo): ?><option value="<?= e($lo) ?>" <?= $episodeLanguageFilter===$lo?'selected':'' ?>><?= e($lo) ?></option><?php endforeach; ?></select>
    <button class="btn small">Filter</button>
    <a class="btn small secondary" href="episodes.php">Reset</a>
  </form>
  <div class="field anime-filter-field"><label>Quick filter current list</label><input class="input" data-admin-anime-filter placeholder="Type anime title..."></div>
  <div class="admin-anime-list clean-anime-list">
    <?php foreach($allAnime as $a): $selected=$anime_id===(int)$a['id']; $c=$counts[(int)$a['id']]; ?>
      <article class="anime-pick-row <?= $selected?'selected':'' ?>" data-anime-pick data-title="<?= e($a['title']) ?>">
        <div class="anime-pick-title"><b><?= e($a['title']) ?></b><?php if($a['is_pinned']): ?><em>Pinned</em><?php endif; ?></div>
        <div class="anime-pick-counts"><span><?= $c['episodes'] ?> Items</span><span><?= $c['links'] ?> Links</span><span><?= $c['zips'] ?> Packs</span></div>
        <a class="btn small <?= $selected?'':'secondary' ?>" href="episodes.php?anime_id=<?= (int)$a['id'] ?>&q=<?= e(urlencode($episodeSearch)) ?>&type=<?= e(urlencode($episodeTypeFilter)) ?>&content_status=<?= e(urlencode($episodeContentFilter)) ?>&anime_status=<?= e(urlencode($episodeStatusFilter)) ?>&language=<?= e(urlencode($episodeLanguageFilter)) ?>">Manage</a>
      </article>
    <?php endforeach; ?>
    <?php if(!$allAnime): ?><div class="help">No anime post found. Go to Anime Posts → Add Anime first.</div><?php endif; ?>
  </div>
</div>

<?php if($anime): ?>
<div class="selected-anime-title"><span>Selected</span><h2><?= e($anime['title']) ?></h2></div>

<div class="grid grid-3 editor-grid">
  <form class="card compact-admin-form" method="post"><?= csrf_field() ?>
    <input type="hidden" name="form_type" value="episode"><input type="hidden" name="anime_id" value="<?= $anime_id ?>">
    <h2><?= $isMovie ? 'Add Movie Item' : 'Add Episode' ?></h2>
    <div class="form-row"><div class="field"><label><?= $isMovie ? 'Movie Item Number' : 'Episode Number' ?></label><input class="input" type="number" name="episode_number" value="1"></div><div class="field"><label>Upload Date</label><input class="input" type="date" name="upload_date" value="<?= date('Y-m-d') ?>"></div></div>
    <input type="hidden" name="title" value=""><input type="hidden" name="notes" value="">
    <div class="field"><label>Sort Order</label><input class="input" type="number" name="sort_order" value="0"></div>
    <label class="check"><input type="checkbox" name="is_active" checked> Show on website</label>
    <button class="btn"><?= $isMovie ? 'Add Movie Item' : 'Add Episode' ?></button>
  </form>

  <form class="card compact-admin-form" method="post"><?= csrf_field() ?>
    <input type="hidden" name="form_type" value="link"><input type="hidden" name="anime_id" value="<?= $anime_id ?>">
    <h2><?= $isMovie ? 'Add Movie Link' : 'Add Episode Link' ?></h2>
    <?php if($episodes): ?>
    <div class="field"><label><?= $isMovie ? 'Movie Item' : 'Episode' ?></label><select name="episode_id"><?php foreach($episodes as $ep): ?><option value="<?= (int)$ep['id'] ?>"><?= $isMovie ? 'Movie' : 'Episode ' . e(str_pad((string)$ep['episode_number'],2,'0',STR_PAD_LEFT)) ?></option><?php endforeach; ?></select></div>
    <div class="form-row"><div class="field"><label>Button Type</label><select name="link_type"><option value="watch">Watch Online</option><option value="download">Download</option></select><small>Watch links appear above all download qualities.</small></div><div class="field"><label>Quality <small>download only</small></label><input class="input" name="quality" placeholder="1080p / 720p / 480p"><small>Leave empty for Watch Online.</small></div></div>
    <div class="field"><label>Language / Server Label</label><input class="input" name="host_name" placeholder="Sub / Dub / Hindi / Server 1"><small>For Watch Online, this becomes the language/server button name.</small></div>
    <div class="field"><label>External URL</label><input class="input" name="url" placeholder="https://pixeldrain.com/u/..." required></div>
    <div class="field"><label>Sort Order</label><input class="input" type="number" name="sort_order" value="0"></div>
    <label class="check"><input type="checkbox" name="is_active" checked> Show on website</label>
    <button class="btn">Add Link</button>
    <?php else: ?><div class="help">Add <?= $isMovie ? 'a movie item' : 'an episode' ?> first, then add Watch Online or Download links.</div><?php endif; ?>
  </form>

  <form class="card compact-admin-form" method="post"><?= csrf_field() ?>
    <input type="hidden" name="form_type" value="zip"><input type="hidden" name="anime_id" value="<?= $anime_id ?>">
    <h2>Add ZIP / Pack Part</h2>
    <div class="field"><label>Pack Title</label><input class="input" name="pack_title" placeholder="Episodes 01-06 ZIP"></div>
    <div class="form-row"><div class="field"><label>Episode Range</label><input class="input" name="episode_range" placeholder="EP 01-06"></div><div class="field"><label>Quality</label><input class="input" name="zip_quality" placeholder="720p"></div></div>
    <div class="form-row"><div class="field"><label>Host Name</label><input class="input" name="zip_host_name" placeholder="Drive / Mega"></div><div class="field"><label>File Size</label><input class="input" name="file_size" placeholder="1.8GB"></div></div>
    <div class="field"><label>ZIP / Pack Link</label><input class="input" name="zip_url" placeholder="https://..." required></div>
    <div class="form-row"><div class="field"><label>Sort Order</label><input class="input" type="number" name="zip_sort_order" value="0"></div><div class="field"><label>Note</label><input class="input" name="zip_notes" placeholder="Optional note"></div></div>
    <label class="check"><input type="checkbox" name="is_active" checked> Show on website</label>
    <button class="btn">Add ZIP Part</button>
  </form>
</div>

<div class="card admin-episode-card">
  <h2><?= $isMovie ? 'Movie Items' : 'Episodes' ?></h2><small>Closed by default. Click the arrow to edit the item, watch link or download links.</small>
  <?php if(!$episodes): ?><div class="help">No episode added yet.</div><?php else: ?>
  <div class="admin-episode-list">
    <?php foreach($episodes as $ep): $epLinks=$links[(int)$ep['id']]??[]; $watchCount=0; foreach($epLinks as $tmp){if(($tmp['link_type']??'download')==='watch')$watchCount++;} ?>
    <details class="admin-episode-item">
      <summary><b><?= $isMovie ? 'Movie' : 'Episode ' . e(str_pad((string)$ep['episode_number'],2,'0',STR_PAD_LEFT)) ?></b><span><?= e($ep['upload_date'] ?: '-') ?></span><small><?= count($epLinks) ?> links • <?= $watchCount ?> watch</small><?php if(!(int)$ep['is_active']): ?><em>Hidden</em><?php endif; ?></summary>
      <div class="admin-episode-body">
        <form class="edit-panel" method="post"><?= csrf_field() ?>
          <input type="hidden" name="form_type" value="episode"><input type="hidden" name="anime_id" value="<?= $anime_id ?>"><input type="hidden" name="episode_id" value="<?= (int)$ep['id'] ?>"><input type="hidden" name="title" value=""><input type="hidden" name="notes" value="">
          <div class="form-row"><div class="field"><label><?= $isMovie ? 'Movie Item Number' : 'Episode Number' ?></label><input class="input" type="number" name="episode_number" value="<?= (int)$ep['episode_number'] ?>"></div><div class="field"><label>Upload Date</label><input class="input" type="date" name="upload_date" value="<?= e($ep['upload_date']) ?>"></div><div class="field"><label>Sort Order</label><input class="input" type="number" name="sort_order" value="<?= (int)$ep['sort_order'] ?>"></div></div>
          <label class="check"><input type="checkbox" name="is_active" <?= (int)$ep['is_active']?'checked':'' ?>> Show <?= $isMovie ? 'movie item' : 'episode' ?></label>
          <div class="actions"><button class="btn small">Save <?= $isMovie ? 'Movie Item' : 'Episode' ?></button><a class="btn small secondary" href="<?= e(csrf_url('episodes.php?anime_id='.$anime_id.'&toggle_ep='.(int)$ep['id'])) ?>"><?= (int)$ep['is_active']?'Hide':'Show' ?></a><a class="btn small danger" onclick="return confirm('Delete this episode and all its links?')" href="<?= e(csrf_url('episodes.php?anime_id='.$anime_id.'&delete_ep='.(int)$ep['id'])) ?>">Delete</a></div>
        </form>
        <div class="link-card-list"><h3>Links</h3><?php if(!$epLinks): ?><p class="muted">No link yet.</p><?php endif; ?>
          <?php foreach($epLinks as $l): ?>
          <form class="link-edit-card clean-link-edit" method="post"><?= csrf_field() ?>
            <input type="hidden" name="form_type" value="link"><input type="hidden" name="anime_id" value="<?= $anime_id ?>"><input type="hidden" name="link_id" value="<?= (int)$l['id'] ?>"><input type="hidden" name="episode_id" value="<?= (int)$ep['id'] ?>">
            <div class="field"><label>Type</label><select name="link_type"><option value="watch" <?= ($l['link_type']??'download')==='watch'?'selected':'' ?>>Watch Online</option><option value="download" <?= ($l['link_type']??'download')==='download'?'selected':'' ?>>Download</option></select></div>
            <div class="field"><label>Quality</label><input name="quality" value="<?= e($l['quality']) ?>" placeholder="Download only"></div>
            <div class="field"><label>Language / Host</label><input name="host_name" value="<?= e($l['host_name']) ?>" placeholder="Sub / Dub / Hindi / Host"></div>
            <div class="field wide"><label>URL</label><input name="url" value="<?= e($l['url']) ?>" placeholder="URL"></div>
            <div class="field"><label>Order</label><input type="number" name="sort_order" value="<?= (int)$l['sort_order'] ?>"></div>
            <label class="check"><input type="checkbox" name="is_active" <?= (int)$l['is_active']?'checked':'' ?>> Show</label>
            <button class="btn small">Save</button><a class="btn small secondary" target="_blank" href="<?= e(($l['link_type']??'download')==='watch' ? '../watch.php?link_id='.(int)$l['id'] : $l['url']) ?>">Preview</a><a class="btn small secondary" href="<?= e(csrf_url('episodes.php?anime_id='.$anime_id.'&toggle_link='.(int)$l['id'])) ?>"><?= (int)$l['is_active']?'Hide':'Show' ?></a><a class="btn small danger" onclick="return confirm('Delete link?')" href="<?= e(csrf_url('episodes.php?anime_id='.$anime_id.'&delete_link='.(int)$l['id'])) ?>">Delete</a>
          </form>
          <?php endforeach; ?>
        </div>
      </div>
    </details>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<div class="card admin-zip-card">
  <h2><?= $isMovie ? 'Extra / Original File Packs' : 'ZIP / Pack Parts' ?></h2><small>Closed by default. Optional; keep hidden/off unless you want extra files or split packs.</small>
  <?php if(!$zipLinks): ?><div class="help">No ZIP / pack link added yet.</div><?php else: ?>
  <div class="zip-admin-list">
    <?php foreach($zipLinks as $z): ?>
    <details class="zip-admin-item">
      <summary><b><?= e($z['pack_title'] ?: 'ZIP Pack') ?></b><span><?= e($z['episode_range'] ?: '-') ?></span><small><?= e($z['quality'] ?: 'HD') ?><?= $z['file_size'] ? ' • '.e($z['file_size']) : '' ?></small><?php if(!(int)$z['is_active']): ?><em>Hidden</em><?php endif; ?></summary>
      <form class="zip-edit-card" method="post"><?= csrf_field() ?><input type="hidden" name="form_type" value="zip"><input type="hidden" name="anime_id" value="<?= $anime_id ?>"><input type="hidden" name="zip_id" value="<?= (int)$z['id'] ?>">
        <div class="form-row"><div class="field"><label>Pack title</label><input name="pack_title" value="<?= e($z['pack_title']) ?>" placeholder="Pack title"></div><div class="field"><label>EP range</label><input name="episode_range" value="<?= e($z['episode_range']) ?>" placeholder="EP range"></div></div>
        <div class="form-row"><div class="field"><label>Quality</label><input name="zip_quality" value="<?= e($z['quality']) ?>" placeholder="720p / 1080p"></div><div class="field"><label>Host</label><input name="zip_host_name" value="<?= e($z['host_name']) ?>" placeholder="Host"></div></div>
        <div class="form-row"><div class="field"><label>Size</label><input name="file_size" value="<?= e($z['file_size']) ?>" placeholder="Size"></div><div class="field"><label>Sort</label><input type="number" name="zip_sort_order" value="<?= (int)$z['sort_order'] ?>"></div></div>
        <div class="field"><label>URL</label><input name="zip_url" value="<?= e($z['url']) ?>" placeholder="URL"></div><div class="field"><label>Note</label><input name="zip_notes" value="<?= e($z['notes']) ?>" placeholder="Note"></div>
        <label class="check"><input type="checkbox" name="is_active" <?= (int)$z['is_active']?'checked':'' ?>> Show ZIP pack</label>
        <div class="actions"><button class="btn small">Save ZIP</button><a class="btn small secondary" href="<?= e(csrf_url('episodes.php?anime_id='.$anime_id.'&toggle_zip='.(int)$z['id'])) ?>"><?= (int)$z['is_active']?'Hide':'Show' ?></a><a class="btn small danger" onclick="return confirm('Delete ZIP link?')" href="<?= e(csrf_url('episodes.php?anime_id='.$anime_id.'&delete_zip='.(int)$z['id'])) ?>">Delete</a></div>
      </form>
    </details>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php endif; require __DIR__ . '/_footer.php'; ?>
