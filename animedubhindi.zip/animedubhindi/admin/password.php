<?php
require_once __DIR__ . '/../includes/functions.php'; require_admin();
require_admin_csrf_for_post();
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(($_POST['new_password']??'') !== ($_POST['confirm_password']??'')){ flash('Passwords do not match.','error'); }
    elseif(strlen($_POST['new_password']??'')<12){ flash('Password must be at least 12 characters.','error'); }
    elseif(!preg_match('/[A-Z]/', $_POST['new_password']??'') || !preg_match('/[a-z]/', $_POST['new_password']??'') || !preg_match('/[0-9]/', $_POST['new_password']??'') || !preg_match('/[^A-Za-z0-9]/', $_POST['new_password']??'')){ flash('Use uppercase, lowercase, number and symbol.','error'); }
    elseif(($_POST['new_password']??'') === 'Admin@12345'){ flash('Do not reuse the default password.','error'); }
    else{ $hash=password_hash($_POST['new_password'], PASSWORD_DEFAULT); db()->prepare('UPDATE admin_users SET password_hash=? WHERE id=?')->execute([$hash,$_SESSION['admin_id']]); save_setting('admin_password_changed', '1'); security_audit_log('password_changed', (string)($_SESSION['admin_username'] ?? 'admin')); flash('Password changed.'); }
    header('Location: password.php'); exit;
}
require __DIR__ . '/_header.php'; ?>
<div class="admin-top"><div><h1>Change Password</h1><p>Use a strong password with uppercase, lowercase, number and symbol. Do not reuse the default password.</p></div></div>
<form class="card" method="post"><?= csrf_field() ?><div class="field"><label>New Password</label><input class="input" type="password" name="new_password" required></div><div class="field"><label>Confirm Password</label><input class="input" type="password" name="confirm_password" required></div><button class="btn">Update Password</button></form>
<?php require __DIR__ . '/_footer.php'; ?>
