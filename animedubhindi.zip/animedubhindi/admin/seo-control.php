<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

$textKeys = ['seo_google_verification','seo_bing_verification','seo_yandex_verification','seo_naver_verification','seo_indexnow_key','seo_default_robots_meta','seo_google_analytics_id','seo_google_tag_manager_id','seo_microsoft_clarity_id','seo_facebook_pixel_id','seo_custom_head_codes','seo_custom_body_start_codes','seo_custom_body_end_codes'];
$checkboxKeys = ['seo_control_enabled','seo_robots_enabled','seo_allow_ai_bots','seo_sitemap_enabled','seo_sitemap_legal_enabled','seo_sitemap_anime_enabled','seo_sitemap_static_enabled','seo_indexnow_enabled','seo_schema_enabled','seo_og_enabled','seo_twitter_enabled','seo_auto_ping_enabled'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';
    if ($action === 'generate_indexnow') {
        $key = bin2hex(random_bytes(16));
        save_setting('seo_indexnow_key', $key);
        save_setting('seo_indexnow_enabled', '1');
        flash('IndexNow key generated. Submit the key URL shown on this page if your search engine asks for it.');
    } else {
        foreach ($textKeys as $k) save_setting($k, trim((string)($_POST[$k] ?? '')));
        foreach ($checkboxKeys as $k) save_setting($k, !empty($_POST[$k]) ? '1' : '0');
        flash('SEO Control settings saved. Robots and sitemap will update automatically.');
    }
    header('Location: seo-control.php'); exit;
}
function seo_chk($key,$default='1'){ return seo_setting($key,$default)==='1'?'checked':''; }
function seo_val($key,$default=''){ return e(seo_setting($key,$default)); }
$base = site_base_url();
$sitemapCount = count(sitemap_pages());
$indexKey = trim(seo_setting('seo_indexnow_key',''));
require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero">
  <div><h1>SEO Control</h1><p>Control robots.txt, sitemap.xml, search-engine verification, AI crawler access and index submission settings from one professional panel.</p></div>
  <a class="btn secondary" href="<?= e($base) ?>/sitemap.xml" target="_blank">View Sitemap</a>
  <a class="btn secondary" href="<?= e($base) ?>/robots.txt" target="_blank">View Robots</a>
</div>

<div class="stats-grid">
  <div class="stat-card"><span>Sitemap URLs</span><b><?= e((string)$sitemapCount) ?></b></div>
  <div class="stat-card"><span>Robots.txt</span><b><?= seo_setting('seo_robots_enabled','1')==='1'?'On':'Off' ?></b></div>
  <div class="stat-card"><span>AI Crawlers</span><b><?= seo_setting('seo_allow_ai_bots','1')==='1'?'Allowed':'Blocked' ?></b></div>
  <div class="stat-card"><span>Schema</span><b><?= seo_setting('seo_schema_enabled','1')==='1'?'On':'Off' ?></b></div>
</div>

<form class="settings-pro-grid" method="post"><?= csrf_field() ?>
  <section class="card settings-panel">
    <h2>Robots.txt & AI Crawlers</h2>
    <label class="check"><input type="checkbox" name="seo_control_enabled" <?= seo_chk('seo_control_enabled','1') ?>> Enable SEO Control</label>
    <label class="check"><input type="checkbox" name="seo_robots_enabled" <?= seo_chk('seo_robots_enabled','1') ?>> Generate robots.txt</label>
    <label class="check"><input type="checkbox" name="seo_allow_ai_bots" <?= seo_chk('seo_allow_ai_bots','1') ?>> Allow AI crawlers such as GPTBot, ChatGPT-User, OAI-SearchBot, ClaudeBot, PerplexityBot, Google-Extended, Applebot and CCBot</label>
    <div class="field"><label>Default robots meta</label><input class="input" name="seo_default_robots_meta" value="<?= seo_val('seo_default_robots_meta','index,follow,max-image-preview:large') ?>"><small>Recommended: index,follow,max-image-preview:large</small></div>
    <p class="muted">Public pages are allowed. Admin, includes, database, storage and installer files stay blocked for security.</p>
  </section>

  <section class="card settings-panel">
    <h2>Sitemap.xml</h2>
    <label class="check"><input type="checkbox" name="seo_sitemap_enabled" <?= seo_chk('seo_sitemap_enabled','1') ?>> Enable sitemap.xml</label>
    <label class="check"><input type="checkbox" name="seo_sitemap_static_enabled" <?= seo_chk('seo_sitemap_static_enabled','1') ?>> Include homepage, movies, series, genres and search</label>
    <label class="check"><input type="checkbox" name="seo_sitemap_anime_enabled" <?= seo_chk('seo_sitemap_anime_enabled','1') ?>> Include all anime posts</label>
    <label class="check"><input type="checkbox" name="seo_sitemap_legal_enabled" <?= seo_chk('seo_sitemap_legal_enabled','1') ?>> Include legal/contact/request/report pages</label>
    <div class="seo-url-box"><b>Sitemap URL</b><code><?= e($base) ?>/sitemap.xml</code></div>
  </section>

  <section class="card settings-panel">
    <h2>Search Engine Verification</h2>
    <div class="field"><label>Google Search Console verification code</label><input class="input" name="seo_google_verification" value="<?= seo_val('seo_google_verification','') ?>" placeholder="Paste only the content value"></div>
    <div class="field"><label>Bing Webmaster verification code</label><input class="input" name="seo_bing_verification" value="<?= seo_val('seo_bing_verification','') ?>" placeholder="msvalidate.01 content value"></div>
    <div class="field"><label>Yandex verification code</label><input class="input" name="seo_yandex_verification" value="<?= seo_val('seo_yandex_verification','') ?>"></div>
    <div class="field"><label>Naver verification code</label><input class="input" name="seo_naver_verification" value="<?= seo_val('seo_naver_verification','') ?>"></div>
  </section>

  <section class="card settings-panel">
    <h2>Analytics & Tracking Codes</h2>
    <p class="muted">Add multiple verification, analytics or tracking codes without editing files. Keep one code per field or paste multiple meta/script tags in the custom boxes.</p>
    <div class="field"><label>Google Analytics / GA4 Measurement ID</label><input class="input" name="seo_google_analytics_id" value="<?= seo_val('seo_google_analytics_id','') ?>" placeholder="G-XXXXXXXXXX"></div>
    <div class="field"><label>Google Tag Manager ID</label><input class="input" name="seo_google_tag_manager_id" value="<?= seo_val('seo_google_tag_manager_id','') ?>" placeholder="GTM-XXXXXXX"></div>
    <div class="field"><label>Microsoft Clarity Project ID</label><input class="input" name="seo_microsoft_clarity_id" value="<?= seo_val('seo_microsoft_clarity_id','') ?>" placeholder="Clarity project ID"></div>
    <div class="field"><label>Facebook / Meta Pixel ID</label><input class="input" name="seo_facebook_pixel_id" value="<?= seo_val('seo_facebook_pixel_id','') ?>" placeholder="Pixel ID"></div>
  </section>

  <section class="card settings-panel settings-wide">
    <h2>Multiple Custom Codes</h2>
    <p class="muted">Use these boxes for extra Google verification tags, additional webmaster tools, Pinterest, Ahrefs, custom analytics, chat widgets, or any future code. Scripts are printed exactly where they belong.</p>
    <div class="field"><label>Extra Head Codes</label><textarea class="input code-area" name="seo_custom_head_codes" rows="7" placeholder="Paste multiple meta/script tags for the &lt;head&gt; here"><?= seo_val('seo_custom_head_codes','') ?></textarea><small>Best for verification meta tags, GA/Clarity head snippets, Search Console alternates.</small></div>
    <div class="field"><label>After Body Start Codes</label><textarea class="input code-area" name="seo_custom_body_start_codes" rows="5" placeholder="Paste GTM noscript/body-start code here"><?= seo_val('seo_custom_body_start_codes','') ?></textarea><small>Best for Google Tag Manager noscript or body-start tracking code.</small></div>
    <div class="field"><label>Before Body End Codes</label><textarea class="input code-area" name="seo_custom_body_end_codes" rows="5" placeholder="Paste footer/body-end scripts here"><?= seo_val('seo_custom_body_end_codes','') ?></textarea><small>Best for chat widgets, heatmap tools, and scripts that should load after the page.</small></div>
  </section>

  <section class="card settings-panel">
    <h2>Schema & Social Preview</h2>
    <label class="check"><input type="checkbox" name="seo_schema_enabled" <?= seo_chk('seo_schema_enabled','1') ?>> Enable JSON-LD schema</label>
    <label class="check"><input type="checkbox" name="seo_og_enabled" <?= seo_chk('seo_og_enabled','1') ?>> Enable Open Graph tags for Telegram/Facebook previews</label>
    <label class="check"><input type="checkbox" name="seo_twitter_enabled" <?= seo_chk('seo_twitter_enabled','1') ?>> Enable Twitter/X card tags</label>
  </section>

  <section class="card settings-panel">
    <h2>IndexNow</h2>
    <label class="check"><input type="checkbox" name="seo_indexnow_enabled" <?= seo_chk('seo_indexnow_enabled','0') ?>> Enable IndexNow support</label>
    <label class="check"><input type="checkbox" name="seo_auto_ping_enabled" <?= seo_chk('seo_auto_ping_enabled','0') ?>> Auto ping new/updated URLs when implemented by hosting</label>
    <div class="field"><label>IndexNow API key</label><input class="input" name="seo_indexnow_key" value="<?= seo_val('seo_indexnow_key','') ?>" placeholder="Generate or paste your IndexNow key"></div>
    <?php if ($indexKey !== ''): ?><div class="seo-url-box"><b>IndexNow key URL</b><code><?= e($base . '/' . preg_replace('/[^A-Za-z0-9_-]/','',$indexKey) . '.txt') ?></code></div><?php endif; ?>
  </section>

  <section class="card settings-panel">
    <h2>Submit / Verify Checklist</h2>
    <div class="seo-submit-grid">
      <a class="btn secondary" href="https://search.google.com/search-console" target="_blank" rel="noopener">Google Search Console</a>
      <a class="btn secondary" href="https://www.bing.com/webmasters" target="_blank" rel="noopener">Bing Webmaster</a>
      <a class="btn secondary" href="https://webmaster.yandex.com" target="_blank" rel="noopener">Yandex Webmaster</a>
      <a class="btn secondary" href="https://searchadvisor.naver.com" target="_blank" rel="noopener">Naver Search Advisor</a>
      <a class="btn secondary" href="https://webmaster.baidu.com" target="_blank" rel="noopener">Baidu Webmaster</a>
      <a class="btn secondary" href="https://search.seznam.cz/pridat-stranku" target="_blank" rel="noopener">Seznam Submit</a>
      <a class="btn secondary" href="https://www.google.com/ping?sitemap=<?= urlencode($base . '/sitemap.xml') ?>" target="_blank" rel="noopener">Google Sitemap Ping</a>
    </div>
    <ol class="admin-guide-list">
      <li>Connect domain and SSL first.</li>
      <li>Submit <b><?= e($base) ?>/sitemap.xml</b> to Google and Bing.</li>
      <li>Paste verification codes above and save.</li>
      <li>Publish unique synopsis, information, episode links and FAQ-style details for each anime page.</li>
      <li>Do not block public pages in robots.txt unless you intentionally want them hidden.</li>
    </ol>
  </section>

  <div class="settings-savebar"><button class="btn">Save SEO Settings</button><button class="btn secondary" name="action" value="generate_indexnow" type="submit">Generate IndexNow Key</button></div>
</form>
<?php require __DIR__ . '/_footer.php'; ?>
