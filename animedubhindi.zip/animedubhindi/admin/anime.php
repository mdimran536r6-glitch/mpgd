<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

$action = $_GET['action'] ?? 'list';
$id = (int)($_GET['id'] ?? 0);

function admin_back_url(string $fallback = 'anime.php'): string {
    $url = $_POST['return_to'] ?? $_GET['return_to'] ?? $fallback;
    $parts = parse_url($url);
    if (!$parts || !empty($parts['scheme']) || !empty($parts['host'])) return $fallback;
    return $url;
}
function admin_build_url(array $extra = [], string $base = 'anime.php'): string {
    $qs = array_merge($_GET, $extra);
    foreach ($qs as $k => $v) { if ($v === null || $v === '') unset($qs[$k]); }
    return $base . ($qs ? '?' . http_build_query($qs) : '');
}
function admin_list_pager(string $base, int $page, int $pages, array $keep = []): void {
    if ($pages <= 1) return;
    echo '<nav class="admin-pager" aria-label="Pagination">';
    $start = max(1, $page - 2); $end = min($pages, $page + 2);
    if ($page > 1) { $qs = array_merge($keep, ['page' => $page - 1]); echo '<a href="'.e($base.'?'.http_build_query($qs)).'">Prev</a>'; }
    if ($start > 1) { $qs = array_merge($keep, ['page' => 1]); echo '<a href="'.e($base.'?'.http_build_query($qs)).'">1</a>'; if ($start > 2) echo '<span>…</span>'; }
    for ($i=$start; $i<=$end; $i++) { $qs = array_merge($keep, ['page' => $i]); $cls=$i===$page?'active':''; echo '<a class="'.$cls.'" href="'.e($base.'?'.http_build_query($qs)).'">'.$i.'</a>'; }
    if ($end < $pages) { if ($end < $pages-1) echo '<span>…</span>'; $qs = array_merge($keep, ['page' => $pages]); echo '<a href="'.e($base.'?'.http_build_query($qs)).'">'.$pages.'</a>'; }
    if ($page < $pages) { $qs = array_merge($keep, ['page' => $page + 1]); echo '<a href="'.e($base.'?'.http_build_query($qs)).'">Next</a>'; }
    echo '</nav>';
}

if (isset($_GET['delete'])) {
    require_csrf(); // get mutation
    $aid=(int)$_GET['delete'];
    db()->prepare('DELETE FROM episode_links WHERE episode_id IN (SELECT id FROM episodes WHERE anime_id=?)')->execute([$aid]);
    db()->prepare('DELETE FROM episodes WHERE anime_id=?')->execute([$aid]);
    db()->prepare('DELETE FROM full_season_links WHERE anime_id=?')->execute([$aid]);
    db()->prepare('DELETE FROM anime WHERE id=?')->execute([$aid]);
    flash('Anime deleted.');
    header('Location: '.admin_back_url('anime.php')); exit;
}
if (isset($_GET['pin'])) {
    require_csrf(); // get mutation
    $aid=(int)$_GET['pin'];
    $s=db()->prepare('SELECT is_pinned FROM anime WHERE id=?'); $s->execute([$aid]); $cur=(int)$s->fetchColumn();
    db()->prepare('UPDATE anime SET is_pinned=? WHERE id=?')->execute([$cur?0:1,$aid]);
    flash($cur?'Removed from pinned.':'Pinned successfully. Pinned posts show first inside Latest Releases.');
    header('Location: '.admin_back_url('anime.php')); exit;
}

if (isset($_GET['set_status'])) {
    require_csrf();
    $aid = (int)($_GET['anime_id'] ?? 0);
    $newStatus = strtolower((string)$_GET['set_status']);
    if (!in_array($newStatus, ['draft','published','unpublished'], true)) $newStatus = 'draft';
    db()->prepare('UPDATE anime SET content_status=?, updated_at=NOW() WHERE id=?')->execute([$newStatus, $aid]);
    flash('Post status changed to '.content_status_label($newStatus).'.');
    header('Location: '.admin_back_url('anime.php')); exit;
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    try{
        $postId=(int)($_POST['id']??0); $title=trim($_POST['title']??''); if(!$title) throw new RuntimeException('Title is required.');
        $oldCover = $_POST['old_cover'] ?? null;
        $coverUrl = trim($_POST['cover_image_url'] ?? '');
        $hasCoverUpload = !empty($_FILES['cover_image']['name']) && is_uploaded_file($_FILES['cover_image']['tmp_name']);
        if ($hasCoverUpload) {
            $cover = upload_cover('cover_image', $oldCover);
        } elseif ($coverUrl !== '') {
            $cover = clean_external_cover_url($coverUrl);
        } else {
            $cover = $oldCover;
        }
        $slugInput = trim($_POST['slug']??''); $slug = $slugInput ? slugify($slugInput) : unique_slug($title,'anime',$postId); $slug = unique_slug($slug,'anime',$postId);
        $contentStatus = $_POST['save_action'] ?? ($_POST['content_status'] ?? setting('default_content_status','draft'));
        if (!in_array($contentStatus, ['draft','published','unpublished'], true)) $contentStatus = 'draft';
        $data = [$title,$slug,$cover,$_POST['type']??'Series',$_POST['status']??'Ongoing',$_POST['language']??setting('default_language','Hindi Dubbed'),$_POST['quality']??setting('default_quality','480p, 720p, 1080p'),$_POST['total_episodes']??'',$_POST['release_year']??'',$_POST['rating']??'',$_POST['genres']??'',$_POST['synopsis']??'',$_POST['official_by']??'',$_POST['encoder']??'',$_POST['published_by']??setting('default_publisher','AnimeDubHindi Team'),$contentStatus,!empty($_POST['is_pinned'])?1:0,!empty($_POST['is_featured'])?1:0,!empty($_POST['show_zip_section'])?1:0,$_POST['seo_title']??'',$_POST['seo_description']??'',$_POST['published_at'] ?: date('Y-m-d H:i:s')];
        $isFeatured = !empty($_POST['is_featured']);
        if($postId){
            $data[]=$postId;
            db()->prepare('UPDATE anime SET title=?,slug=?,cover_image=?,type=?,status=?,language=?,quality=?,total_episodes=?,release_year=?,rating=?,genres=?,synopsis=?,official_by=?,encoder=?,published_by=?,content_status=?,is_pinned=?,is_featured=?,show_zip_section=?,seo_title=?,seo_description=?,published_at=?,updated_at=NOW() WHERE id=?')->execute($data);
            flash('Anime saved as '.content_status_label($contentStatus).'.');
        } else {
            db()->prepare('INSERT INTO anime(title,slug,cover_image,type,status,language,quality,total_episodes,release_year,rating,genres,synopsis,official_by,encoder,published_by,content_status,is_pinned,is_featured,show_zip_section,seo_title,seo_description,published_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute($data);
            $postId = (int)db()->lastInsertId();
            flash('Anime created as '.content_status_label($contentStatus).'.');
        }
        try {
            db()->exec("CREATE TABLE IF NOT EXISTS sidebar_featured_anime (id INT AUTO_INCREMENT PRIMARY KEY, anime_id INT NOT NULL UNIQUE, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_sidebar_featured_active (is_active, sort_order), INDEX idx_sidebar_featured_anime (anime_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            if ($isFeatured) {
                $nextOrder = (int)db()->query('SELECT COALESCE(MAX(sort_order),0)+1 FROM sidebar_featured_anime')->fetchColumn();
                $fs = db()->prepare('INSERT INTO sidebar_featured_anime(anime_id, sort_order, is_active) VALUES(?,?,1) ON DUPLICATE KEY UPDATE is_active=1');
                $fs->execute([$postId, $nextOrder]);
            } else {
                db()->prepare('DELETE FROM sidebar_featured_anime WHERE anime_id=?')->execute([$postId]);
            }
        } catch (Throwable $e) {}
        header('Location: '.admin_back_url('anime.php')); exit;
    }catch(Throwable $e){
        flash($e->getMessage(),'error');
        header('Location: anime.php'.($postId?'?action=edit&id='.$postId:'?action=add')); exit;
    }
}

$row=null; if($id){ $s=db()->prepare('SELECT * FROM anime WHERE id=?'); $s->execute([$id]); $row=$s->fetch(); }
require __DIR__ . '/_header.php';
?>
<?php if($action==='add' || ($action==='edit' && $row)): ?>
<div class="admin-top"><div><h1><?= $row?'Edit Anime':'Add Anime' ?></h1><p>Add the full details once. The homepage, search, genre pages and details page update automatically.</p></div><a class="btn secondary" href="<?= e(admin_back_url('anime.php')) ?>">Back</a></div>
<form class="card" method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($row['id']??0) ?>"><input type="hidden" name="old_cover" value="<?= e($row['cover_image']??'') ?>"><input type="hidden" name="return_to" value="<?= e(admin_back_url('anime.php')) ?>">
  <h2>Publish Workflow</h2>
  <div class="workflow-panel">
    <div class="field"><label>Post Visibility</label><select name="content_status">
      <?php $cs = $row['content_status'] ?? setting('default_content_status','draft'); ?>
      <option value="draft" <?= $cs==='draft'?'selected':'' ?>>Draft - save privately</option>
      <option value="published" <?= $cs==='published'?'selected':'' ?>>Published - visible on website</option>
      <option value="unpublished" <?= $cs==='unpublished'?'selected':'' ?>>Unpublished - hidden from website</option>
    </select><small>Draft/unpublished posts are hidden from public pages. Use Preview to check before publishing.</small></div>
    <?php if($row): ?><a class="btn secondary" target="_blank" href="<?= e('../anime.php?slug='.urlencode($row['slug']).'&preview=1') ?>">Preview Post</a><?php endif; ?>
  </div>
  <h2>Basic Details</h2>
  <div class="field"><label>Anime Title</label><input class="input" name="title" required value="<?= e($row['title']??'') ?>" placeholder="Example: Sample Hero Academy Season 1 Hindi Dubbed"></div>
  <div class="form-row"><div class="field"><label>Slug / URL</label><input class="input" name="slug" value="<?= e($row['slug']??'') ?>" placeholder="auto-generated if blank"></div><div class="field"><label>Published Date</label><input class="input" type="datetime-local" name="published_at" value="<?= !empty($row['published_at']) ? e(date('Y-m-d\TH:i', strtotime($row['published_at']))) : e(date('Y-m-d\TH:i')) ?>"></div></div>
  <div class="form-row"><div class="field"><label>Cover Image Upload</label><input class="input" type="file" name="cover_image" accept="image/*"><small>Upload JPG, PNG or WEBP. If you upload a file, it will override the URL below.</small></div><div class="field"><label>Cover Image URL</label><input class="input" type="url" name="cover_image_url" value="<?= e(!empty($row['cover_image']) && preg_match('#^https?://#i', (string)$row['cover_image']) ? $row['cover_image'] : '') ?>" placeholder="https://example.com/cover.jpg"><small>Useful for API covers. Leave blank to keep the existing uploaded cover.</small></div></div>
  <div class="form-row"><div class="field"><label>Current Cover Preview</label><div class="cover-preview-admin"><img src="<?= e(cover_url($row['cover_image']??null)) ?>" alt=""></div><small>Upload or URL both save into the same cover field, so the main website stays connected.</small></div><div class="field"><label>Published By</label><input class="input" name="published_by" value="<?= e($row['published_by']??setting('default_publisher','AnimeDubHindi Team')) ?>"></div></div>
  <div class="field"><label>Synopsis</label><textarea name="synopsis" placeholder="Write a clean synopsis. This appears above Anime Information on the details page."><?= e($row['synopsis']??'') ?></textarea></div>
  <h2>Anime Information</h2>
  <div class="form-row"><div class="field"><label>Type</label><select name="type"><option <?= (($row['type']??'Series')==='Series')?'selected':'' ?>>Series</option><option <?= (($row['type']??'')==='Movie')?'selected':'' ?>>Movie</option></select></div><div class="field"><label>Status</label><select name="status"><option <?= (($row['status']??'Ongoing')==='Ongoing')?'selected':'' ?>>Ongoing</option><option <?= (($row['status']??'')==='Completed')?'selected':'' ?>>Completed</option><option <?= (($row['status']??'')==='Upcoming')?'selected':'' ?>>Upcoming</option></select></div></div>
  <div class="form-row"><div class="field"><label>Language</label><input class="input" name="language" value="<?= e($row['language']??setting('default_language','Hindi Dubbed')) ?>"></div><div class="field"><label>Quality</label><input class="input" name="quality" value="<?= e($row['quality']??setting('default_quality','480p, 720p, 1080p')) ?>"></div></div>
  <div class="form-row"><div class="field"><label>Total Episodes</label><input class="input" name="total_episodes" value="<?= e($row['total_episodes']??'') ?>"></div><div class="field"><label>Release Year</label><input class="input" name="release_year" value="<?= e($row['release_year']??'') ?>"></div></div>
  <div class="form-row"><div class="field"><label>Rating</label><input class="input" name="rating" value="<?= e($row['rating']??'') ?>" placeholder="8.2/10"></div><div class="field"><label>Genres</label><input class="input" name="genres" value="<?= e($row['genres']??'') ?>" placeholder="Action | Fantasy | Comedy"></div></div>
  <div class="form-row"><div class="field"><label>Official By</label><input class="input" name="official_by" value="<?= e($row['official_by']??'') ?>"></div><div class="field"><label>Encoder</label><input class="input" name="encoder" value="<?= e($row['encoder']??'') ?>"></div></div>
  <div class="form-row"><label class="check"><input type="checkbox" name="is_pinned" <?= !empty($row['is_pinned'])?'checked':'' ?>> Pin this anime first in Latest Releases</label><label class="check"><input type="checkbox" name="is_featured" <?= !empty($row['is_featured'])?'checked':'' ?>> Mark as featured in sidebar</label><label class="check"><input type="checkbox" name="show_zip_section" <?= (isset($row['show_zip_section']) && (int)$row['show_zip_section']===1)?'checked':'' ?>> Show ZIP / Pack section on details page <small>Default off. Turn on only when extra ZIP/original files are needed.</small></label></div>
  <h2>SEO</h2><div class="field"><label>SEO Title</label><input class="input" name="seo_title" value="<?= e($row['seo_title']??'') ?>"></div><div class="field"><label>SEO Description</label><input class="input" name="seo_description" value="<?= e($row['seo_description']??'') ?>"></div>
  <div class="form-actions sticky-form-actions"><button class="btn" name="save_action" value="draft">Save Draft</button><button class="btn teal" name="save_action" value="published">Publish</button><button class="btn secondary" name="save_action" value="unpublished">Unpublish</button><?php if($row): ?><a class="btn secondary" target="_blank" href="<?= e('../anime.php?slug='.urlencode($row['slug']).'&preview=1') ?>">Preview</a><?php endif; ?></div>
</form>
<?php else:
  $q = trim($_GET['q'] ?? '');
  $contentFilter = trim($_GET['content_status'] ?? '');
  $typeFilter = trim($_GET['type'] ?? '');
  $statusFilter = trim($_GET['anime_status'] ?? '');
  $pinFilter = trim($_GET['pin_state'] ?? '');
  $featureFilter = trim($_GET['featured_state'] ?? '');
  $zipFilter = trim($_GET['zip_state'] ?? '');
  $yearFilter = trim($_GET['release_year'] ?? '');
  $languageFilter = trim($_GET['language'] ?? '');
  $languageOptions = admin_language_options();
  $page = max(1, (int)($_GET['page'] ?? 1));
  $perPage = max(5, min(50, (int)setting('admin_anime_page_size','10')));
  $whereParts = ['1']; $params=[];
  if($q !== ''){ $whereParts[] = '(title LIKE ? OR language LIKE ? OR type LIKE ? OR status LIKE ? OR genres LIKE ? OR published_by LIKE ? OR content_status LIKE ?)'; $like = '%'.$q.'%'; array_push($params,$like,$like,$like,$like,$like,$like,$like); }
  if(in_array($contentFilter, ['draft','published','unpublished'], true)){ $whereParts[] = "COALESCE(content_status,'published')=?"; $params[] = $contentFilter; }
  if(in_array($typeFilter, ['Series','Movie'], true)){ $whereParts[] = 'type=?'; $params[] = $typeFilter; }
  if(in_array($statusFilter, ['Ongoing','Completed','Upcoming'], true)){ $whereParts[] = 'status=?'; $params[] = $statusFilter; }
  if($pinFilter === 'pinned'){ $whereParts[] = 'is_pinned=1'; }
  if($pinFilter === 'not_pinned'){ $whereParts[] = 'is_pinned=0'; }
  if($featureFilter === 'featured'){ $whereParts[] = 'is_featured=1'; }
  if($featureFilter === 'not_featured'){ $whereParts[] = 'is_featured=0'; }
  if($zipFilter === 'zip_on'){ $whereParts[] = 'show_zip_section=1'; }
  if($zipFilter === 'zip_off'){ $whereParts[] = 'show_zip_section=0'; }
  if($yearFilter !== '' && preg_match('/^\d{4}$/', $yearFilter)){ $whereParts[] = 'release_year=?'; $params[] = $yearFilter; }
  if($languageFilter !== ''){ $whereParts[] = 'language=?'; $params[] = $languageFilter; }
  $where = 'WHERE '.implode(' AND ', $whereParts);
  $countSt = db()->prepare("SELECT COUNT(*) FROM anime $where"); $countSt->execute($params); $total=(int)$countSt->fetchColumn();
  $pages = max(1, (int)ceil($total / $perPage)); $page = min($page, $pages); $offset = ($page-1)*$perPage;
  $sql = "SELECT * FROM anime $where ORDER BY is_pinned DESC, published_at DESC, id DESC LIMIT ? OFFSET ?";
  $st = db()->prepare($sql); $i=1; foreach($params as $p){$st->bindValue($i++,$p);} $st->bindValue($i++,$perPage,PDO::PARAM_INT); $st->bindValue($i++,$offset,PDO::PARAM_INT); $st->execute(); $animeRows=$st->fetchAll();
  $keep = [];
  foreach(['q'=>$q,'content_status'=>$contentFilter,'type'=>$typeFilter,'anime_status'=>$statusFilter,'pin_state'=>$pinFilter,'featured_state'=>$featureFilter,'zip_state'=>$zipFilter,'release_year'=>$yearFilter,'language'=>$languageFilter] as $k=>$v){ if($v!=='') $keep[$k]=$v; }
  $currentListUrl = 'anime.php'.(($_SERVER['QUERY_STRING']??'') ? '?'.$_SERVER['QUERY_STRING'] : '');
?>
<div class="admin-top"><div><h1>Anime Posts</h1><p>Search, edit, pin and manage every anime post from one clean list.</p></div><a class="btn" href="anime.php?action=add&return_to=<?= e(urlencode($currentListUrl)) ?>">Add New Anime</a></div>
<div class="card anime-list-card">
  <div class="admin-content-toolbar admin-filter-toolbar">
    <form class="admin-filter-grid admin-filter-grid-wide" method="get" action="anime.php">
      <input class="input" name="q" value="<?= e($q) ?>" placeholder="Search title, genre, publisher...">
      <select name="content_status"><option value="">All visibility</option><option value="draft" <?= $contentFilter==='draft'?'selected':'' ?>>Draft</option><option value="published" <?= $contentFilter==='published'?'selected':'' ?>>Published</option><option value="unpublished" <?= $contentFilter==='unpublished'?'selected':'' ?>>Unpublished</option></select>
      <select name="type"><option value="">All types</option><option value="Series" <?= $typeFilter==='Series'?'selected':'' ?>>Series</option><option value="Movie" <?= $typeFilter==='Movie'?'selected':'' ?>>Movie</option></select>
      <select name="anime_status"><option value="">All statuses</option><option value="Ongoing" <?= $statusFilter==='Ongoing'?'selected':'' ?>>Ongoing</option><option value="Completed" <?= $statusFilter==='Completed'?'selected':'' ?>>Completed</option><option value="Upcoming" <?= $statusFilter==='Upcoming'?'selected':'' ?>>Upcoming</option></select>
      <select name="language"><option value="">All languages</option><?php foreach($languageOptions as $lo): ?><option value="<?= e($lo) ?>" <?= $languageFilter===$lo?'selected':'' ?>><?= e($lo) ?></option><?php endforeach; ?></select>
      <select name="pin_state"><option value="">Pin: All</option><option value="pinned" <?= $pinFilter==='pinned'?'selected':'' ?>>Pinned only</option><option value="not_pinned" <?= $pinFilter==='not_pinned'?'selected':'' ?>>Not pinned</option></select>
      <select name="featured_state"><option value="">Featured: All</option><option value="featured" <?= $featureFilter==='featured'?'selected':'' ?>>Featured only</option><option value="not_featured" <?= $featureFilter==='not_featured'?'selected':'' ?>>Not featured</option></select>
      <select name="zip_state"><option value="">ZIP: All</option><option value="zip_on" <?= $zipFilter==='zip_on'?'selected':'' ?>>ZIP on</option><option value="zip_off" <?= $zipFilter==='zip_off'?'selected':'' ?>>ZIP off</option></select>
      <input class="input" name="release_year" value="<?= e($yearFilter) ?>" placeholder="Year">
      <button class="btn small" type="submit">Filter</button>
      <a class="btn small secondary" href="anime.php">Reset</a>
    </form>
    <div class="admin-result-count"><b><?= $total ?></b> posts found · Page <?= $page ?> of <?= $pages ?></div>
  </div>
  <?php if(!$animeRows): ?><div class="help">No anime found. Try another keyword.</div><?php endif; ?>
  <div class="admin-anime-list admin-anime-list-pro">
    <?php foreach($animeRows as $a):
      $return = urlencode(admin_build_url([], 'anime.php'));
    ?>
      <details class="admin-anime-accordion-row">
        <summary class="admin-anime-summary">
          <span class="admin-row-arrow" aria-hidden="true">⌄</span>
          <span class="admin-anime-cover"><img src="<?= e(cover_url($a['cover_image']??null)) ?>" alt=""></span>
          <span class="admin-anime-info">
            <span class="admin-anime-title-line"><span class="admin-anime-title"><?= e($a['title']) ?></span><?php if($a['is_pinned']): ?><span class="badge pin">Pinned</span><?php endif; ?><span class="badge status-<?= e(content_status_badge_class($a['content_status'] ?? 'published')) ?>"><?= e(content_status_label($a['content_status'] ?? 'published')) ?></span></span>
            <span class="admin-inline-meta">
              <span><b>Type</b><?= e($a['type'] ?: '-') ?></span>
              <span><b>Published</b><?= e(!empty($a['published_at']) ? date('M j, Y', strtotime($a['published_at'])) : '-') ?></span>
              <span><b>Status</b><?= e($a['status'] ?: '-') ?></span>
              <span><b>Lang</b><?= e($a['language'] ?: 'Hindi Dubbed') ?></span>
            </span>
          </span>
        </summary>
        <div class="admin-anime-accordion-body">
          <div class="admin-anime-body-text">
            <b><?= e($a['title']) ?></b>
            <p><?= e(excerpt($a['synopsis'] ?? '', 130) ?: 'No synopsis added yet.') ?></p>
          </div>
          <div class="admin-anime-actions admin-actions-pro">
            <a class="btn small secondary" href="<?= e('../anime.php?slug='.$a['slug'].'&preview=1') ?>" target="_blank">Preview</a>
            <a class="btn small secondary" href="anime.php?action=edit&id=<?= (int)$a['id'] ?>&return_to=<?= e($return) ?>">Edit</a>
            <a class="btn small teal" href="episodes.php?anime_id=<?= (int)$a['id'] ?>"><?= strtolower((string)($a['type'] ?? ''))==='movie' ? 'Movie Links' : 'Episodes' ?></a>
            <a class="btn small secondary" href="<?= e(csrf_url('anime.php?pin='.(int)$a['id'].'&return_to='.rawurlencode($return))) ?>"><?= $a['is_pinned']?'Unpin':'Pin' ?></a>
            <a class="btn small teal" href="<?= e(csrf_url('anime.php?set_status=published&anime_id='.(int)$a['id'].'&return_to='.rawurlencode($return))) ?>">Publish</a>
            <a class="btn small secondary" href="<?= e(csrf_url('anime.php?set_status=unpublished&anime_id='.(int)$a['id'].'&return_to='.rawurlencode($return))) ?>">Unpublish</a>
            <a class="btn small danger" onclick="return confirm('Delete this anime?')" href="<?= e(csrf_url('anime.php?delete='.(int)$a['id'].'&return_to='.rawurlencode($return))) ?>">Delete</a>
          </div>
        </div>
      </details>
    <?php endforeach; ?>
  </div>
  <?php admin_list_pager('anime.php', $page, $pages, $keep); ?>
</div>
<?php endif; require __DIR__ . '/_footer.php'; ?>
