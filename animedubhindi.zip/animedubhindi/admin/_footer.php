</main></div>
<div class="admin-confirm-backdrop" id="adminConfirmBackdrop" hidden>
  <div class="admin-confirm-modal" role="dialog" aria-modal="true" aria-labelledby="adminConfirmTitle">
    <div class="admin-confirm-icon">!</div>
    <div class="admin-confirm-content">
      <h3 id="adminConfirmTitle">Confirm action</h3>
      <p id="adminConfirmMessage">Are you sure?</p>
    </div>
    <div class="admin-confirm-actions">
      <button type="button" class="btn secondary" id="adminConfirmCancel">Cancel</button>
      <button type="button" class="btn danger" id="adminConfirmOk">Confirm</button>
    </div>
  </div>
</div>
<script>
(function(){
  const shell = document.getElementById('adminShell');
  const collapseBtn = document.querySelector('.admin-collapse');
  if (shell && localStorage.getItem('adhAdminSideCollapsed') === '1') shell.classList.add('side-collapsed');
  if (collapseBtn && shell) {
    collapseBtn.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      shell.classList.toggle('side-collapsed');
      localStorage.setItem('adhAdminSideCollapsed', shell.classList.contains('side-collapsed') ? '1' : '0');
    });
  }

  // Keep the admin exactly where the editor was after Save/Hide/Delete/Pin actions.
  const scrollKey = 'adhAdminScrollY:' + location.pathname;
  const stampKey = 'adhAdminScrollStamp:' + location.pathname;
  const saveAdminScroll = () => {
    sessionStorage.setItem(scrollKey, String(window.scrollY || document.documentElement.scrollTop || 0));
    sessionStorage.setItem(stampKey, String(Date.now()));
  };
  window.saveAdminScroll = saveAdminScroll;
  const restoreAdminScroll = () => {
    const stamp = parseInt(sessionStorage.getItem(stampKey) || '0', 10);
    const y = parseInt(sessionStorage.getItem(scrollKey) || '0', 10);
    if (!y || !stamp || Date.now() - stamp > 10 * 60 * 1000) return;
    const doScroll = () => window.scrollTo({ top: y, left: 0, behavior: 'auto' });
    doScroll();
    requestAnimationFrame(doScroll);
    [80, 220, 520, 900].forEach(t => setTimeout(doScroll, t));
    setTimeout(() => { sessionStorage.removeItem(scrollKey); sessionStorage.removeItem(stampKey); }, 1400);
  };
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  window.addEventListener('load', restoreAdminScroll);
  window.addEventListener('pageshow', restoreAdminScroll);
  document.querySelectorAll('form').forEach(f => f.addEventListener('submit', saveAdminScroll));
  document.querySelectorAll('a[href]').forEach(a => {
    const href = a.getAttribute('href') || '';
    const isSameAdminAction = href.includes('delete=') || href.includes('toggle_') || href.includes('pin=') || href.includes('unpin=');
    if (isSameAdminAction) a.addEventListener('click', saveAdminScroll);
  });

  const animeFilter=document.querySelector('[data-admin-anime-filter]');
  if(animeFilter){
    const items=[...document.querySelectorAll('[data-anime-pick]')];
    animeFilter.addEventListener('input',()=>{
      const q=animeFilter.value.trim().toLowerCase();
      items.forEach(item=>{item.style.display=(item.dataset.title||item.textContent||'').toLowerCase().includes(q)?'':'none';});
    });
  }


  // Professional admin toast + confirmation modal for all destructive/admin notices.
  const toast = document.querySelector('[data-admin-toast]');
  if (toast) {
    const closeToast = () => toast.classList.add('is-hiding');
    const closeBtn = toast.querySelector('.admin-toast-close');
    if (closeBtn) closeBtn.addEventListener('click', closeToast);
    setTimeout(closeToast, 5200);
  }

  const confirmBackdrop = document.getElementById('adminConfirmBackdrop');
  // Safety: the modal is hidden on page load and must not block admin clicks.
  if (confirmBackdrop) {
    confirmBackdrop.hidden = true;
    confirmBackdrop.classList.remove('is-open');
    confirmBackdrop.style.pointerEvents = 'none';
  }
  const confirmMessage = document.getElementById('adminConfirmMessage');
  const confirmOk = document.getElementById('adminConfirmOk');
  const confirmCancel = document.getElementById('adminConfirmCancel');
  let confirmResolve = null;
  function openAdminConfirm(message, dangerText) {
    if (!confirmBackdrop || !confirmMessage || !confirmOk || !confirmCancel) {
      return Promise.resolve(window.confirm(message || 'Are you sure?'));
    }
    confirmMessage.textContent = message || 'Are you sure?';
    confirmOk.textContent = dangerText || 'Confirm';
    confirmBackdrop.hidden = false;
    confirmBackdrop.style.pointerEvents = 'auto';
    requestAnimationFrame(() => confirmBackdrop.classList.add('is-open'));
    confirmOk.focus();
    return new Promise(resolve => { confirmResolve = resolve; });
  }
  function closeAdminConfirm(result) {
    if (!confirmBackdrop) return;
    confirmBackdrop.classList.remove('is-open');
    confirmBackdrop.style.pointerEvents = 'none';
    setTimeout(() => { confirmBackdrop.hidden = true; }, 160);
    if (confirmResolve) confirmResolve(result);
    confirmResolve = null;
  }
  if (confirmOk) confirmOk.addEventListener('click', () => closeAdminConfirm(true));
  if (confirmCancel) confirmCancel.addEventListener('click', () => closeAdminConfirm(false));
  if (confirmBackdrop) {
    confirmBackdrop.addEventListener('click', (ev) => { if (ev.target === confirmBackdrop) closeAdminConfirm(false); });
    document.addEventListener('keydown', (ev) => { if (!confirmBackdrop.hidden && ev.key === 'Escape') closeAdminConfirm(false); });
  }
  window.adminConfirm = openAdminConfirm;

  document.addEventListener('click', (ev) => {
    const link = ev.target.closest('a[onclick*="confirm("]');
    if (!link) return;
    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();
    const match = (link.getAttribute('onclick') || '').match(/confirm\((['"])(.*?)\1\)/);
    const message = match ? match[2] : 'Confirm this action?';
    openAdminConfirm(message, 'Continue').then(ok => { if (ok) window.location.href = link.href; });
  }, true);
})();


  // Stable admin navigation: keep sidebar scroll, collapsed state, and action position.
  (function(){
    const nav = document.querySelector('.admin-nav');
    const adminMain = document.querySelector('.admin-main');
    const stableKey = 'adhAdminStable:';
    const pageKey = location.pathname + location.search;
    const navScrollKey = stableKey + 'navScrollTop';
    const pageScrollKey = stableKey + 'pageScroll:' + pageKey;
    const pageStampKey = stableKey + 'pageStamp:' + pageKey;

    function getScrollY(){
      return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
    }
    function rememberPageScroll(){
      try {
        sessionStorage.setItem(pageScrollKey, String(getScrollY()));
        sessionStorage.setItem(pageStampKey, String(Date.now()));
        if (nav) localStorage.setItem(navScrollKey, String(nav.scrollTop || 0));
      } catch(e) {}
    }
    function restorePageScroll(){
      try {
        if (nav && localStorage.getItem(navScrollKey) !== null) {
          nav.scrollTop = parseInt(localStorage.getItem(navScrollKey) || '0', 10) || 0;
        }
        const y = parseInt(sessionStorage.getItem(pageScrollKey) || '0', 10) || 0;
        const stamp = parseInt(sessionStorage.getItem(pageStampKey) || '0', 10) || 0;
        if (!y || !stamp || Date.now() - stamp > 20 * 60 * 1000) return;
        const go = () => window.scrollTo({top:y,left:0,behavior:'auto'});
        go(); requestAnimationFrame(go); [120,360,800,1300].forEach(t=>setTimeout(go,t));
      } catch(e) {}
    }
    window.addEventListener('beforeunload', rememberPageScroll);
    window.addEventListener('pagehide', rememberPageScroll);
    window.addEventListener('load', restorePageScroll);
    window.addEventListener('pageshow', restorePageScroll);
    document.addEventListener('submit', function(){ rememberPageScroll(); }, true);
    document.addEventListener('click', function(ev){
      const a = ev.target.closest && ev.target.closest('a[href]');
      if (!a) return;
      const href = a.getAttribute('href') || '';
      if (href === '#' || href.startsWith('javascript:') || a.target === '_blank') return;
      rememberPageScroll();
    }, true);
    if (nav) nav.addEventListener('scroll', function(){
      try { localStorage.setItem(navScrollKey, String(nav.scrollTop || 0)); } catch(e) {}
    }, {passive:true});
  })();
</script>

<script>
(function(){
  document.addEventListener('mousemove', function(ev){
    const a = ev.target.closest && ev.target.closest('.admin-shell.side-collapsed .admin-nav a');
    if (a) a.style.setProperty('--tooltip-y', ev.clientY + 'px');
  }, {passive:true});
})();
</script>

<script>
(function(){
  if (window.adminToolConfirm) return; window.adminToolConfirm = true;
  document.addEventListener('submit', function(e){
    var form = e.target.closest('form[data-confirm]');
    if (!form) return;
    var msg = form.getAttribute('data-confirm') || 'Are you sure?';
    if (!window.confirm(msg)) e.preventDefault();
  }, true);
})();
</script>


<script>
(function(){
  document.addEventListener('change', function(ev){
    const master = ev.target.closest && ev.target.closest('[data-select-all]');
    if (!master) return;
    const sel = master.getAttribute('data-select-all');
    document.querySelectorAll(sel).forEach(function(cb){ cb.checked = master.checked; });
  });
  document.addEventListener('submit', function(ev){
    const form = ev.target.closest && ev.target.closest('form[data-bulk-confirm]');
    if (!form) return;
    const checked = form.querySelectorAll('input[name="ids[]"]:checked').length;
    if (!checked) { ev.preventDefault(); if(window.adminConfirm){ window.adminConfirm('Select at least one anime before applying a bulk action.', 'OK'); } else alert('Select at least one anime first.'); return; }
    if (form.dataset.bulkConfirmed === '1') return;
    ev.preventDefault();
    const msg = form.getAttribute('data-bulk-confirm') || 'Apply this action?';
    if (window.adminConfirm) {
      window.adminConfirm(msg, 'Apply').then(function(ok){ if(ok){ form.dataset.bulkConfirmed='1'; form.submit(); }});
    } else if (confirm(msg)) { form.submit(); }
  }, true);
})();
</script>

</body></html>
