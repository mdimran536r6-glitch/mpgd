<?php
require __DIR__ . '/_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = (string)($_POST['security_action'] ?? '');
    if ($action === 'clear_old_logs') {
        try {
            db()->exec("DELETE FROM security_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
            db()->exec("DELETE FROM login_attempts WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
            flash('Old security logs cleaned successfully.');
        } catch (Throwable $e) { flash('Could not clean security logs.', 'error'); }
        header('Location: security.php'); exit;
    }
}

$checks = security_quick_checks();
$protected = 0;
foreach ($checks as $c) if (!empty($c[1])) $protected++;
$total = count($checks);

try { $failedLogin24 = (int)db()->query("SELECT COUNT(*) FROM login_attempts WHERE success=0 AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)")->fetchColumn(); } catch(Throwable $e) { $failedLogin24 = 0; }
try { $successLogin24 = (int)db()->query("SELECT COUNT(*) FROM login_attempts WHERE success=1 AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)")->fetchColumn(); } catch(Throwable $e) { $successLogin24 = 0; }
try { $securityLogCount = (int)db()->query("SELECT COUNT(*) FROM security_logs")->fetchColumn(); } catch(Throwable $e) { $securityLogCount = 0; }
$logType = trim((string)($_GET['event_type'] ?? ''));
$logQ = trim((string)($_GET['q'] ?? ''));
$logPage = max(1, (int)($_GET['page'] ?? 1));
$logPerPage = max(10, min(80, (int)setting('admin_security_log_page_size','20')));
$logParts=['1']; $logParams=[];
if($logType !== ''){ $logParts[]='event_type=?'; $logParams[]=$logType; }
if($logQ !== ''){ $logParts[]='(event_type LIKE ? OR detail LIKE ?)'; $like='%'.$logQ.'%'; array_push($logParams,$like,$like); }
$logWhere = 'WHERE '.implode(' AND ', $logParts);
try { $st=db()->prepare("SELECT COUNT(*) FROM security_logs $logWhere"); $st->execute($logParams); $logTotal=(int)$st->fetchColumn(); } catch(Throwable $e){ $logTotal=0; }
$logPages=max(1,(int)ceil($logTotal/$logPerPage)); $logPage=min($logPage,$logPages); $logOffset=($logPage-1)*$logPerPage;
try { $st=db()->prepare("SELECT * FROM security_logs $logWhere ORDER BY created_at DESC LIMIT ? OFFSET ?"); $i=1; foreach($logParams as $param){$st->bindValue($i++,$param);} $st->bindValue($i++,$logPerPage,PDO::PARAM_INT); $st->bindValue($i++,$logOffset,PDO::PARAM_INT); $st->execute(); $logs=$st->fetchAll(); } catch(Throwable $e) { $logs = []; }
$logKeep=[]; foreach(['event_type'=>$logType,'q'=>$logQ] as $k=>$v){ if($v!=='') $logKeep[$k]=$v; }
?>
<section class="admin-top"><div><h1>Security Center</h1><p>Check admin protection, login safety and server hardening from one place.</p></div><div class="admin-top-actions"><a class="btn secondary" href="<?= e(admin_url('password.php')) ?>">Change Password</a></div></section>

<section class="stats-grid security-stats">
  <div class="stat-card"><span>Protected checks</span><b><?= e($protected) ?>/<?= e($total) ?></b></div>
  <div class="stat-card"><span>Failed logins / 24h</span><b><?= e(number_format($failedLogin24)) ?></b></div>
  <div class="stat-card"><span>Successful logins / 24h</span><b><?= e(number_format($successLogin24)) ?></b></div>
  <div class="stat-card"><span>Security logs</span><b><?= e(number_format($securityLogCount)) ?></b></div>
</section>

<section class="card security-card">
  <div class="card-head"><h2>Hardening checklist</h2><p>Every item should show protected before going live.</p></div>
  <div class="security-check-list">
    <?php foreach($checks as $check): ?>
      <div class="security-check-row">
        <div><b><?= e($check[0]) ?></b><span><?= e($check[2]) ?></span></div>
        <?= security_status_badge((bool)$check[1]) ?>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<section class="card security-card">
  <div class="card-head"><h2>Security events</h2><p>Filter login, logout and blocked activity logs. IP addresses are stored only as hashes.</p></div>
  <form class="admin-filter-grid security-filter-grid" method="get" action="security.php">
    <input class="input" name="q" value="<?= e($logQ) ?>" placeholder="Search event details...">
    <select name="event_type"><option value="">All events</option><option value="login_success" <?= $logType==='login_success'?'selected':'' ?>>Login success</option><option value="login_failed" <?= $logType==='login_failed'?'selected':'' ?>>Login failed</option><option value="logout" <?= $logType==='logout'?'selected':'' ?>>Logout</option><option value="password_changed" <?= $logType==='password_changed'?'selected':'' ?>>Password changed</option></select>
    <button class="btn small">Filter</button>
    <a class="btn small secondary" href="security.php">Reset</a>
  </form>
  <p class="muted">Showing <?= e(number_format($logTotal)) ?> matching events · Page <?= e($logPage) ?> of <?= e($logPages) ?></p>
  <?php if(!$logs): ?><p class="muted">No security log entries found for this filter.</p><?php else: ?>
    <div class="security-log-list">
      <?php foreach($logs as $log): ?>
        <div class="security-log-item">
          <b><?= e($log['event_type']) ?></b>
          <span><?= e($log['detail'] ?: '-') ?></span>
          <time><?= e($log['created_at']) ?></time>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <?php if($logPages > 1): ?><nav class="admin-pager" aria-label="Security log pages">
    <?php if($logPage>1): $qs=array_merge($logKeep,['page'=>$logPage-1]); ?><a href="security.php?<?= e(http_build_query($qs)) ?>">Prev</a><?php endif; ?>
    <?php $start=max(1,$logPage-2); $end=min($logPages,$logPage+2); for($p=$start;$p<=$end;$p++): $qs=array_merge($logKeep,['page'=>$p]); ?><a class="<?= $p===$logPage?'active':'' ?>" href="security.php?<?= e(http_build_query($qs)) ?>"><?= $p ?></a><?php endfor; ?>
    <?php if($logPage<$logPages): $qs=array_merge($logKeep,['page'=>$logPage+1]); ?><a href="security.php?<?= e(http_build_query($qs)) ?>">Next</a><?php endif; ?>
  </nav><?php endif; ?>
  <form method="post" class="inline-form" onsubmit="return confirm('Clean security logs older than 30 days?')"><?= csrf_field() ?><input type="hidden" name="security_action" value="clear_old_logs"><button class="btn secondary">Clean Old Logs</button></form>
</section>

<section class="card security-card">
  <div class="card-head"><h2>Live safety checklist</h2><p>Do these once after uploading to hosting.</p></div>
  <ul class="security-tips">
    <li>Run install.php once, then delete or rename it on live hosting.</li>
    <li>Change the default admin password immediately.</li>
    <li>Enable HTTPS/SSL in hosting control panel.</li>
    <li>Keep database username/password private and never share config.php.</li>
    <li>Only upload trusted theme files and never upload PHP files inside uploads.</li>
  </ul>
</section>
<?php require __DIR__ . '/_footer.php'; ?>
