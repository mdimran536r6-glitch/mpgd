<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

$blocks = [
  'featured' => ['title'=>'Featured Anime', 'desc'=>'Manual anime slider selected from Featured Anime page.', 'enabled_key'=>'sidebar_featured_enabled', 'order_key'=>'sidebar_order_featured', 'default'=>10, 'manage'=>'featured.php'],
  'channels' => ['title'=>'Community Channels', 'desc'=>'WhatsApp and Telegram channel buttons.', 'enabled_key'=>'social_box_enabled', 'order_key'=>'sidebar_order_channels', 'default'=>20, 'manage'=>'settings.php'],
  'ad_control' => ['title'=>'Ad Control Sidebar', 'desc'=>'Adsterra/Monetag/native ad placement from Ad Control.', 'enabled_key'=>'ad_code_sidebar_enabled', 'order_key'=>'sidebar_order_ad_control', 'default'=>30, 'manage'=>'ad-control.php'],
  'advertisement' => ['title'=>'Advertisement Box', 'desc'=>'Legacy image/HTML advertisement box from Advanced Settings.', 'enabled_key'=>'ad_enabled', 'order_key'=>'sidebar_order_advertisement', 'default'=>40, 'manage'=>'settings.php'],
  'site_menu' => ['title'=>'Site Menu Links', 'desc'=>'Header menu links and submenu copy buttons.', 'enabled_key'=>'sidebar_menu_links_enabled', 'order_key'=>'sidebar_order_site_menu', 'default'=>50, 'manage'=>'menus.php'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['layout_action'] ?? 'save';
  if ($action === 'preset') {
    $preset = $_POST['preset'] ?? 'default';
    $orders = [
      'default' => ['featured'=>10,'channels'=>20,'ad_control'=>30,'advertisement'=>40,'site_menu'=>50],
      'ads_first' => ['ad_control'=>10,'advertisement'=>20,'featured'=>30,'channels'=>40,'site_menu'=>50],
      'featured_first' => ['featured'=>10,'channels'=>20,'site_menu'=>30,'ad_control'=>40,'advertisement'=>50],
      'menu_first' => ['site_menu'=>10,'featured'=>20,'channels'=>30,'ad_control'=>40,'advertisement'=>50],
    ];
    foreach (($orders[$preset] ?? $orders['default']) as $key => $order) {
      if (isset($blocks[$key])) save_setting($blocks[$key]['order_key'], (string)$order);
    }
    flash('Sidebar order preset applied.');
    header('Location: layout-control.php'); exit;
  }

  foreach ($blocks as $key => $block) {
    save_setting($block['enabled_key'], !empty($_POST['enabled'][$key]) ? '1' : '0');
    $order = max(1, min(99, (int)($_POST['order'][$key] ?? $block['default'])));
    save_setting($block['order_key'], (string)$order);
  }
  flash('Sidebar layout saved.');
  header('Location: layout-control.php'); exit;
}

$sortedBlocks = $blocks;
uksort($sortedBlocks, function($a, $b) use ($blocks) {
  $oa = (int)setting($blocks[$a]['order_key'], (string)$blocks[$a]['default']);
  $ob = (int)setting($blocks[$b]['order_key'], (string)$blocks[$b]['default']);
  if ($oa === $ob) return strcmp($a, $b);
  return $oa <=> $ob;
});

require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero">
  <div><h1>Layout Control</h1><p>Use the arrow buttons to move Featured Anime, Channels, Advertisement and Site Menu up or down. Click Save Order and the public sidebar will update instantly.</p></div>
  <a class="btn secondary" href="<?= e(url('index.php')) ?>" target="_blank">Preview Website</a>
</div>

<div class="card layout-control-card">
  <h2>Quick order presets</h2>
  <form method="post" class="layout-preset-row"><?= csrf_field() ?>
    <button class="btn secondary" name="preset" value="default" type="submit" onclick="this.form.layout_action.value='preset'">Default</button>
    <button class="btn secondary" name="preset" value="ads_first" type="submit" onclick="this.form.layout_action.value='preset'">Ads First</button>
    <button class="btn secondary" name="preset" value="featured_first" type="submit" onclick="this.form.layout_action.value='preset'">Featured First</button>
    <button class="btn secondary" name="preset" value="menu_first" type="submit" onclick="this.form.layout_action.value='preset'">Menu First</button>
    <input type="hidden" name="layout_action" value="preset">
  </form>
</div>

<form method="post" class="layout-control-list" id="sidebarLayoutForm"><?= csrf_field() ?>
  <div class="layout-order-toolbar card">
    <div>
      <h2>Sidebar order</h2>
      <p>Move blocks with the arrow buttons, then save. Lower items appear lower on the website sidebar.</p>
    </div>
    <button class="btn" type="submit">Save Order</button>
  </div>
  <div class="layout-sortable" id="sidebarLayoutSortable">
  <?php foreach ($sortedBlocks as $key => $block): ?>
    <?php $enabled = setting($block['enabled_key'], '1') === '1'; $order = (int)setting($block['order_key'], (string)$block['default']); ?>
    <section class="card layout-block-row" data-layout-row data-key="<?= e($key) ?>">
      <div class="layout-move-controls" aria-label="Move <?= e($block['title']) ?>">
        <button class="layout-arrow" type="button" data-layout-move="up" title="Move up" aria-label="Move <?= e($block['title']) ?> up">↑</button>
        <button class="layout-arrow" type="button" data-layout-move="down" title="Move down" aria-label="Move <?= e($block['title']) ?> down">↓</button>
      </div>
      <div class="layout-block-main">
        <span class="layout-position-badge" data-layout-position><?= e((string)$order) ?></span>
        <div>
          <h2><?= e($block['title']) ?></h2>
          <p><?= e($block['desc']) ?></p>
        </div>
      </div>
      <div class="layout-block-controls">
        <label class="check"><input type="checkbox" name="enabled[<?= e($key) ?>]" <?= $enabled ? 'checked' : '' ?>> Show</label>
        <input class="input layout-order-input" type="hidden" min="1" max="99" name="order[<?= e($key) ?>]" value="<?= e((string)$order) ?>">
        <a class="btn secondary" href="<?= e(admin_url($block['manage'])) ?>">Manage</a>
      </div>
    </section>
  <?php endforeach; ?>
  </div>
  <div class="settings-savebar"><button class="btn">Save Order</button><a class="btn secondary" href="<?= e(admin_url('control-center.php')) ?>">Control Center</a></div>
</form>

<div class="card admin-guide-note">
  <h2>How it works</h2>
  <p>Use ↑ and ↓ to place a block anywhere. After saving, the website sidebar will follow the exact same order. You can still use presets for quick arrangements.</p>
</div>

<script>
(function(){
  const list = document.getElementById('sidebarLayoutSortable');
  if (!list) return;
  const step = 10;
  function updateOrders(){
    const rows = Array.from(list.querySelectorAll('[data-layout-row]'));
    rows.forEach((row, index) => {
      const value = (index + 1) * step;
      const input = row.querySelector('.layout-order-input');
      const badge = row.querySelector('[data-layout-position]');
      if (input) input.value = String(value);
      if (badge) badge.textContent = String(index + 1);
      const up = row.querySelector('[data-layout-move="up"]');
      const down = row.querySelector('[data-layout-move="down"]');
      if (up) up.disabled = index === 0;
      if (down) down.disabled = index === rows.length - 1;
    });
  }
  list.addEventListener('click', function(ev){
    const btn = ev.target.closest('[data-layout-move]');
    if (!btn) return;
    const row = btn.closest('[data-layout-row]');
    const direction = btn.getAttribute('data-layout-move');
    if (direction === 'up' && row.previousElementSibling) {
      list.insertBefore(row, row.previousElementSibling);
    }
    if (direction === 'down' && row.nextElementSibling) {
      list.insertBefore(row.nextElementSibling, row);
    }
    updateOrders();
    row.classList.add('layout-row-active');
    setTimeout(() => row.classList.remove('layout-row-active'), 450);
  });
  updateOrders();
})();
</script>

<?php require __DIR__ . '/_footer.php'; ?>
