<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

function bulk_back_url(): string {
    $url = $_POST['return_to'] ?? ($_SERVER['REQUEST_URI'] ?? 'bulk-control.php');
    $parts = parse_url($url);
    if (!$parts || !empty($parts['scheme']) || !empty($parts['host'])) return 'bulk-control.php';
    return $url ?: 'bulk-control.php';
}

function placeholders(array $ids): string { return implode(',', array_fill(0, count($ids), '?')); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ids = array_values(array_unique(array_filter(array_map('intval', $_POST['ids'] ?? []), fn($v) => $v > 0)));
    $action = (string)($_POST['bulk_action'] ?? '');
    try {
        if (!$ids) throw new RuntimeException('Select at least one anime first.');
        $in = placeholders($ids);
        $ok = true;
        switch ($action) {
            case 'publish':
                db()->prepare("UPDATE anime SET content_status='published', updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('Selected anime posts published.');
                break;
            case 'draft':
                db()->prepare("UPDATE anime SET content_status='draft', updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('Selected anime posts moved to draft.');
                break;
            case 'unpublish':
                db()->prepare("UPDATE anime SET content_status='unpublished', updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('Selected anime posts unpublished.');
                break;
            case 'pin':
                db()->prepare("UPDATE anime SET is_pinned=1, updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('Selected anime posts pinned.');
                break;
            case 'unpin':
                db()->prepare("UPDATE anime SET is_pinned=0, updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('Selected anime posts unpinned.');
                break;
            case 'feature':
                db()->prepare("UPDATE anime SET is_featured=1, updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                try {
                    db()->exec("CREATE TABLE IF NOT EXISTS sidebar_featured_anime (id INT AUTO_INCREMENT PRIMARY KEY, anime_id INT NOT NULL UNIQUE, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_sidebar_featured_active (is_active, sort_order), INDEX idx_sidebar_featured_anime (anime_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    $next = (int)db()->query('SELECT COALESCE(MAX(sort_order),0)+1 FROM sidebar_featured_anime')->fetchColumn();
                    $ins = db()->prepare('INSERT INTO sidebar_featured_anime(anime_id, sort_order, is_active) VALUES(?,?,1) ON DUPLICATE KEY UPDATE is_active=1');
                    foreach ($ids as $id) $ins->execute([$id, $next++]);
                } catch (Throwable $e) {}
                flash('Selected anime posts added to Featured Anime.');
                break;
            case 'unfeature':
                db()->prepare("UPDATE anime SET is_featured=0, updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                try { db()->prepare("DELETE FROM sidebar_featured_anime WHERE anime_id IN ($in)")->execute($ids); } catch (Throwable $e) {}
                flash('Selected anime posts removed from Featured Anime.');
                break;
            case 'zip_show':
                db()->prepare("UPDATE anime SET show_zip_section=1, updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('ZIP / Pack section enabled for selected anime.');
                break;
            case 'zip_hide':
                db()->prepare("UPDATE anime SET show_zip_section=0, updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('ZIP / Pack section hidden for selected anime.');
                break;
            case 'mark_ongoing':
                db()->prepare("UPDATE anime SET status='Ongoing', updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('Selected anime marked as Ongoing.');
                break;
            case 'mark_completed':
                db()->prepare("UPDATE anime SET status='Completed', updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('Selected anime marked as Completed.');
                break;
            case 'mark_upcoming':
                db()->prepare("UPDATE anime SET status='Upcoming', updated_at=NOW() WHERE id IN ($in)")->execute($ids);
                flash('Selected anime marked as Upcoming.');
                break;
            case 'delete':
                // Delete connected child data first, then delete anime rows.
                try { db()->prepare("DELETE FROM episode_links WHERE episode_id IN (SELECT id FROM episodes WHERE anime_id IN ($in))")->execute($ids); } catch (Throwable $e) {}
                try { db()->prepare("DELETE FROM episodes WHERE anime_id IN ($in)")->execute($ids); } catch (Throwable $e) {}
                try { db()->prepare("DELETE FROM full_season_links WHERE anime_id IN ($in)")->execute($ids); } catch (Throwable $e) {}
                try { db()->prepare("DELETE FROM sidebar_featured_anime WHERE anime_id IN ($in)")->execute($ids); } catch (Throwable $e) {}
                try { db()->prepare("DELETE FROM api_import_map WHERE anime_id IN ($in)")->execute($ids); } catch (Throwable $e) {}
                db()->prepare("DELETE FROM anime WHERE id IN ($in)")->execute($ids);
                flash('Selected anime posts and their connected links were deleted.');
                break;
            default:
                $ok = false;
                throw new RuntimeException('Choose a valid bulk action.');
        }
    } catch (Throwable $e) {
        flash($e->getMessage(), 'error');
    }
    header('Location: ' . bulk_back_url()); exit;
}

$q = trim((string)($_GET['q'] ?? ''));
$contentStatus = trim((string)($_GET['content_status'] ?? ''));
$typeFilter = trim((string)($_GET['type'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$languageFilter = trim((string)($_GET['language'] ?? ''));
$languageOptions = admin_language_options();
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = max(10, min(80, (int)setting('admin_bulk_page_size','20')));
$where = ['1']; $params = [];
if ($q !== '') { $where[] = '(title LIKE ? OR genres LIKE ? OR language LIKE ? OR published_by LIKE ?)'; $like = '%'.$q.'%'; array_push($params, $like,$like,$like,$like); }
if (in_array($contentStatus, ['draft','published','unpublished'], true)) { $where[] = "COALESCE(content_status,'published')=?"; $params[] = $contentStatus; }
if (in_array($typeFilter, ['Series','Movie'], true)) { $where[] = 'type=?'; $params[] = $typeFilter; }
if (in_array($statusFilter, ['Ongoing','Completed','Upcoming'], true)) { $where[] = 'status=?'; $params[] = $statusFilter; }
if ($languageFilter !== '') { $where[] = 'language=?'; $params[] = $languageFilter; }
$whereSql = implode(' AND ', $where);
$count = db()->prepare("SELECT COUNT(*) FROM anime WHERE $whereSql"); $count->execute($params); $total = (int)$count->fetchColumn();
$pages = max(1, (int)ceil($total / $perPage)); $page = min($page, $pages); $offset = ($page-1) * $perPage;
$sql = "SELECT id,title,slug,cover_image,type,status,language,published_by,content_status,is_pinned,is_featured,show_zip_section,published_at,updated_at FROM anime WHERE $whereSql ORDER BY is_pinned DESC, updated_at DESC, id DESC LIMIT ? OFFSET ?";
$stmt = db()->prepare($sql); $i=1; foreach($params as $p) $stmt->bindValue($i++, $p); $stmt->bindValue($i++, $perPage, PDO::PARAM_INT); $stmt->bindValue($i++, $offset, PDO::PARAM_INT); $stmt->execute(); $rows = $stmt->fetchAll();
$returnTo = 'bulk-control.php' . (($_SERVER['QUERY_STRING'] ?? '') ? '?' . $_SERVER['QUERY_STRING'] : '');
require __DIR__ . '/_header.php';
?>
<div class="admin-top"><div><h1>Bulk Control</h1><p>Update many anime posts at once without opening every post. Public pages update automatically after saving.</p></div><a class="btn secondary" href="<?= e(admin_url('anime.php')) ?>">Anime Posts</a></div>
<section class="card settings-panel">
  <h2>Find Anime</h2>
  <form class="admin-filter-grid" method="get" action="bulk-control.php">
    <input class="input" name="q" value="<?= e($q) ?>" placeholder="Search title, genre, language, publisher...">
    <select name="content_status"><option value="">All publish states</option><option value="draft" <?= $contentStatus==='draft'?'selected':'' ?>>Draft</option><option value="published" <?= $contentStatus==='published'?'selected':'' ?>>Published</option><option value="unpublished" <?= $contentStatus==='unpublished'?'selected':'' ?>>Unpublished</option></select>
    <select name="type"><option value="">All types</option><option <?= $typeFilter==='Series'?'selected':'' ?>>Series</option><option <?= $typeFilter==='Movie'?'selected':'' ?>>Movie</option></select>
    <select name="status"><option value="">All statuses</option><option <?= $statusFilter==='Ongoing'?'selected':'' ?>>Ongoing</option><option <?= $statusFilter==='Completed'?'selected':'' ?>>Completed</option><option <?= $statusFilter==='Upcoming'?'selected':'' ?>>Upcoming</option></select>
    <select name="language"><option value="">All languages</option><?php foreach($languageOptions as $lo): ?><option value="<?= e($lo) ?>" <?= $languageFilter===$lo?'selected':'' ?>><?= e($lo) ?></option><?php endforeach; ?></select>
    <button class="btn small">Filter</button>
    <a class="btn small secondary" href="bulk-control.php">Reset</a>
  </form>
</section>
<section class="card bulk-control-card">
  <form method="post" data-bulk-confirm="Apply this bulk action to selected anime posts?"><?= csrf_field() ?><input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
    <div class="bulk-toolbar">
      <div><b><?= (int)$total ?></b> posts found · Page <?= (int)$page ?> of <?= (int)$pages ?></div>
      <div class="bulk-actions-line">
        <select name="bulk_action" required>
          <option value="">Choose action</option>
          <option value="publish">Publish selected</option>
          <option value="draft">Move selected to draft</option>
          <option value="unpublish">Unpublish selected</option>
          <option value="pin">Pin selected</option>
          <option value="unpin">Unpin selected</option>
          <option value="feature">Add to Featured Anime</option>
          <option value="unfeature">Remove from Featured Anime</option>
          <option value="zip_show">Show ZIP / Pack section</option>
          <option value="zip_hide">Hide ZIP / Pack section</option>
          <option value="mark_ongoing">Mark anime status: Ongoing</option>
          <option value="mark_completed">Mark anime status: Completed</option>
          <option value="mark_upcoming">Mark anime status: Upcoming</option>
          <option value="delete" data-danger="1">Delete selected permanently</option>
        </select>
        <button class="btn small">Apply</button>
      </div>
    </div>
    <label class="bulk-select-all"><input type="checkbox" data-select-all=".bulk-post-check"> Select all visible posts</label>
    <?php if(!$rows): ?><div class="help">No anime found for this filter.</div><?php endif; ?>
    <div class="bulk-list">
      <?php foreach($rows as $a): $cs = $a['content_status'] ?? 'published'; ?>
      <article class="bulk-row">
        <label class="bulk-check"><input class="bulk-post-check" type="checkbox" name="ids[]" value="<?= (int)$a['id'] ?>"></label>
        <img src="<?= e(cover_url($a['cover_image'] ?? null)) ?>" alt="">
        <div class="bulk-info">
          <b><?= e($a['title']) ?></b>
          <span><?= e($a['type'] ?: 'Series') ?> · <?= e($a['status'] ?: 'Ongoing') ?> · <?= e($a['language'] ?: 'Hindi Dubbed') ?></span>
          <small>Updated <?= e(!empty($a['updated_at']) ? date('M j, Y H:i', strtotime($a['updated_at'])) : '-') ?></small>
        </div>
        <div class="bulk-badges">
          <span class="badge status-<?= e(function_exists('content_status_badge_class') ? content_status_badge_class($cs) : $cs) ?>"><?= e(function_exists('content_status_label') ? content_status_label($cs) : ucfirst($cs)) ?></span>
          <?php if($a['is_pinned']): ?><span class="badge pin">Pinned</span><?php endif; ?>
          <?php if($a['is_featured']): ?><span class="badge">Featured</span><?php endif; ?>
          <?php if($a['show_zip_section']): ?><span class="badge soft">ZIP On</span><?php else: ?><span class="badge soft">ZIP Off</span><?php endif; ?>
        </div>
        <div class="bulk-row-actions"><a class="btn small secondary" href="anime.php?action=edit&id=<?= (int)$a['id'] ?>&return_to=<?= e(rawurlencode($returnTo)) ?>">Edit</a><a class="btn small teal" href="episodes.php?anime_id=<?= (int)$a['id'] ?>">Episodes</a></div>
      </article>
      <?php endforeach; ?>
    </div>
  </form>
  <?php if($pages > 1): $keep=[]; foreach(['q'=>$q,'content_status'=>$contentStatus,'type'=>$typeFilter,'status'=>$statusFilter,'language'=>$languageFilter] as $k=>$v){ if($v!=='') $keep[$k]=$v; } ?>
  <nav class="admin-pager" aria-label="Bulk pagination">
    <?php if($page>1): $qs=array_merge($keep,['page'=>$page-1]); ?><a href="bulk-control.php?<?= e(http_build_query($qs)) ?>">Prev</a><?php endif; ?>
    <?php $start=max(1,$page-2); $end=min($pages,$page+2); for($p=$start;$p<=$end;$p++): $qs=array_merge($keep,['page'=>$p]); ?><a class="<?= $p===$page?'active':'' ?>" href="bulk-control.php?<?= e(http_build_query($qs)) ?>"><?= $p ?></a><?php endfor; ?>
    <?php if($page<$pages): $qs=array_merge($keep,['page'=>$page+1]); ?><a href="bulk-control.php?<?= e(http_build_query($qs)) ?>">Next</a><?php endif; ?>
  </nav>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/_footer.php'; ?>
