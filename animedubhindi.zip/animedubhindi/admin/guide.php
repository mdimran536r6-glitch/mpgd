<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require __DIR__ . '/_header.php';
$siteUrl = setting('site_url','https://www.animedubhindi.xyz');
?>
<div class="admin-top dashboard-hero">
  <div>
    <h1>Admin Guide</h1>
    <p>Everything you can control from this panel, written step by step so the website stays easy to manage.</p>
  </div>
  <div class="admin-top-actions"><a class="btn" href="<?= e(url('index.php')) ?>" target="_blank">Open Website</a></div>
</div>

<div class="guide-grid">
  <section class="card guide-card">
    <h2>1. Dashboard</h2>
    <p>Use the dashboard as the quick overview page. It shows total anime, episodes, links and a paginated anime list.</p>
    <ul>
      <li>Search anime quickly.</li>
      <li>Open edit, episode manager or website preview from one place.</li>
      <li>Pinned anime stay first on the public homepage.</li>
    </ul>
  </section>

  <section class="card guide-card">
    <h2>2. Anime Posts</h2>
    <p>Create and control all public anime/movie pages from here.</p>
    <ul>
      <li>Add title, cover image, synopsis, type, language, genres, status, year, rating and SEO text.</li>
      <li>Pin posts to show them first in Latest Releases.</li>
      <li>Use <b>Featured Anime</b> to manually choose which posts appear in the sidebar slider. Auto selection is not used.</li>
      <li>Turn ZIP/pack section on or off per anime.</li>
      <li>Edit, view or delete posts from the same list.</li>
    </ul>
  </section>

  <section class="card guide-card">
    <h2>3. Episode Links</h2>
    <p>This is where episode pages become useful for visitors.</p>
    <ul>
      <li>Search/select an anime, then add episodes.</li>
      <li>Add a Watch Online link above quality buttons.</li>
      <li>Add multiple download hosts for 480p, 720p, 1080p or any custom quality.</li>
      <li>Hide/show episode links without deleting them.</li>
      <li>Add multiple ZIP packs like EP 01-06, EP 07-12 or Full Season.</li>
    </ul>
  </section>


  <section class="card guide-card">
    <h2>3A. Bulk Control</h2>
    <p>Use Bulk Control when you need to update many posts together without opening each anime one by one.</p>
    <ul>
      <li>Search and filter by publish state, type and anime status.</li>
      <li>Publish, draft or unpublish selected anime posts.</li>
      <li>Pin/unpin, feature/unfeature and show/hide ZIP section in bulk.</li>
      <li>Mark selected anime as Ongoing, Completed or Upcoming.</li>
      <li>Main website updates automatically after saving.</li>
    </ul>
  </section>

  <section class="card guide-card">
    <h2>4. Header Menus</h2>
    <p>Control the top website navigation and sidebar copyable menu links.</p>
    <ul>
      <li>Add main menus like Home, Movie, Series, Genres and Request Anime.</li>
      <li>Add submenu items under a main menu.</li>
      <li>Use relative URLs such as <code>movies.php</code> or <code>search.php?q=Action</code>.</li>
      <li>Deactivate menu items instead of deleting them.</li>
    </ul>
  </section>

  <section class="card guide-card">
    <h2>5. Advanced Settings</h2>
    <p>Most public website options are controlled from one page.</p>
    <ul>
      <li>Brand name, mascot/icon, live URL, SEO description and maintenance mode.</li>
      <li>Header smart hide/show, search box, Telegram strip and community popup.</li>
      <li>Homepage title, small label, card meta, pinned badge and Load More behavior.</li>
      <li>Anime details sections: breadcrumb, meta, synopsis, info, episodes, ZIP packs and related anime.</li>
      <li>Featured anime slider manual selection, WhatsApp/Telegram sidebar box, sidebar menu links and copy buttons.</li>
      <li>Advertisement on/off, refresh time, ad image, ad click URL or custom HTML.</li>
      <li>Footer columns, community buttons, footer about text and back-to-top button.</li>
      <li>Admin page-size controls for Anime Posts, Dashboard and Requests/Reports.</li>
      <li>Analytics enable/disable and retention days.</li>
    </ul>
  </section>

  <section class="card guide-card">
    <h2>6. Analytics</h2>
    <p>Analytics is intentionally clean so it does not become heavy.</p>
    <ul>
      <li>See total events, page views, anime views, watch clicks, downloads, ZIP clicks, requests and reports.</li>
      <li>Filter by Today, 7 Days, 30 Days or All Time.</li>
      <li>Download a CSV summary.</li>
      <li>Raw IP addresses are not stored.</li>
    </ul>
  </section>

  <section class="card guide-card">
    <h2>7. Requests and Reports</h2>
    <p>Visitors can send anime requests or broken link reports. Admin pages use search and pagination.</p>
    <ul>
      <li>Read full visitor messages clearly.</li>
      <li>Use search to find a title or page URL.</li>
      <li>Pagination prevents very long pages.</li>
    </ul>
  </section>

  <section class="card guide-card">
    <h2>8. Security and Publishing</h2>
    <p>Before going live, finish these steps.</p>
    <ul>
      <li>Change the default admin password.</li>
      <li>Set Live Website URL to <code><?= e($siteUrl) ?></code>.</li>
      <li>Use only images and links you have rights/permission to use.</li>
      <li>Run <code>install.php</code> after uploading a new package to repair missing database fields.</li>
      <li>Delete or restrict installer files after final live setup if your hosting/security practice requires it.</li>
    </ul>
  </section>
</div>


<div class="card guide-checklist">
  <h2>Admin Control Map</h2>
  <div class="checklist-columns">
    <div><b>Content</b><ol><li>Anime posts</li><li>Episode links</li><li>Watch Online links</li><li>ZIP packs</li><li>Manual Featured Anime selection</li><li>Pinned status</li><li>Draft/publish/unpublish workflow</li><li>Bulk Control for many posts</li></ol></div>
    <div><b>Layout</b><ol><li>Homepage labels/counts</li><li>Sidebar blocks</li><li>Header search/strip</li><li>Details page sections</li><li>Footer columns</li></ol></div>
    <div><b>Operations</b><ol><li>Requests/reports inbox</li><li>Analytics summary</li><li>Admin page sizes</li><li>Password</li><li>Maintenance mode</li></ol></div>
  </div>
</div>

<div class="card guide-checklist">
  <h2>Quick Admin Checklist</h2>
  <div class="checklist-columns">
    <div><b>For a new anime</b><ol><li>Add anime post.</li><li>Upload/add cover.</li><li>Add synopsis and information.</li><li>Add episode links.</li><li>Add ZIP packs if needed.</li><li>Pin or feature if important.</li></ol></div>
    <div><b>For website layout</b><ol><li>Update header menus.</li><li>Choose exact sidebar featured anime from Featured Anime.</li><li>Set sidebar featured count.</li><li>Turn social/ad/menu boxes on or off.</li><li>Adjust latest and related post counts.</li><li>Preview on desktop and mobile.</li></ol></div>
    <div><b>For maintenance</b><ol><li>Check requests.</li><li>Check broken reports.</li><li>Review analytics summary.</li><li>Change password regularly.</li><li>Backup database before large edits.</li></ol></div>
  </div>
</div>

  <section class="card guide-section">
    <h2>Control Center</h2>
    <p>The Control Center is the fastest place to manage website-wide options without opening every page separately.</p>
    <ul>
      <li>Enable or disable public Search, Request, Report and Contact pages.</li>
      <li>Control homepage labels, post count, Load More, card meta, author and date.</li>
      <li>Control anime details sections such as Synopsis, Anime Information, Episodes, ZIP packs and Related Anime.</li>
      <li>Control sidebar blocks, Featured Anime, community channels, Site Menu and Ad Control master switch.</li>
      <li>Set admin page sizes, session timeout, analytics on/off and analytics retention.</li>
    </ul>
  </section>

<?php require __DIR__ . '/_footer.php'; ?>
