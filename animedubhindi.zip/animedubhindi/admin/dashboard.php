<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if(!function_exists('dashboard_pager')){
function dashboard_pager(int $page, int $pages, array $keep=[]): void {
  if ($pages <= 1) return;
  echo '<nav class="admin-pager" aria-label="Anime pages">';
  if($page > 1){ $qs=array_merge($keep,['page'=>$page-1]); echo '<a href="dashboard.php?'.e(http_build_query($qs)).'">Prev</a>'; }
  $start=max(1,$page-2); $end=min($pages,$page+2);
  if($start>1){ $qs=array_merge($keep,['page'=>1]); echo '<a href="dashboard.php?'.e(http_build_query($qs)).'">1</a>'; if($start>2) echo '<span>…</span>'; }
  for($i=$start;$i<=$end;$i++){ $qs=array_merge($keep,['page'=>$i]); echo '<a class="'.($i===$page?'active':'').'" href="dashboard.php?'.e(http_build_query($qs)).'">'.$i.'</a>'; }
  if($end<$pages){ if($end<$pages-1) echo '<span>…</span>'; $qs=array_merge($keep,['page'=>$pages]); echo '<a href="dashboard.php?'.e(http_build_query($qs)).'">'.$pages.'</a>'; }
  if($page < $pages){ $qs=array_merge($keep,['page'=>$page+1]); echo '<a href="dashboard.php?'.e(http_build_query($qs)).'">Next</a>'; }
  echo '</nav>';
}}

$stats = [];
foreach(['anime','episodes','episode_links','requests','reports','full_season_links'] as $t){ try{$stats[$t]=(int)db()->query("SELECT COUNT(*) FROM $t")->fetchColumn();}catch(Throwable $e){$stats[$t]=0;} }

$q = trim($_GET['q'] ?? '');
$contentFilter = trim($_GET['content_status'] ?? '');
$typeFilter = trim($_GET['type'] ?? '');
$statusFilter = trim($_GET['anime_status'] ?? '');
$languageFilter = trim($_GET['language'] ?? '');
$languageOptions = admin_language_options();
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = max(5, min(50, (int)setting('admin_dashboard_page_size','8')));
$whereParts=['1']; $params=[];
if($q !== ''){ $whereParts[]='(title LIKE ? OR language LIKE ? OR type LIKE ? OR status LIKE ? OR genres LIKE ?)'; $like='%'.$q.'%'; array_push($params,$like,$like,$like,$like,$like); }
if(in_array($contentFilter, ['draft','published','unpublished'], true)){ $whereParts[]="COALESCE(content_status,'published')=?"; $params[]=$contentFilter; }
if(in_array($typeFilter, ['Series','Movie'], true)){ $whereParts[]='type=?'; $params[]=$typeFilter; }
if(in_array($statusFilter, ['Ongoing','Completed','Upcoming'], true)){ $whereParts[]='status=?'; $params[]=$statusFilter; }
if($languageFilter !== ''){ $whereParts[]='language=?'; $params[]=$languageFilter; }
$where='WHERE '.implode(' AND ', $whereParts);
$countSt=db()->prepare("SELECT COUNT(*) FROM anime $where"); $countSt->execute($params); $total=(int)$countSt->fetchColumn();
$pages=max(1,(int)ceil($total/$perPage)); $page=min($page,$pages); $offset=($page-1)*$perPage;
$st=db()->prepare("SELECT * FROM anime $where ORDER BY is_pinned DESC, published_at DESC, id DESC LIMIT ? OFFSET ?");
$i=1; foreach($params as $p){$st->bindValue($i++,$p);} $st->bindValue($i++,$perPage,PDO::PARAM_INT); $st->bindValue($i++,$offset,PDO::PARAM_INT); $st->execute(); $animeRows=$st->fetchAll();
$keep=[]; foreach(['q'=>$q,'content_status'=>$contentFilter,'type'=>$typeFilter,'anime_status'=>$statusFilter,'language'=>$languageFilter] as $k=>$v){ if($v!=='') $keep[$k]=$v; }
require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero"><div><h1>Dashboard</h1><p>Control anime posts, episodes, links, requests and site settings from one connected database.</p></div><a class="btn" href="anime.php?action=add">Add New Anime</a></div>
<div class="grid grid-3 dashboard-stats">
  <div class="stat"><span>Total Anime</span><b><?= $stats['anime'] ?></b><small>Published entries</small></div>
  <div class="stat"><span>Episodes</span><b><?= $stats['episodes'] ?></b><small>Episode groups</small></div>
  <div class="stat"><span>Links</span><b><?= $stats['episode_links'] ?></b><small>Download/watch links</small></div>
</div>
<div class="grid grid-3 dashboard-stats small-stats">
  <div class="stat"><span>ZIP Packs</span><b><?= $stats['full_season_links'] ?></b></div>
  <div class="stat"><span>Requests</span><b><?= $stats['requests'] ?></b></div>
  <div class="stat"><span>Reports</span><b><?= $stats['reports'] ?></b></div>
</div>
<div class="card dashboard-tools">
  <h2>Quick Actions</h2>
  <div class="quick-actions">
    <a class="quick-action" href="anime.php?action=add"><b>Add Anime</b><span>Create a new post</span></a>
    <a class="quick-action" href="episodes.php"><b>Episode Links</b><span>Add watch/download links</span></a>
    <a class="quick-action" href="settings.php"><b>Advanced Settings</b><span>Fine-tune frontend blocks</span></a>
    <a class="quick-action" href="analytics.php"><b>Analytics</b><span>Traffic and click reports</span></a>
    <a class="quick-action" href="requests.php"><b>Requests & Reports</b><span>Read visitor messages</span></a>
  </div>
</div>
<div class="card anime-list-card">
  <div class="card-title-row dashboard-list-title">
    <div><h2>All Anime</h2><small>Pinned posts stay first. Use search and pages instead of scrolling endlessly.</small></div>
  </div>
  <div class="admin-content-toolbar admin-filter-toolbar">
    <form class="admin-filter-grid admin-filter-grid-dashboard" method="get" action="dashboard.php">
      <input class="input" name="q" value="<?= e($q) ?>" placeholder="Search title, type, status or genre...">
      <select name="content_status"><option value="">All visibility</option><option value="draft" <?= $contentFilter==='draft'?'selected':'' ?>>Draft</option><option value="published" <?= $contentFilter==='published'?'selected':'' ?>>Published</option><option value="unpublished" <?= $contentFilter==='unpublished'?'selected':'' ?>>Unpublished</option></select>
      <select name="type"><option value="">All types</option><option value="Series" <?= $typeFilter==='Series'?'selected':'' ?>>Series</option><option value="Movie" <?= $typeFilter==='Movie'?'selected':'' ?>>Movie</option></select>
      <select name="anime_status"><option value="">All statuses</option><option value="Ongoing" <?= $statusFilter==='Ongoing'?'selected':'' ?>>Ongoing</option><option value="Completed" <?= $statusFilter==='Completed'?'selected':'' ?>>Completed</option><option value="Upcoming" <?= $statusFilter==='Upcoming'?'selected':'' ?>>Upcoming</option></select>
      <select name="language"><option value="">All languages</option><?php foreach($languageOptions as $lo): ?><option value="<?= e($lo) ?>" <?= $languageFilter===$lo?'selected':'' ?>><?= e($lo) ?></option><?php endforeach; ?></select>
      <button class="btn small" type="submit">Filter</button>
      <a class="btn small secondary" href="dashboard.php">Reset</a>
    </form>
    <div class="admin-result-count"><b><?= $total ?></b> posts found · Page <?= $page ?> of <?= $pages ?></div>
  </div>
  <?php if(!$animeRows): ?><div class="help">No anime found.</div><?php endif; ?>
  <div class="admin-anime-list admin-anime-list-pro dashboard-anime-list">
    <?php foreach($animeRows as $a): ?>
      <article class="admin-anime-row admin-anime-row-pro dashboard-anime-row">
        <a class="admin-anime-cover" href="<?= e('../anime.php?slug='.$a['slug']) ?>" target="_blank" title="View post"><img src="<?= e(cover_url($a['cover_image']??null)) ?>" alt=""></a>
        <div class="admin-anime-info">
          <div class="admin-anime-title-line"><a class="admin-anime-title" href="anime.php?action=edit&id=<?= (int)$a['id'] ?>"><?= e($a['title']) ?></a><?php if($a['is_pinned']): ?><span class="badge pin">Pinned</span><?php endif; ?></div>
          <p><?= e($a['language'] ?: 'Hindi Dubbed') ?> • <?= e($a['status'] ?: 'Ongoing') ?></p>
          <div class="admin-inline-meta"><span><b>Type</b><?= e($a['type'] ?: '-') ?></span><span><b>Published</b><?= e(!empty($a['published_at']) ? date('M j, Y', strtotime($a['published_at'])) : '-') ?></span><span><b>Status</b><?= e($a['status'] ?: '-') ?></span></div>
        </div>
        <div class="admin-anime-actions admin-actions-pro">
          <a class="btn small secondary" href="anime.php?action=edit&id=<?= (int)$a['id'] ?>">Edit</a>
          <a class="btn small teal" href="episodes.php?anime_id=<?= (int)$a['id'] ?>">Episodes</a>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
  <?php dashboard_pager($page,$pages,$keep); ?>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
