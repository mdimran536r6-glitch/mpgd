<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

function tools_table_exists(string $table): bool {
  try { $stmt = db()->prepare("SHOW TABLES LIKE ?"); $stmt->execute([$table]); return (bool)$stmt->fetchColumn(); }
  catch (Throwable $e) { return false; }
}

if (isset($_GET['export']) && $_GET['export'] === 'settings') {
  header('Content-Type: application/json; charset=utf-8');
  header('Content-Disposition: attachment; filename="animedubhindi-settings-' . date('Ymd-His') . '.json"');
  $rows = tools_table_exists('settings') ? db()->query('SELECT setting_key, setting_value FROM settings ORDER BY setting_key ASC')->fetchAll() : [];
  echo json_encode(['site'=>'AnimeDubHindi','exported_at'=>date('c'),'settings'=>$rows], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
  exit;
}
if (isset($_GET['export']) && $_GET['export'] === 'anime') {
  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="animedubhindi-anime-' . date('Ymd-His') . '.csv"');
  $out = fopen('php://output', 'w');
  fputcsv($out, ['id','title','slug','type','anime_status','content_status','language','published_by','published_at','is_pinned','is_featured']);
  if (tools_table_exists('anime')) {
    $rows = db()->query("SELECT id,title,slug,type,status,COALESCE(content_status,'published') AS content_status,language,published_by,published_at,is_pinned,is_featured FROM anime ORDER BY id DESC")->fetchAll();
    foreach ($rows as $r) fputcsv($out, $r);
  }
  fclose($out); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['tool_action'] ?? '';
  try {
    if ($action === 'clear_analytics') {
      if (tools_table_exists('analytics_events')) db()->exec('TRUNCATE TABLE analytics_events');
      flash('Analytics data cleared successfully.');
    } elseif ($action === 'clear_old_analytics') {
      $days = max(7, min(3650, (int)($_POST['older_than_days'] ?? 180)));
      if (tools_table_exists('analytics_events')) {
        $stmt = db()->prepare('DELETE FROM analytics_events WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)');
        $stmt->execute([$days]);
      }
      flash('Old analytics data cleaned.');
    } elseif ($action === 'clear_request_report') {
      $type = $_POST['message_type'] ?? '';
      if ($type === 'requests' && tools_table_exists('requests')) { db()->exec('TRUNCATE TABLE requests'); flash('All request messages cleared.'); }
      elseif ($type === 'reports' && tools_table_exists('reports')) { db()->exec('TRUNCATE TABLE reports'); flash('All report messages cleared.'); }
      else flash('Nothing was cleared.', 'error');
    } elseif ($action === 'toggle_public_pages') {
      $keys = ['public_search_enabled','public_request_enabled','public_report_enabled','public_contact_enabled'];
      foreach ($keys as $k) save_setting($k, !empty($_POST[$k]) ? '1' : '0');
      flash('Public page access controls saved.');
    } elseif ($action === 'save_content_defaults') {
      $textKeys = ['empty_search_message','empty_list_message','default_no_image_alt','copyright_owner','footer_copyright_text'];
      foreach ($textKeys as $k) save_setting($k, (string)($_POST[$k] ?? ''));
      flash('Content defaults saved.');
    } elseif ($action === 'repair_core_settings') {
      $defaults = [
        'site_name'=>'AnimeDubHindi','site_url'=>'https://www.animedubhindi.xyz','latest_initial_limit'=>'18','similar_posts_limit'=>'6',
        'sidebar_featured_enabled'=>'1','social_box_enabled'=>'1','sidebar_menu_links_enabled'=>'1','analytics_enabled'=>'1',
        'public_search_enabled'=>'1','public_request_enabled'=>'1','public_report_enabled'=>'1','public_contact_enabled'=>'1',
        'details_share_enabled'=>'1','details_synopsis_enabled'=>'1','details_info_enabled'=>'1','details_episodes_enabled'=>'1','details_zip_enabled'=>'1','details_related_enabled'=>'1'
      ];
      foreach ($defaults as $k=>$v) if (setting($k, '') === '') save_setting($k, $v);
      flash('Missing core settings repaired without changing existing values.');
    }
  } catch (Throwable $e) { flash('Tool action failed: ' . $e->getMessage(), 'error'); }
  header('Location: tools.php'); exit;
}

function checked_tool($key,$default='1'){ return setting($key,$default)==='1'?'checked':''; }
require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero">
  <div>
    <h1>Website Tools</h1>
    <p>Professional maintenance controls for exports, cleanup, access switches and safe repair tasks. These tools keep the admin panel and public website connected without editing files manually.</p>
  </div>
  <div class="admin-actions"><a class="btn secondary" href="<?= e(admin_url('control-center.php')) ?>">Control Center</a><a class="btn" href="<?= e(url('index.php')) ?>" target="_blank">Preview Website</a></div>
</div>

<div class="admin-grid tools-grid">
  <section class="card settings-panel">
    <h2>Export & Backup</h2>
    <p class="muted">Download lightweight backups before changing large settings.</p>
    <div class="admin-actions stacked-actions">
      <a class="btn" href="<?= e(csrf_url(admin_url('tools.php?export=settings'))) ?>">Export Settings JSON</a>
      <a class="btn secondary" href="<?= e(csrf_url(admin_url('tools.php?export=anime'))) ?>">Export Anime CSV</a>
    </div>
  </section>

  <section class="card settings-panel">
    <h2>Public Page Switches</h2>
    <p class="muted">Temporarily enable or disable public utility pages without deleting the pages.</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="tool_action" value="toggle_public_pages">
      <label class="check"><input type="checkbox" name="public_search_enabled" <?= checked_tool('public_search_enabled','1') ?>> Search page</label>
      <label class="check"><input type="checkbox" name="public_request_enabled" <?= checked_tool('public_request_enabled','1') ?>> Request Anime page</label>
      <label class="check"><input type="checkbox" name="public_report_enabled" <?= checked_tool('public_report_enabled','1') ?>> Broken Link Report page</label>
      <label class="check"><input type="checkbox" name="public_contact_enabled" <?= checked_tool('public_contact_enabled','1') ?>> Contact page</label>
      <button class="btn" type="submit">Save Page Switches</button>
    </form>
  </section>

  <section class="card settings-panel">
    <h2>Data Cleanup</h2>
    <p class="muted">Clean only operational data. Anime posts, episodes, ZIP packs and settings will not be touched.</p>
    <form method="post" data-confirm="Clear all analytics data? This cannot be undone."><?= csrf_field() ?><input type="hidden" name="tool_action" value="clear_analytics"><button class="btn danger" type="submit">Clear Analytics</button></form>
    <form method="post" class="form-inline"><?= csrf_field() ?><input type="hidden" name="tool_action" value="clear_old_analytics"><label>Delete analytics older than days</label><input class="input" type="number" name="older_than_days" value="180" min="7" max="3650"><button class="btn secondary" type="submit">Clean Old Data</button></form>
  </section>

  <section class="card settings-panel">
    <h2>Request & Report Cleanup</h2>
    <p class="muted">Use only after exporting or reviewing messages.</p>
    <form method="post" data-confirm="Clear selected messages? This cannot be undone."><?= csrf_field() ?><input type="hidden" name="tool_action" value="clear_request_report">
      <select class="input" name="message_type"><option value="requests">All requests</option><option value="reports">All broken-link reports</option></select>
      <button class="btn danger" type="submit">Clear Selected</button>
    </form>
  </section>

  <section class="card settings-panel control-panel-wide">
    <h2>Content Defaults</h2>
    <p class="muted">Small frontend texts used when lists are empty or when fallback text is needed.</p>
    <form method="post" class="settings-pro-grid compact-form"><?= csrf_field() ?><input type="hidden" name="tool_action" value="save_content_defaults">
      <div class="field"><label>No Search Result Message</label><input class="input" name="empty_search_message" value="<?= e(setting('empty_search_message','No matching anime found. Try another keyword.')) ?>"></div>
      <div class="field"><label>Empty List Message</label><input class="input" name="empty_list_message" value="<?= e(setting('empty_list_message','No posts are available in this section yet.')) ?>"></div>
      <div class="field"><label>Default Image Alt Text</label><input class="input" name="default_no_image_alt" value="<?= e(setting('default_no_image_alt','Anime cover image')) ?>"></div>
      <div class="field"><label>Copyright Owner</label><input class="input" name="copyright_owner" value="<?= e(setting('copyright_owner','AnimeDubHindi')) ?>"></div>
      <div class="field control-panel-wide"><label>Footer Copyright Text Override</label><input class="input" name="footer_copyright_text" value="<?= e(setting('footer_copyright_text','')) ?>" placeholder="Leave blank for automatic copyright line"></div>
      <div class="control-panel-wide"><button class="btn" type="submit">Save Content Defaults</button></div>
    </form>
  </section>

  <section class="card settings-panel">
    <h2>Safe Repair</h2>
    <p class="muted">Repair missing important settings without overwriting your saved values.</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="tool_action" value="repair_core_settings"><button class="btn secondary" type="submit">Repair Missing Settings</button></form>
  </section>

  <section class="card settings-panel">
    <h2>Quick Checks</h2>
    <p class="muted">Open these links after publishing or changing SEO settings.</p>
    <div class="admin-actions stacked-actions">
      <a class="btn secondary" href="<?= e(url('robots.txt')) ?>" target="_blank">Open Robots.txt</a>
      <a class="btn secondary" href="<?= e(url('sitemap.xml')) ?>" target="_blank">Open Sitemap</a>
      <a class="btn secondary" href="<?= e(admin_url('security.php')) ?>">Security Page</a>
    </div>
  </section>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
