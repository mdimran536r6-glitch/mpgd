<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

function compact_admin_number($number): string {
  $n = (float)$number; $abs = abs($n);
  if ($abs >= 1000000000) return rtrim(rtrim(number_format($n / 1000000000, 1), '0'), '.') . 'B';
  if ($abs >= 1000000) return rtrim(rtrim(number_format($n / 1000000, 1), '0'), '.') . 'M';
  if ($abs >= 1000) return rtrim(rtrim(number_format($n / 1000, 1), '0'), '.') . 'K';
  return (string)(int)$n;
}
function req_url(array $changes=[]): string {
  $qs = $_GET;
  foreach($changes as $k=>$v){ if($v===null) unset($qs[$k]); else $qs[$k]=$v; }
  return 'requests.php' . ($qs ? '?' . http_build_query($qs) : '');
}
function admin_pager(string $key, int $page, int $pages): void {
  if ($pages <= 1) return;
  echo '<div class="admin-pager request-pager">';
  if ($page > 1) echo '<a class="wide" href="'.e(req_url([$key=>$page-1])).'">‹ Prev</a>';
  $shown = [];
  foreach([1, $page-1, $page, $page+1, $pages] as $p){ if($p>=1 && $p<=$pages) $shown[$p]=true; }
  $last = 0;
  foreach(array_keys($shown) as $p){
    if($last && $p > $last + 1) echo '<span>…</span>';
    echo '<a class="'.($p===$page?'active':'').'" href="'.e(req_url([$key=>$p])).'">'.$p.'</a>';
    $last = $p;
  }
  if ($page < $pages) echo '<a class="wide" href="'.e(req_url([$key=>$page+1])).'">Next ›</a>';
  echo '</div>';
}
function count_table(string $table, string $where, array $params): int {
  try { $st = db()->prepare("SELECT COUNT(*) FROM $table $where"); $st->execute($params); return (int)$st->fetchColumn(); } catch(Throwable $e){ return 0; }
}
function fetch_messages(string $table, string $where, array $params, int $limit, int $offset): array {
  try { $st = db()->prepare("SELECT * FROM $table $where ORDER BY created_at DESC LIMIT ? OFFSET ?"); $i=1; foreach($params as $p) $st->bindValue($i++, $p); $st->bindValue($i++, $limit, PDO::PARAM_INT); $st->bindValue($i, $offset, PDO::PARAM_INT); $st->execute(); return $st->fetchAll(); } catch(Throwable $e){ return []; }
}

if(isset($_GET['clear']) && $_GET['clear']==='requests'){
  require_csrf();
  db()->exec('TRUNCATE TABLE requests');
  flash('Requests cleared.');
  header('Location: requests.php');
  exit;
}
if(isset($_GET['clear']) && $_GET['clear']==='reports'){
  require_csrf();
  db()->exec('TRUNCATE TABLE reports');
  flash('Reports cleared.');
  header('Location: requests.php');
  exit;
}

$perPage = max(5, min(50, (int)setting('admin_message_page_size','10')));
$q = trim((string)($_GET['q'] ?? ''));
$dateFrom = trim((string)($_GET['date_from'] ?? ''));
$dateTo = trim((string)($_GET['date_to'] ?? ''));
$reqPage = max(1, (int)($_GET['req_page'] ?? 1));
$repPage = max(1, (int)($_GET['rep_page'] ?? 1));
$reqParts = [];
$repParts = [];
$reqParams = [];
$repParams = [];
if($q !== ''){
  $like = '%' . $q . '%';
  $reqParts[] = '(anime_title LIKE ? OR name LIKE ? OR email LIKE ? OR message LIKE ?)';
  array_push($reqParams,$like,$like,$like,$like);
  $repParts[] = '(page_url LIKE ? OR name LIKE ? OR email LIKE ? OR message LIKE ?)';
  array_push($repParams,$like,$like,$like,$like);
}
if($dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)){ $reqParts[]='created_at >= ?'; $repParts[]='created_at >= ?'; $reqParams[]=$dateFrom.' 00:00:00'; $repParams[]=$dateFrom.' 00:00:00'; }
if($dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)){ $reqParts[]='created_at <= ?'; $repParts[]='created_at <= ?'; $reqParams[]=$dateTo.' 23:59:59'; $repParams[]=$dateTo.' 23:59:59'; }
$reqWhere = $reqParts ? 'WHERE '.implode(' AND ', $reqParts) : '';
$repWhere = $repParts ? 'WHERE '.implode(' AND ', $repParts) : '';
$reqTotalAll = count_table('requests','',[]);
$repTotalAll = count_table('reports','',[]);
$reqTotal = count_table('requests',$reqWhere,$reqParams);
$repTotal = count_table('reports',$repWhere,$repParams);
$reqPages = max(1, (int)ceil($reqTotal / $perPage));
$repPages = max(1, (int)ceil($repTotal / $perPage));
$reqPage = min($reqPage, $reqPages);
$repPage = min($repPage, $repPages);
$requests = fetch_messages('requests',$reqWhere,$reqParams,$perPage,($reqPage-1)*$perPage);
$reports = fetch_messages('reports',$repWhere,$repParams,$perPage,($repPage-1)*$perPage);

require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero request-hero">
  <div>
    <h1>Requests & Reports</h1>
    <p>Read visitor anime requests and broken-link reports in a clean paginated inbox.</p>
  </div>
  <div class="request-stats-mini"><span><b><?= e(compact_admin_number($reqTotalAll)) ?></b> Requests</span><span><b><?= e(compact_admin_number($repTotalAll)) ?></b> Reports</span></div>
</div>

<div class="card request-toolbar">
  <form method="get" class="admin-filter-grid request-filter-grid">
    <input class="input" name="q" value="<?= e($q) ?>" placeholder="Search name, email, anime title, URL or message...">
    <input class="input" type="date" name="date_from" value="<?= e($dateFrom) ?>" title="From date">
    <input class="input" type="date" name="date_to" value="<?= e($dateTo) ?>" title="To date">
    <button class="btn" type="submit">Filter</button>
    <?php if($q !== '' || $dateFrom !== '' || $dateTo !== ''): ?><a class="btn secondary" href="requests.php">Reset</a><?php endif; ?>
  </form>
  <p class="muted">Showing <?= e(compact_admin_number($reqTotal)) ?> request matches and <?= e(compact_admin_number($repTotal)) ?> report matches.</p>
</div>

<div class="grid grid-2 request-report-grid">
  <div class="card admin-message-section">
    <div class="card-title-row">
      <div><h2>Anime Requests</h2><small><?= e(compact_admin_number($reqTotal)) ?> shown · <?= e(compact_admin_number($reqTotalAll)) ?> total</small></div>
      <a class="btn small secondary" onclick="return confirm('Clear all anime requests?')" href="<?= e(csrf_url('requests.php?clear=requests')) ?>">Clear</a>
    </div>
    <?php if(!$requests): ?><div class="help">No matching request found.</div><?php endif; ?>
    <div class="admin-card-list">
      <?php foreach($requests as $r): ?>
      <article class="admin-message-card clean-message-card">
        <div class="message-head"><span class="message-type">Request #<?= (int)$r['id'] ?></span><time><?= e(date('M j, Y • h:i A', strtotime($r['created_at'] ?? 'now'))) ?></time></div>
        <h3><?= e($r['anime_title'] ?: 'Anime request') ?></h3>
        <div class="message-block"><b>Visitor Message</b><p><?= nl2br(e($r['message'] ?: 'No message provided.')) ?></p></div>
        <div class="admin-message-meta"><span><b>Name:</b> <?= e($r['name'] ?: 'Visitor') ?></span><span><b>Email:</b> <?= e($r['email'] ?: 'Not provided') ?></span></div>
      </article>
      <?php endforeach; ?>
    </div>
    <?php admin_pager('req_page', $reqPage, $reqPages); ?>
  </div>

  <div class="card admin-message-section">
    <div class="card-title-row">
      <div><h2>Broken Link Reports</h2><small><?= e(compact_admin_number($repTotal)) ?> shown · <?= e(compact_admin_number($repTotalAll)) ?> total</small></div>
      <a class="btn small secondary" onclick="return confirm('Clear all reports?')" href="<?= e(csrf_url('requests.php?clear=reports')) ?>">Clear</a>
    </div>
    <?php if(!$reports): ?><div class="help">No matching report found.</div><?php endif; ?>
    <div class="admin-card-list">
      <?php foreach($reports as $r): ?>
      <article class="admin-message-card clean-message-card">
        <div class="message-head"><span class="message-type report">Report #<?= (int)$r['id'] ?></span><time><?= e(date('M j, Y • h:i A', strtotime($r['created_at'] ?? 'now'))) ?></time></div>
        <h3>Broken link report</h3>
        <div class="message-block"><b>Visitor Message</b><p><?= nl2br(e($r['message'] ?: 'No message provided.')) ?></p></div>
        <?php if(!empty($r['page_url'])): ?><a class="admin-url" href="<?= e($r['page_url']) ?>" target="_blank" rel="noopener">Open reported page ↗</a><?php endif; ?>
        <div class="admin-message-meta"><span><b>Name:</b> <?= e($r['name'] ?: 'Visitor') ?></span><span><b>Email:</b> <?= e($r['email'] ?: 'Not provided') ?></span></div>
      </article>
      <?php endforeach; ?>
    </div>
    <?php admin_pager('rep_page', $repPage, $repPages); ?>
  </div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
