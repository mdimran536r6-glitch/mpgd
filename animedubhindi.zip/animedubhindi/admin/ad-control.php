<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
require_admin_csrf_for_post();

$placements = [
  'head' => ['Head / Verification Code', 'Meta verification, Adsterra/Monetag verification, or scripts that must load inside <head>.'],
  'body_start' => ['After Body Start', 'Scripts that your ad network asks to place immediately after <body>.'],
  'under_header' => ['Under Header', 'Banner/native code below the Telegram strip. Good for top banner ads.'],
  'before_latest' => ['Before Latest Releases', 'Homepage ad slot above Latest Releases. Good for horizontal native/banner code.'],
  'after_latest' => ['After Latest Releases', 'Homepage ad slot after the post grid and Load More area.'],
  'sidebar' => ['Sidebar / Native Box', 'Right sidebar placement near Featured, Channels, Site Menu and legacy advertisement.'],
  'before_anime_content' => ['Before Anime Details', 'Details page slot above the anime title/content.'],
  'after_cover' => ['After Cover Image', 'Details page slot under the cover image and before Synopsis.'],
  'before_episodes' => ['Before Episode Links', 'Details page slot immediately above the episode section.'],
  'after_episodes' => ['After Episode Links', 'Details page slot below all episode download/watch rows.'],
  'before_zip' => ['Before ZIP / Pack Downloads', 'Details page slot above batch/ZIP download section.'],
  'after_zip' => ['After ZIP / Pack Downloads', 'Details page slot below ZIP/download packs.'],
  'before_footer' => ['Before Footer', 'Site-wide banner slot just before footer.'],
  'popunder' => ['Popunder Script', 'Adsterra/Monetag popunder code. Loads near the end of the page.'],
  'socialbar' => ['Social Bar Script', 'Social bar / push / floating ad code. Loads near the end of the page.'],
  'chat' => ['Floating Chat / Widget', 'Floating chat, support widget, or community widget code.'],
  'body_end' => ['Body End / Custom Script', 'Any custom JavaScript that should run before </body>.'],
];

$boolKeys = ['ad_code_master_enabled'];
$textKeys = ['ad_code_sidebar_title', 'ad_control_notes'];
foreach ($placements as $key => $_) {
  $boolKeys[] = 'ad_code_' . $key . '_enabled';
  $textKeys[] = 'ad_code_' . $key;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = (string)($_POST['ad_action'] ?? 'save');

  if ($action === 'clear_all') {
    save_setting('ad_code_master_enabled', '0');
    foreach ($placements as $key => $_) {
      save_setting('ad_code_' . $key . '_enabled', '0');
      save_setting('ad_code_' . $key, '');
    }
    save_setting('ad_code_sidebar_title', 'Sponsored');
    save_setting('ad_control_notes', '');
    flash('All ad codes have been cleared and all ad placements are now off.');
    header('Location: ad-control.php#saved'); exit;
  }

  if ($action === 'clear_one') {
    $placement = preg_replace('/[^a-z0-9_]/', '', (string)($_POST['clear_placement'] ?? ''));
    if (isset($placements[$placement])) {
      save_setting('ad_code_' . $placement . '_enabled', '0');
      save_setting('ad_code_' . $placement, '');
      flash($placements[$placement][0] . ' cleared successfully.');
      header('Location: ad-control.php#ad_' . $placement); exit;
    }
    flash('Invalid ad placement selected.', 'error');
    header('Location: ad-control.php#saved'); exit;
  }

  if ($action === 'clear_notes') {
    save_setting('ad_control_notes', '');
    flash('Ad Control notes cleared.');
    header('Location: ad-control.php#notes'); exit;
  }

  foreach ($boolKeys as $key) save_setting($key, isset($_POST[$key]) ? '1' : '0');
  foreach ($textKeys as $key) save_setting($key, (string)($_POST[$key] ?? ''));
  flash('Ad Control settings saved. All public placements will follow your active switches.');
  header('Location: ad-control.php#saved'); exit;
}

function ac_checked(string $key, string $default='0'): string { return setting($key, $default) === '1' ? 'checked' : ''; }
function ac_value(string $key, string $default=''): string { return e(setting($key, $default)); }
function ad_textarea(string $key, string $placeholder=''): void { echo '<textarea class="ad-code-area" name="'.e($key).'" spellcheck="false" placeholder="'.e($placeholder).'">'.e(setting($key, '')).'</textarea>'; }

require __DIR__ . '/_header.php';
?>
<div class="admin-top dashboard-hero">
  <div>
    <h1>Ad Control</h1>
    <p>Control where Adsterra, Monetag, popunder, social bar, banner, native and chat scripts appear on the public website.</p>
  </div>
  <div class="admin-top-actions"><a class="btn secondary" href="<?= e(url('index.php')) ?>" target="_blank">Preview Website</a></div>
</div>

<form method="post" class="settings-form ad-control-form" id="adControlForm"><?= csrf_field() ?>
  <input type="hidden" name="ad_action" id="adAction" value="save">
  <input type="hidden" name="clear_placement" id="adClearPlacement" value="">
  <section class="card ad-master-card" id="saved">
    <div class="ad-control-headline">
      <div><h2>Master Switch</h2><p>Disable all ad scripts instantly without deleting your saved code.</p></div>
      <label class="switch-line"><input type="checkbox" name="ad_code_master_enabled" <?= ac_checked('ad_code_master_enabled','1') ?>><span>Enable all ad placements</span></label>
    </div>
    <div class="ad-safe-note"><b>Professional tip:</b> Enable one placement at a time, test homepage, anime details, mobile menu and watch page, then enable the next script. Too many ad scripts can slow the website.</div>
  </section>

  <section class="card ad-danger-card">
    <div class="ad-clear-head">
      <div>
        <h2>Clear / Delete Ad Codes</h2>
        <p>Remove saved ad code content safely. You can clear one placement at a time or clear every ad placement at once.</p>
      </div>
      <button type="submit" class="btn danger clear-ad-all-btn" onclick="return adControlConfirmAll();">Clear All Ad Codes</button>
    </div>
    <div class="ad-safe-note muted-note"><b>Note:</b> Clearing all will empty every ad code box, turn every placement off, reset the sidebar ad title, and clear private notes. Website content, anime posts and episodes will not be deleted.</div>
  </section>

  <section class="card ad-placement-map">
    <h2>Where ads will show on the website</h2>
    <div class="placement-map-grid">
      <div><b>Top area</b><span>Head, body start, under header, before latest releases.</span></div>
      <div><b>Homepage</b><span>Before Latest Releases and After Latest Releases.</span></div>
      <div><b>Sidebar</b><span>Native/sidebar ad box beside Featured, Channels and Site Menu.</span></div>
      <div><b>Anime details</b><span>Before details, after cover, before episodes, after episodes, before/after ZIP packs.</span></div>
      <div><b>Bottom scripts</b><span>Popunder, social bar, chat widget and custom body-end scripts.</span></div>
      <div><b>Footer area</b><span>Before footer banner/ad slot appears above the footer.</span></div>
    </div>
  </section>

  <section class="card ad-placement-card sidebar-title-card">
    <div class="field"><label>Sidebar/native ad box title</label><input class="input" name="ad_code_sidebar_title" value="<?= ac_value('ad_code_sidebar_title','Sponsored') ?>" placeholder="Sponsored"></div>
  </section>

  <div class="ad-placement-list">
    <?php foreach ($placements as $key => [$title, $desc]): ?>
      <section class="card ad-placement-card" id="ad_<?= e($key) ?>">
        <div class="ad-placement-title">
          <div>
            <h2><?= e($title) ?></h2>
            <p><?= e($desc) ?></p>
          </div>
          <div class="ad-placement-actions">
            <label class="switch-line"><input type="checkbox" name="ad_code_<?= e($key) ?>_enabled" <?= ac_checked('ad_code_'.$key.'_enabled') ?>><span>On</span></label>
            <button type="submit" class="btn mini danger-outline clear-ad-btn" name="clear_placement" value="<?= e($key) ?>" onclick="return adControlConfirmOne('<?= e($title) ?>','<?= e($key) ?>');">Clear</button>
          </div>
        </div>
        <?php ad_textarea('ad_code_'.$key, $key === 'sidebar' ? '<script src="native/sidebar ad code"></script>' : '<script>ad code here</script>'); ?>
      </section>
    <?php endforeach; ?>
  </div>

  <section class="card ad-placement-card">
    <h2>Recommended setup</h2>
    <div class="admin-guide-grid compact-guide">
      <div><b>1. Verification first</b><span>Paste head/verification code first and save.</span></div>
      <div><b>2. Start with sidebar</b><span>Native/sidebar ads are safer for layout than aggressive popunders.</span></div>
      <div><b>3. Add popunder/social later</b><span>Only enable after testing speed and mobile experience.</span></div>
      <div><b>4. Keep backup clean</b><span>If any network script breaks layout, switch that placement off.</span></div>
    </div>
    <div class="field" id="notes"><label>Private notes</label><textarea name="ad_control_notes" placeholder="Zone IDs, test dates, account notes... "><?= e(setting('ad_control_notes','')) ?></textarea></div>
    <button type="submit" class="btn secondary mini clear-note-btn" onclick="return adControlClearNotes();">Clear Notes</button>
  </section>

  <div class="settings-savebar"><button class="btn" onclick="document.getElementById('adAction').value='save'">Save Ad Control</button><a class="btn secondary" href="<?= e(url('index.php')) ?>" target="_blank">Preview Website</a></div>
</form>
<script>
function adControlSubmitAfterConfirm(action, message, confirmText, placement){
  var form = document.getElementById('adControlForm');
  var actionField = document.getElementById('adAction');
  var placementField = document.getElementById('adClearPlacement');
  if(!form || !actionField) return false;
  var run = function(ok){
    if(!ok) return;
    actionField.value = action;
    if(placementField) placementField.value = placement || '';
    if(window.saveAdminScroll) window.saveAdminScroll();
    form.submit();
  };
  if(window.adminConfirm){ window.adminConfirm(message, confirmText || 'Clear').then(run); }
  else { run(confirm(message)); }
  return false;
}
function adControlConfirmAll(){
  return adControlSubmitAfterConfirm('clear_all', 'Clear all ad codes? This will empty every placement, turn all ads off, reset the sidebar ad title, and clear private notes. Anime posts, episodes and website content will not be deleted.', 'Clear all');
}
function adControlConfirmOne(name, placement){
  return adControlSubmitAfterConfirm('clear_one', 'Clear this ad placement: ' + name + '? The saved code will be removed and this placement will be turned off.', 'Clear', placement);
}
function adControlClearNotes(){
  return adControlSubmitAfterConfirm('clear_notes', 'Clear private Ad Control notes?', 'Clear notes');
}
</script>
<?php require __DIR__ . '/_footer.php'; ?>
