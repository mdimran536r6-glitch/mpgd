<?php
require_once __DIR__ . '/../includes/functions.php'; require_admin();
require_admin_csrf_for_post();
if (isset($_GET['delete'])) { require_csrf(); db()->prepare('DELETE FROM menus WHERE id=? OR parent_id=?')->execute([(int)$_GET['delete'],(int)$_GET['delete']]); flash('Menu deleted.'); header('Location: menus.php'); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $id=(int)($_POST['id']??0); $menuUrl=trim((string)($_POST['url']??'')); if($menuUrl!=='' && preg_match('#^(javascript|data):#i',$menuUrl)) $menuUrl=''; $data=[clean_text((string)($_POST['label']??''),100),clean_text((string)($_POST['slug']??''),120),$menuUrl,(int)($_POST['parent_id']??0),(int)($_POST['sort_order']??0),!empty($_POST['is_active'])?1:0];
    if($id){$data[]=$id;db()->prepare('UPDATE menus SET label=?,slug=?,url=?,parent_id=?,sort_order=?,is_active=? WHERE id=?')->execute($data);flash('Menu updated.');}
    else{db()->prepare('INSERT INTO menus(label,slug,url,parent_id,sort_order,is_active) VALUES(?,?,?,?,?,?)')->execute($data);flash('Menu added.');}
    header('Location: menus.php'); exit;
}
$menus=db()->query('SELECT * FROM menus ORDER BY parent_id ASC, sort_order ASC, id ASC')->fetchAll();
$edit=null;if(isset($_GET['edit'])){$s=db()->prepare('SELECT * FROM menus WHERE id=?');$s->execute([(int)$_GET['edit']]);$edit=$s->fetch();}
require __DIR__ . '/_header.php';
?>
<div class="admin-top"><div><h1>Header Menus</h1><p>Add, remove and reorder header sections. If a menu has child items, the arrow shows automatically.</p></div></div>
<div class="grid grid-2"><form class="card" method="post"><?= csrf_field() ?><h2><?= $edit?'Edit Menu':'Add Menu' ?></h2><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>"><div class="field"><label>Label</label><input class="input" name="label" value="<?= e($edit['label']??'') ?>" required></div><div class="field"><label>URL</label><input class="input" name="url" value="<?= e($edit['url']??'') ?>" placeholder="index.php or https://..."></div><div class="field"><label>Slug</label><input class="input" name="slug" value="<?= e($edit['slug']??'') ?>"></div><div class="form-row"><div class="field"><label>Parent</label><select name="parent_id"><option value="0">No parent</option><?php foreach($menus as $m): if((int)$m['parent_id']===0): ?><option value="<?= (int)$m['id'] ?>" <?= (int)($edit['parent_id']??0)===(int)$m['id']?'selected':'' ?>><?= e($m['label']) ?></option><?php endif; endforeach; ?></select></div><div class="field"><label>Sort</label><input class="input" type="number" name="sort_order" value="<?= e($edit['sort_order']??0) ?>"></div></div><label><input type="checkbox" name="is_active" <?= !isset($edit['is_active']) || $edit['is_active']?'checked':'' ?>> Active</label><br><br><button class="btn">Save Menu</button></form>
<div class="card table-wrap"><h2>Menus</h2><table class="table"><tr><th>Label</th><th>Parent</th><th>URL</th><th>Active</th><th>Action</th></tr><?php foreach($menus as $m): ?><tr><td><b><?= e($m['label']) ?></b></td><td><?= $m['parent_id']?(int)$m['parent_id']:'-' ?></td><td><?= e($m['url']) ?></td><td><?= $m['is_active']?'Yes':'No' ?></td><td class="actions"><a class="btn small secondary" href="menus.php?edit=<?= (int)$m['id'] ?>">Edit</a><a class="btn small danger" onclick="return confirm('Delete menu?')" href="<?= e(csrf_url('menus.php?delete='.(int)$m['id'])) ?>">Delete</a></td></tr><?php endforeach; ?></table></div></div>
<?php require __DIR__ . '/_footer.php'; ?>
