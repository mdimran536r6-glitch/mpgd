<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header('X-Frame-Options: DENY');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
}
$timeoutSeconds = max(900, (int)setting('admin_session_timeout_minutes','60') * 60);
if (!empty($_SESSION['admin_last_seen']) && time() - (int)$_SESSION['admin_last_seen'] > $timeoutSeconds) { session_destroy(); header('Location: index.php'); exit; }
$_SESSION['admin_last_seen'] = time();
$flash = get_flash();
$current = basename($_SERVER['SCRIPT_NAME']);
$siteName = setting('site_name','AnimeDubHindi');
$brandIcon = setting('brand_icon_url','') ?: asset('img/anime-logo-icon.svg');
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin - <?= e($siteName) ?></title><meta name="robots" content="noindex,nofollow"><link rel="stylesheet" href="<?= e(asset('css/admin.css')) ?>?v=api-importer-final"></head><body>
<div class="admin-shell" id="adminShell">
  <aside class="admin-side" id="adminSide">
    <button class="admin-collapse" type="button" aria-label="Toggle admin sidebar" title="Toggle menu"><span></span><span></span><span></span></button>
    <div class="admin-logo admin-logo-pro">
      <div class="admin-mark"><img src="<?= e($brandIcon) ?>" alt=""></div>
      <div class="admin-logo-text"><b><?= e($siteName) ?></b><span>Control Panel</span></div>
    </div>
    <nav class="admin-nav">
      <a data-label="Dashboard" title="Dashboard" class="<?= $current==='dashboard.php'?'active':'' ?>" href="<?= e(admin_url('dashboard.php')) ?>"><span>Dashboard</span></a>
      <a data-label="Control Center" title="Control Center" class="<?= $current==='control-center.php'?'active':'' ?>" href="<?= e(admin_url('control-center.php')) ?>"><span>Control Center</span></a>
      <a data-label="Layout Control" title="Layout Control" class="<?= $current==='layout-control.php'?'active':'' ?>" href="<?= e(admin_url('layout-control.php')) ?>"><span>Layout Control</span></a>
      <a data-label="Anime Posts" title="Anime Posts" class="<?= $current==='anime.php'?'active':'' ?>" href="<?= e(admin_url('anime.php')) ?>"><span>Anime Posts</span></a>
      <a data-label="API Importer" title="API Importer" class="<?= $current==='api-importer.php'?'active':'' ?>" href="<?= e(admin_url('api-importer.php')) ?>"><span>API Importer</span></a>
      <a data-label="Bulk Control" title="Bulk Control" class="<?= $current==='bulk-control.php'?'active':'' ?>" href="<?= e(admin_url('bulk-control.php')) ?>"><span>Bulk Control</span></a>
      <a data-label="Episode Links" title="Episode Links" class="<?= $current==='episodes.php'?'active':'' ?>" href="<?= e(admin_url('episodes.php')) ?>"><span>Episode Links</span></a>
      <a data-label="Featured Anime" title="Featured Anime" class="<?= $current==='featured.php'?'active':'' ?>" href="<?= e(admin_url('featured.php')) ?>"><span>Featured Anime</span></a>
      <a data-label="Header Menus" title="Header Menus" class="<?= $current==='menus.php'?'active':'' ?>" href="<?= e(admin_url('menus.php')) ?>"><span>Header Menus</span></a>
      <a data-label="Advanced Settings" title="Advanced Settings" class="<?= $current==='settings.php'?'active':'' ?>" href="<?= e(admin_url('settings.php')) ?>"><span>Advanced Settings</span></a>
      <a data-label="SEO Control" title="SEO Control" class="<?= $current==='seo-control.php'?'active':'' ?>" href="<?= e(admin_url('seo-control.php')) ?>"><span>SEO Control</span></a>
      <a data-label="Ad Control" title="Ad Control" class="<?= $current==='ad-control.php'?'active':'' ?>" href="<?= e(admin_url('ad-control.php')) ?>"><span>Ad Control</span></a>
      <a data-label="Analytics" title="Analytics" class="<?= $current==='analytics.php'?'active':'' ?>" href="<?= e(admin_url('analytics.php')) ?>"><span>Analytics</span></a>
      <a data-label="Website Tools" title="Website Tools" class="<?= $current==='tools.php'?'active':'' ?>" href="<?= e(admin_url('tools.php')) ?>"><span>Website Tools</span></a>
      <a data-label="Security" title="Security" class="<?= $current==='security.php'?'active':'' ?>" href="<?= e(admin_url('security.php')) ?>"><span>Security</span></a>
      <a data-label="Admin Guide" title="Admin Guide" class="<?= $current==='guide.php'?'active':'' ?>" href="<?= e(admin_url('guide.php')) ?>"><span>Admin Guide</span></a>
      <a data-label="Requests" title="Requests" class="<?= $current==='requests.php'?'active':'' ?>" href="<?= e(admin_url('requests.php')) ?>"><span>Requests</span></a>
      <a data-label="Password" title="Password" class="<?= $current==='password.php'?'active':'' ?>" href="<?= e(admin_url('password.php')) ?>"><span>Password</span></a>
      <a data-label="View Website" title="View Website" href="<?= e(url('index.php')) ?>" target="_blank"><span>View Website</span></a>
      <a data-label="Logout" title="Logout" href="<?= e(csrf_url(admin_url('logout.php'))) ?>"><span>Logout</span></a>
    </nav>
  </aside>
  <main class="admin-main">
    <?php if($flash): ?>
      <div class="admin-toast-stack" aria-live="polite" aria-atomic="true">
        <div class="admin-toast <?= e($flash['type']) ?>" data-admin-toast>
          <span class="admin-toast-icon"><?= ($flash['type'] ?? '') === 'error' ? '!' : '✓' ?></span>
          <div class="admin-toast-body">
            <b><?= ($flash['type'] ?? '') === 'error' ? 'Action failed' : 'Done' ?></b>
            <p><?= e($flash['message']) ?></p>
          </div>
          <button class="admin-toast-close" type="button" aria-label="Close notification">×</button>
        </div>
      </div>
    <?php endif; ?>
