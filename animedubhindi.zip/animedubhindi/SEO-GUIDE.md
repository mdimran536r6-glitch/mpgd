# AnimeDubHindi SEO Guide

Use Admin → SEO Control to manage sitemap.xml, robots.txt, search-engine verification and AI crawler access.

## Important URLs

- Sitemap: https://www.animedubhindi.xyz/sitemap.xml
- Robots: https://www.animedubhindi.xyz/robots.txt

## Submit To

- Google Search Console
- Bing Webmaster Tools
- Yandex Webmaster
- Naver Search Advisor

## Recommended Workflow

1. Publish anime with unique title, synopsis and SEO description.
2. Check sitemap.xml after publishing.
3. Submit sitemap in search webmaster tools.
4. Use URL Inspection for important new anime posts.
5. Keep public pages indexable and admin/private folders blocked.
