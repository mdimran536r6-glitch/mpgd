<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
$message = null; $ok = false;
define('INSTALL_LOCK_FILE', __DIR__ . '/storage/install.lock');
$isLocalInstall = in_array($_SERVER['SERVER_NAME'] ?? '', ['localhost','127.0.0.1'], true) || str_starts_with($_SERVER['HTTP_HOST'] ?? '', 'localhost');
if (file_exists(INSTALL_LOCK_FILE) && !$isLocalInstall) {
  http_response_code(403);
  exit('Installer is locked for security. Delete storage/install.lock manually if you intentionally need to run it again.');
}
function qid(string $name): string { return '`' . str_replace('`', '``', $name) . '`'; }
function table_exists(PDO $pdo, string $table): bool { $s=$pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=? AND TABLE_NAME=?'); $s->execute([DB_NAME,$table]); return (int)$s->fetchColumn()>0; }
function column_exists(PDO $pdo, string $table, string $column): bool { $s=$pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME=? AND COLUMN_NAME=?'); $s->execute([DB_NAME,$table,$column]); return (int)$s->fetchColumn()>0; }
function add_column_if_missing(PDO $pdo, string $table, string $column, string $definition): void { if(table_exists($pdo,$table) && !column_exists($pdo,$table,$column)) $pdo->exec('ALTER TABLE '.qid($table).' ADD COLUMN '.qid($column).' '.$definition); }
function put_setting(PDO $pdo, string $key, string $value): void { $s=$pdo->prepare('INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)'); $s->execute([$key,$value]); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once __DIR__ . '/includes/functions.php';
  require_csrf();
  try {
    $server = db_server();
    $server->exec('CREATE DATABASE IF NOT EXISTS '.qid(DB_NAME).' CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo = db();
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (id INT AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(120) NOT NULL UNIQUE, setting_value MEDIUMTEXT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS anime (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255) NOT NULL, slug VARCHAR(255) NOT NULL UNIQUE, cover_image VARCHAR(255) NULL, type VARCHAR(50) DEFAULT 'Series', status VARCHAR(60) DEFAULT 'Ongoing', language VARCHAR(120) DEFAULT 'Hindi Dubbed', quality VARCHAR(120) DEFAULT '480p, 720p, 1080p', total_episodes VARCHAR(50) DEFAULT NULL, release_year VARCHAR(20) DEFAULT NULL, rating VARCHAR(50) DEFAULT NULL, genres VARCHAR(255) DEFAULT NULL, synopsis TEXT NULL, official_by VARCHAR(160) DEFAULT NULL, encoder VARCHAR(160) DEFAULT NULL, published_by VARCHAR(120) DEFAULT 'AnimeDubHindi Team', content_status VARCHAR(30) DEFAULT 'published', show_zip_section TINYINT(1) DEFAULT 1, is_pinned TINYINT(1) DEFAULT 0, is_featured TINYINT(1) DEFAULT 0, views INT DEFAULT 0, seo_title VARCHAR(255) DEFAULT NULL, seo_description VARCHAR(255) DEFAULT NULL, published_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS episodes (id INT AUTO_INCREMENT PRIMARY KEY, anime_id INT NOT NULL, title VARCHAR(255) DEFAULT NULL, episode_number INT DEFAULT 1, upload_date DATE DEFAULT NULL, notes TEXT NULL, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_episodes_anime (anime_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS sidebar_featured_anime (id INT AUTO_INCREMENT PRIMARY KEY, anime_id INT NOT NULL UNIQUE, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_sidebar_featured_active (is_active, sort_order), INDEX idx_sidebar_featured_anime (anime_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS episode_links (id INT AUTO_INCREMENT PRIMARY KEY, episode_id INT NOT NULL, quality VARCHAR(60) DEFAULT NULL, host_name VARCHAR(120) DEFAULT NULL, url TEXT NULL, link_type VARCHAR(30) DEFAULT 'download', sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_links_episode (episode_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS full_season_links (id INT AUTO_INCREMENT PRIMARY KEY, anime_id INT NOT NULL, pack_title VARCHAR(180) DEFAULT NULL, episode_range VARCHAR(120) DEFAULT NULL, quality VARCHAR(60) DEFAULT NULL, host_name VARCHAR(120) DEFAULT NULL, file_size VARCHAR(60) DEFAULT NULL, url TEXT NULL, link_type VARCHAR(30) DEFAULT 'download', sort_order INT DEFAULT 0, notes TEXT NULL, is_active TINYINT(1) DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_full_anime (anime_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS menus (id INT AUTO_INCREMENT PRIMARY KEY, label VARCHAR(100) NOT NULL, slug VARCHAR(120) DEFAULT NULL, url VARCHAR(255) DEFAULT NULL, parent_id INT DEFAULT 0, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS requests (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) DEFAULT NULL, email VARCHAR(160) DEFAULT NULL, anime_title VARCHAR(255) DEFAULT NULL, message TEXT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS reports (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) DEFAULT NULL, email VARCHAR(160) DEFAULT NULL, page_url VARCHAR(255) DEFAULT NULL, message TEXT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS analytics_events (id BIGINT AUTO_INCREMENT PRIMARY KEY, event_type VARCHAR(40) NOT NULL, anime_id INT NULL, episode_id INT NULL, link_id INT NULL, zip_id INT NULL, page_url VARCHAR(500) NULL, referrer VARCHAR(500) NULL, title VARCHAR(255) NULL, device_type VARCHAR(30) DEFAULT 'desktop', ip_hash CHAR(64) NULL, user_agent VARCHAR(500) NULL, extra_data JSON NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_analytics_type_date (event_type, created_at), INDEX idx_analytics_anime_date (anime_id, created_at), INDEX idx_analytics_date (created_at), INDEX idx_analytics_device (device_type)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS api_import_map (id BIGINT AUTO_INCREMENT PRIMARY KEY, source_name VARCHAR(80) NOT NULL, source_id VARCHAR(190) NOT NULL, anime_id INT NOT NULL, source_url VARCHAR(500) NULL, import_status VARCHAR(40) DEFAULT 'imported', last_seen_at DATETIME DEFAULT CURRENT_TIMESTAMP, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_api_source (source_name, source_id), INDEX idx_api_anime (anime_id), INDEX idx_api_source_status (source_name, import_status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS api_import_state (id INT AUTO_INCREMENT PRIMARY KEY, source_name VARCHAR(80) NOT NULL UNIQUE, next_page INT DEFAULT 1, per_page INT DEFAULT 10, last_run_at DATETIME NULL, notes TEXT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    foreach(['title'=>"VARCHAR(255) NOT NULL DEFAULT ''",'slug'=>"VARCHAR(255) NOT NULL DEFAULT ''",'cover_image'=>'VARCHAR(255) NULL','type'=>"VARCHAR(50) DEFAULT 'Series'",'status'=>"VARCHAR(60) DEFAULT 'Ongoing'",'language'=>"VARCHAR(120) DEFAULT 'Hindi Dubbed'",'quality'=>'VARCHAR(120) DEFAULT NULL','total_episodes'=>'VARCHAR(50) DEFAULT NULL','release_year'=>'VARCHAR(20) DEFAULT NULL','rating'=>'VARCHAR(50) DEFAULT NULL','genres'=>'VARCHAR(255) DEFAULT NULL','synopsis'=>'TEXT NULL','official_by'=>'VARCHAR(160) DEFAULT NULL','encoder'=>'VARCHAR(160) DEFAULT NULL','published_by'=>"VARCHAR(120) DEFAULT 'AnimeDubHindi Team'",'content_status'=>"VARCHAR(30) DEFAULT 'published'",'show_zip_section'=>'TINYINT(1) DEFAULT 1','is_pinned'=>'TINYINT(1) DEFAULT 0','is_featured'=>'TINYINT(1) DEFAULT 0','views'=>'INT DEFAULT 0','seo_title'=>'VARCHAR(255) DEFAULT NULL','seo_description'=>'VARCHAR(255) DEFAULT NULL','published_at'=>'DATETIME DEFAULT CURRENT_TIMESTAMP','updated_at'=>'DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'] as $c=>$d) add_column_if_missing($pdo,'anime',$c,$d);
    foreach(['anime_id'=>'INT NOT NULL','title'=>'VARCHAR(255) DEFAULT NULL','episode_number'=>'INT DEFAULT 1','upload_date'=>'DATE DEFAULT NULL','notes'=>'TEXT NULL','sort_order'=>'INT DEFAULT 0','is_active'=>'TINYINT(1) DEFAULT 1','created_at'=>'DATETIME DEFAULT CURRENT_TIMESTAMP'] as $c=>$d) add_column_if_missing($pdo,'episodes',$c,$d);
    foreach(['episode_id'=>'INT NOT NULL','quality'=>'VARCHAR(60) DEFAULT NULL','host_name'=>'VARCHAR(120) DEFAULT NULL','url'=>'TEXT NULL','link_type'=>"VARCHAR(30) DEFAULT 'download'",'sort_order'=>'INT DEFAULT 0','is_active'=>'TINYINT(1) DEFAULT 1','created_at'=>'DATETIME DEFAULT CURRENT_TIMESTAMP'] as $c=>$d) add_column_if_missing($pdo,'episode_links',$c,$d);
    foreach(['anime_id'=>'INT NOT NULL','pack_title'=>'VARCHAR(180) DEFAULT NULL','episode_range'=>'VARCHAR(120) DEFAULT NULL','quality'=>'VARCHAR(60) DEFAULT NULL','host_name'=>'VARCHAR(120) DEFAULT NULL','file_size'=>'VARCHAR(60) DEFAULT NULL','url'=>'TEXT NULL','link_type'=>"VARCHAR(30) DEFAULT 'download'",'sort_order'=>'INT DEFAULT 0','notes'=>'TEXT NULL','is_active'=>'TINYINT(1) DEFAULT 1','created_at'=>'DATETIME DEFAULT CURRENT_TIMESTAMP'] as $c=>$d) add_column_if_missing($pdo,'full_season_links',$c,$d);
    try { $pdo->exec("UPDATE anime SET content_status='published' WHERE content_status IS NULL OR content_status=''"); } catch (Throwable $e) {}

    $controlDefaults = [
      'maintenance_enabled'=>'0','maintenance_message'=>'We are updating the website. Please check back soon.',
      'smart_header_enabled'=>'1','header_search_enabled'=>'1','header_telegram_strip_enabled'=>'1',
      'homepage_kicker'=>'Fresh Updates','homepage_title'=>'Latest Releases','load_more_enabled'=>'1','load_more_label'=>'Load More',
      'show_pinned_badge'=>'1','card_meta_enabled'=>'1','card_author_enabled'=>'1','card_date_enabled'=>'1',
      'details_breadcrumb_enabled'=>'1','details_meta_enabled'=>'1','details_share_enabled'=>'1','details_synopsis_enabled'=>'1','details_info_enabled'=>'1','details_episodes_enabled'=>'1','details_zip_enabled'=>'1','details_related_enabled'=>'1',
      'footer_about_enabled'=>'1','footer_quick_links_enabled'=>'1','footer_support_enabled'=>'1','footer_legal_enabled'=>'1','footer_community_enabled'=>'1','back_to_top_enabled'=>'1',
      'admin_anime_page_size'=>'10','admin_dashboard_page_size'=>'8','admin_message_page_size'=>'10','admin_bulk_page_size'=>'20','analytics_retention_days'=>'180'
    ];
    foreach($controlDefaults as $k=>$v) put_setting($pdo,$k,$v);

    foreach(['show_empty_ad_box'=>'0','social_box_enabled'=>'1','whatsapp_link'=>'https://whatsapp.com/channel/0029VbCnnx96GcGDAZxFLZ2j','telegram_sidebar_link'=>'https://t.me/animedubhindixyz','site_name'=>'AnimeDubHindi','site_tagline'=>'','brand_icon_url'=>'','similar_posts_limit'=>'6','upcoming_title'=>'Upcoming','upcoming_message'=>'Episode links will be updated soon. Please check back later.','sidebar_menu_links_enabled'=>'1','sidebar_menu_children_enabled'=>'1','sidebar_menu_copy_enabled'=>'1','sidebar_featured_enabled'=>'1','sidebar_featured_title'=>'Top Picks','sidebar_featured_label'=>'Featured','sidebar_featured_limit'=>'5','analytics_enabled'=>'1'] as $k=>$v) put_setting($pdo,$k,$v);

    $defaults = [
      'site_name'=>'AnimeDubHindi','site_tagline'=>'','site_description'=>'Anime release updates, episode details and external download pack information.',
      'telegram_text'=>'For more updates join our Telegram channel','telegram_link'=>'https://t.me/animedubhindixyz','telegram_popup_enabled'=>'1','telegram_popup_text'=>'Join our official channels for latest anime updates and release notices.',
      'social_box_enabled'=>'1','whatsapp_link'=>'https://whatsapp.com/channel/0029VbCnnx96GcGDAZxFLZ2j','telegram_sidebar_link'=>'https://t.me/animedubhindixyz',
      'sidebar_menu_links_enabled'=>'1','sidebar_menu_children_enabled'=>'1','sidebar_menu_copy_enabled'=>'1','sidebar_featured_enabled'=>'1','sidebar_featured_title'=>'Top Picks','sidebar_featured_label'=>'Featured','sidebar_featured_limit'=>'5',
      'ad_enabled'=>'0','show_empty_ad_box'=>'0','ad_refresh_enabled'=>'0','ad_refresh_seconds'=>'60','ad_title'=>'Advertisement','ad_image'=>'','ad_url'=>'#','ad_html'=>'',
      'footer_about'=>'AnimeDubHindi is a clean anime update platform for release details, episode lists and community notices.',
      'footer_credit'=>'','analytics_enabled'=>'1','latest_initial_limit'=>'18','similar_posts_limit'=>'6','upcoming_title'=>'Upcoming','upcoming_message'=>'Episode links will be updated soon. Please check back later.',
      'ad_code_master_enabled'=>'1','ad_code_head_enabled'=>'0','ad_code_head'=>'','ad_code_body_start_enabled'=>'0','ad_code_body_start'=>'','ad_code_under_header_enabled'=>'0','ad_code_under_header'=>'','ad_code_before_latest_enabled'=>'0','ad_code_before_latest'=>'','ad_code_after_latest_enabled'=>'0','ad_code_after_latest'=>'','ad_code_before_anime_content_enabled'=>'0','ad_code_before_anime_content'=>'','ad_code_after_cover_enabled'=>'0','ad_code_after_cover'=>'','ad_code_before_episodes_enabled'=>'0','ad_code_before_episodes'=>'','ad_code_after_episodes_enabled'=>'0','ad_code_after_episodes'=>'','ad_code_before_zip_enabled'=>'0','ad_code_before_zip'=>'','ad_code_after_zip_enabled'=>'0','ad_code_after_zip'=>'','ad_code_before_footer_enabled'=>'0','ad_code_before_footer'=>'','ad_code_sidebar_enabled'=>'0','ad_code_sidebar_title'=>'Sponsored','ad_code_sidebar'=>'','ad_code_popunder_enabled'=>'0','ad_code_popunder'=>'','ad_code_socialbar_enabled'=>'0','ad_code_socialbar'=>'','ad_code_chat_enabled'=>'0','ad_code_chat'=>'','ad_code_body_end_enabled'=>'0','ad_code_body_end'=>'','ad_control_notes'=>''
    ];
    foreach($defaults as $k=>$v){
      $exists=$pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key=?'); $exists->execute([$k]);
      if((int)$exists->fetchColumn()===0) put_setting($pdo,$k,$v);
    }
    put_setting($pdo, 'site_url', 'https://www.animedubhindi.xyz');
    put_setting($pdo, 'sidebar_menu_links_enabled', '1');
    put_setting($pdo, 'sidebar_menu_children_enabled', '1');
    put_setting($pdo, 'sidebar_menu_copy_enabled', '1');

    foreach ([
      'seo_google_analytics_id'=>'',
      'seo_google_tag_manager_id'=>'',
      'seo_microsoft_clarity_id'=>'',
      'seo_facebook_pixel_id'=>'',
      'seo_custom_head_codes'=>'',
      'seo_custom_body_start_codes'=>'',
      'seo_custom_body_end_codes'=>'',
      'seo_control_enabled'=>'1',
      'seo_robots_enabled'=>'1',
      'seo_allow_ai_bots'=>'1',
      'seo_sitemap_enabled'=>'1',
      'seo_sitemap_anime_enabled'=>'1',
      'seo_sitemap_static_enabled'=>'1',
      'seo_sitemap_legal_enabled'=>'1',
      'seo_schema_enabled'=>'1',
      'seo_og_enabled'=>'1',
      'seo_twitter_enabled'=>'1',
      'seo_default_robots_meta'=>'index,follow,max-image-preview:large',
    ] as $k=>$v) { $exists=$pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key=?'); $exists->execute([$k]); if((int)$exists->fetchColumn()===0) put_setting($pdo,$k,$v); }
    foreach (['sidebar_order_featured'=>'10','sidebar_order_channels'=>'20','sidebar_order_ad_control'=>'30','sidebar_order_advertisement'=>'40','sidebar_order_site_menu'=>'50'] as $k=>$v) { $exists=$pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key=?'); $exists->execute([$k]); if((int)$exists->fetchColumn()===0) put_setting($pdo,$k,$v); }
    foreach ([
      'public_search_enabled'=>'1','public_request_enabled'=>'1','public_report_enabled'=>'1','public_contact_enabled'=>'1',
      'default_publisher'=>'AnimeDubHindi Team','default_language'=>'Hindi Dubbed','default_quality'=>'480p, 720p, 1080p',
      'request_page_message'=>'Anime requests are temporarily closed. Please check again later.',
      'report_page_message'=>'Broken link reports are temporarily closed. Please check again later.',
      'contact_page_message'=>'Contact messages are temporarily unavailable. Please use our community channels for urgent updates.',
      'admin_session_timeout_minutes'=>'60',
      'default_content_status'=>'draft',
      'anime_preview_enabled'=>'1'
    ] as $k=>$v) { $exists=$pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key=?'); $exists->execute([$k]); if((int)$exists->fetchColumn()===0) put_setting($pdo,$k,$v); }

    foreach (['ad_code_before_latest_enabled'=>'0','ad_code_after_latest_enabled'=>'0','ad_code_before_anime_content_enabled'=>'0','ad_code_after_cover_enabled'=>'0','ad_code_before_episodes_enabled'=>'0','ad_code_after_episodes_enabled'=>'0','ad_code_before_zip_enabled'=>'0','ad_code_after_zip_enabled'=>'0','ad_code_before_footer_enabled'=>'0'] as $k=>$v) { $exists=$pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key=?'); $exists->execute([$k]); if((int)$exists->fetchColumn()===0) put_setting($pdo,$k,$v); }
    foreach (['ad_code_before_latest'=>'','ad_code_after_latest'=>'','ad_code_before_anime_content'=>'','ad_code_after_cover'=>'','ad_code_before_episodes'=>'','ad_code_after_episodes'=>'','ad_code_before_zip'=>'','ad_code_after_zip'=>'','ad_code_before_footer'=>''] as $k=>$v) { $exists=$pdo->prepare('SELECT COUNT(*) FROM settings WHERE setting_key=?'); $exists->execute([$k]); if((int)$exists->fetchColumn()===0) put_setting($pdo,$k,$v); }

    // Keep the public footer brand text clean and consistent after repair/install.
    put_setting($pdo, 'footer_about', 'AnimeDubHindi is a clean anime update platform for release details, episode lists and community notices.');

    $hash = password_hash('Admin@12345', PASSWORD_DEFAULT);
    $pdo->prepare('INSERT IGNORE INTO admin_users(username,password_hash) VALUES(?,?)')->execute(['admin',$hash]);

    if ((int)$pdo->query('SELECT COUNT(*) FROM menus')->fetchColumn() === 0) {
      $m=$pdo->prepare('INSERT INTO menus(label,url,parent_id,sort_order,is_active) VALUES(?,?,?,?,1)');
      $m->execute(['Home','index.php',0,1]);
      $m->execute(['Language','#',0,2]); $lang=(int)$pdo->lastInsertId();
      $m->execute(['Hindi Dubbed','search.php?q=Hindi', $lang,1]); $m->execute(['English Dubbed','search.php?q=English', $lang,2]); $m->execute(['Japanese','search.php?q=Japanese', $lang,3]);
      $m->execute(['Movie','movies.php',0,3]); $m->execute(['Series','series.php',0,4]);
      $m->execute(['Genres','#',0,5]); $genre=(int)$pdo->lastInsertId();
      foreach(['Action','Fantasy','Romance','Comedy','Adventure'] as $i=>$g) $m->execute([$g,'search.php?q='.urlencode($g),$genre,$i+1]);
      $m->execute(['Request Anime','request.php',0,6]);
    }

    if ((int)$pdo->query('SELECT COUNT(*) FROM anime')->fetchColumn() === 0) {
      $a=$pdo->prepare('INSERT INTO anime(title,slug,cover_image,type,status,language,quality,total_episodes,release_year,rating,genres,synopsis,official_by,encoder,published_by,is_pinned,is_featured,seo_title,seo_description,published_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
      $a->execute(['Sample Hero Academy Season 1','sample-hero-academy-season-1','', 'Series','Ongoing','Hindi Dubbed','480p, 720p, 1080p','12','2026','8.1/10','Action | Fantasy | Super Power','A young trainee enters a city academy where gifted fighters learn to control unusual abilities. As new challenges appear, the team must protect their classmates while uncovering the secret behind a strange tournament.','Official Partner','animedubhindi','AnimeDubHindi Team',1,1,'Sample Hero Academy Season 1 Hindi Dubbed Episodes','Sample Hero Academy Season 1 episode links and anime information.','2026-06-08 10:00:00']);
      $aid=(int)$pdo->lastInsertId();
      $ep=$pdo->prepare('INSERT INTO episodes(anime_id,title,episode_number,upload_date,notes,sort_order) VALUES(?,?,?,?,?,?)');
      $ln=$pdo->prepare('INSERT INTO episode_links(episode_id,quality,host_name,url,link_type,sort_order) VALUES(?,?,?,?,?,?)');
      for($i=1;$i<=4;$i++){ $ep->execute([$aid,'Episode '.str_pad((string)$i,2,'0',STR_PAD_LEFT),$i,date('Y-m-d'),'',$i]); $eid=(int)$pdo->lastInsertId(); $ln->execute([$eid,'','Sample Player','https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4','watch',0]); foreach(['480p','720p','1080p'] as $idx=>$q){ $ln->execute([$eid,$q,'Download Server','#','download',$idx+1]); }}
      $zip=$pdo->prepare('INSERT INTO full_season_links(anime_id,pack_title,episode_range,quality,host_name,file_size,url,sort_order,notes) VALUES(?,?,?,?,?,?,?,?,?)');
      $zip->execute([$aid,'Episodes 01-04 ZIP','EP 01-04','720p','Host One','1.2GB','#',1,'']);
      $zip->execute([$aid,'Episodes 05-08 ZIP','EP 05-08','720p','Host Two','1.3GB','#',2,'Add more parts like this']);
      $a->execute(['Moonlight Vanguard Movie','moonlight-vanguard-movie','', 'Movie','Completed','Hindi Dubbed','720p, 1080p','1','2026','7.8/10','Adventure | Drama','A quiet warrior returns to a coastal town after years away. When a mysterious light appears above the sea, old friends must reunite to protect the only home they have left.','Official Partner','animedubhindi','AnimeDubHindi Team',0,0,'Moonlight Vanguard Movie Hindi Dubbed','Moonlight Vanguard Movie anime information and external links.','2026-06-07 12:00:00']);
    }

    // Extra realistic demo content for testing homepage grid, details pages, sidebar featured slider, episode links and ZIP packs.
    $demoAnimes = [
      ['Crimson Dawn Academy','crimson-dawn-academy','assets/img/sample-covers/crimson-dawn-academy.svg','Series','Ongoing','Hindi Dubbed','480p, 720p, 1080p','12','2026','8.4/10','Action | School | Super Power','A group of students train under a strict academy system where every match reveals a hidden part of the city’s power structure.','Official Partner','animedubhindi','AnimeDubHindi Team',1,1,'Crimson Dawn Academy Hindi Dubbed Episodes','Crimson Dawn Academy anime details, episode links and ZIP pack information.','2026-06-09 11:00:00',6,[['Episodes 01-06 ZIP','EP 01-06','720p','Drive Pack','1.8GB'],['Episodes 07-12 ZIP','EP 07-12','720p','Mirror Pack','1.9GB']]],
      ['Silent Blade Ronin','silent-blade-ronin','assets/img/sample-covers/silent-blade-ronin.svg','Series','Ongoing','Hindi Dubbed','480p, 720p, 1080p','10','2026','8.0/10','Action | Adventure | Samurai','A quiet swordsman travels across provinces looking for a lost symbol that can end a long-running conflict.','Official Partner','animedubhindi','AnimeDubHindi Team',0,1,'Silent Blade Ronin Hindi Dubbed Episodes','Silent Blade Ronin anime details, episode links and ZIP pack information.','2026-06-08 19:30:00',4,[['Episodes 01-04 ZIP','EP 01-04','720p','Batch Server','1.1GB']]],
      ['Neon Spirit City','neon-spirit-city','assets/img/sample-covers/neon-spirit-city.svg','Series','Ongoing','Hindi Dubbed','480p, 720p','24','2026','7.9/10','Supernatural | Mystery | Urban','In a neon city where spirits pass through train stations, two friends investigate strange disappearances after midnight.','Official Partner','animedubhindi','AnimeDubHindi Team',0,1,'Neon Spirit City Hindi Dubbed Episodes','Neon Spirit City anime details, episode links and ZIP pack information.','2026-06-08 09:20:00',3,[]],
      ['Skyline Guardians','skyline-guardians','assets/img/sample-covers/skyline-guardians.svg','Series','Completed','Hindi Dubbed','480p, 720p, 1080p','12','2025','8.2/10','Action | Sci-Fi | Team','A small defense team protects floating districts after a wave of mechanical storms begins attacking the skyline.','Official Partner','animedubhindi','AnimeDubHindi Team',0,1,'Skyline Guardians Hindi Dubbed Episodes','Skyline Guardians anime details, episode links and ZIP pack information.','2026-06-07 18:05:00',5,[['Full Season ZIP','EP 01-12','1080p','Premium Host','4.6GB']]],
      ['Moonlit Kitchen Club','moonlit-kitchen-club','assets/img/sample-covers/moonlit-kitchen-club.svg','Series','Ongoing','Hindi Dubbed','480p, 720p','8','2026','7.6/10','Comedy | Slice of Life | School','A school cooking club turns into the most competitive place on campus when a mysterious chef joins the class.','Official Partner','animedubhindi','AnimeDubHindi Team',0,0,'Moonlit Kitchen Club Hindi Dubbed Episodes','Moonlit Kitchen Club anime details, episode links and ZIP pack information.','2026-06-07 13:15:00',2,[]],
      ['Dragon Gate Journey','dragon-gate-journey','assets/img/sample-covers/dragon-gate-journey.svg','Series','Ongoing','Hindi Dubbed','480p, 720p, 1080p','20','2026','8.5/10','Fantasy | Adventure | Magic','A village courier crosses forbidden gates to deliver a message that can stop an old dragon pact from breaking.','Official Partner','animedubhindi','AnimeDubHindi Team',1,1,'Dragon Gate Journey Hindi Dubbed Episodes','Dragon Gate Journey anime details, episode links and ZIP pack information.','2026-06-06 21:10:00',6,[['Episodes 01-05 ZIP','EP 01-05','720p','Server A','1.5GB'],['Episodes 06-10 ZIP','EP 06-10','720p','Server B','1.6GB']]],
      ['Winter Sakura Notes','winter-sakura-notes','assets/img/sample-covers/winter-sakura-notes.svg','Series','Completed','Hindi Dubbed','480p, 720p','12','2025','7.7/10','Romance | Drama | School','A transfer student finds old letters under a winter sakura tree and slowly learns the story behind them.','Official Partner','animedubhindi','AnimeDubHindi Team',0,0,'Winter Sakura Notes Hindi Dubbed Episodes','Winter Sakura Notes anime details, episode links and ZIP pack information.','2026-06-06 08:40:00',4,[['Full Season ZIP','EP 01-12','720p','Archive Host','2.8GB']]],
      ['Phantom Rail Express','phantom-rail-express','assets/img/sample-covers/phantom-rail-express.svg','Movie','Completed','Hindi Dubbed','720p, 1080p','1','2026','8.1/10','Mystery | Supernatural | Adventure','Passengers on a night train wake up in different versions of the same city and must solve the route before sunrise.','Official Partner','animedubhindi','AnimeDubHindi Team',0,1,'Phantom Rail Express Hindi Dubbed Episodes','Phantom Rail Express anime details, episode links and ZIP pack information.','2026-06-05 22:00:00',1,[]],
      ['Aqua Mecha Patrol','aqua-mecha-patrol','assets/img/sample-covers/aqua-mecha-patrol.svg','Series','Ongoing','Hindi Dubbed','480p, 720p, 1080p','16','2026','7.8/10','Mecha | Sci-Fi | Action','Young pilots use aquatic machines to defend island settlements after the ocean begins reacting to unknown signals.','Official Partner','animedubhindi','AnimeDubHindi Team',0,0,'Aqua Mecha Patrol Hindi Dubbed Episodes','Aqua Mecha Patrol anime details, episode links and ZIP pack information.','2026-06-05 15:25:00',3,[]],
      ['Starfall Detective Agency','starfall-detective-agency','assets/img/sample-covers/starfall-detective-agency.svg','Series','Ongoing','Hindi Dubbed','480p, 720p','12','2026','8.0/10','Detective | Mystery | Fantasy','A detective agency handles cases connected to falling stars, missing memories and impossible crime scenes.','Official Partner','animedubhindi','AnimeDubHindi Team',0,1,'Starfall Detective Agency Hindi Dubbed Episodes','Starfall Detective Agency anime details, episode links and ZIP pack information.','2026-06-04 20:45:00',5,[['Episodes 01-05 ZIP','EP 01-05','720p','Batch Host','1.4GB']]],
      ['Forest Code Alchemist','forest-code-alchemist','assets/img/sample-covers/forest-code-alchemist.svg','Series','Completed','Hindi Dubbed','480p, 720p, 1080p','12','2025','7.9/10','Fantasy | Magic | Adventure','An apprentice alchemist decodes forest markings that point to a hidden library beneath an ancient tree.','Official Partner','animedubhindi','AnimeDubHindi Team',0,0,'Forest Code Alchemist Hindi Dubbed Episodes','Forest Code Alchemist anime details, episode links and ZIP pack information.','2026-06-04 07:30:00',4,[['Full Season ZIP','EP 01-12','1080p','Drive Pack','3.7GB']]],
      ['Orbit Idol Project','orbit-idol-project','assets/img/sample-covers/orbit-idol-project.svg','Series','Ongoing','Hindi Dubbed','480p, 720p','10','2026','7.5/10','Music | Comedy | Drama','A small idol group prepares for a space-station concert while dealing with rival teams and technical chaos.','Official Partner','animedubhindi','AnimeDubHindi Team',0,0,'Orbit Idol Project Hindi Dubbed Episodes','Orbit Idol Project anime details, episode links and ZIP pack information.','2026-06-03 16:00:00',2,[]],
      ['Demon Library Keeper','demon-library-keeper','assets/img/sample-covers/demon-library-keeper.svg','Series','Ongoing','Hindi Dubbed','480p, 720p, 1080p','12','2026','8.3/10','Dark Fantasy | Mystery | Magic','A reserved librarian guards cursed books that rewrite reality when opened by the wrong person.','Official Partner','animedubhindi','AnimeDubHindi Team',0,1,'Demon Library Keeper Hindi Dubbed Episodes','Demon Library Keeper anime details, episode links and ZIP pack information.','2026-06-02 18:10:00',6,[['Episodes 01-03 ZIP','EP 01-03','720p','Server One','900MB'],['Episodes 04-06 ZIP','EP 04-06','720p','Server Two','950MB']]],
      ['Summer Fox Messenger','summer-fox-messenger','assets/img/sample-covers/summer-fox-messenger.svg','Series','Completed','Hindi Dubbed','480p, 720p','6','2025','7.4/10','Fantasy | Slice of Life | Comedy','A fox messenger spends one summer delivering letters that change the lives of a quiet mountain town.','Official Partner','animedubhindi','AnimeDubHindi Team',0,0,'Summer Fox Messenger Hindi Dubbed Episodes','Summer Fox Messenger anime details, episode links and ZIP pack information.','2026-06-01 12:00:00',3,[]],
      ['Iron Lotus Tournament','iron-lotus-tournament','assets/img/sample-covers/iron-lotus-tournament.svg','Series','Ongoing','Hindi Dubbed','480p, 720p, 1080p','18','2026','8.6/10','Martial Arts | Action | Tournament','Fighters from different regions enter a tournament where every victory unlocks a secret about the Iron Lotus arena.','Official Partner','animedubhindi','AnimeDubHindi Team',1,1,'Iron Lotus Tournament Hindi Dubbed Episodes','Iron Lotus Tournament anime details, episode links and ZIP pack information.','2026-05-31 21:40:00',6,[['Episodes 01-06 ZIP','EP 01-06','1080p','Main Host','2.1GB'],['Episodes 07-12 ZIP','EP 07-12','1080p','Mirror Host','2.2GB']]],
      ['Tiny Witch Delivery','tiny-witch-delivery','assets/img/sample-covers/tiny-witch-delivery.svg','Series','Ongoing','Hindi Dubbed','480p, 720p','12','2026','7.6/10','Comedy | Fantasy | Adventure','A tiny witch runs a delivery service for magical items and accidentally becomes involved in a kingdom-wide problem.','Official Partner','animedubhindi','AnimeDubHindi Team',0,0,'Tiny Witch Delivery Hindi Dubbed Episodes','Tiny Witch Delivery anime details, episode links and ZIP pack information.','2026-05-30 10:50:00',2,[]],
    ];
    $animeInsert = $pdo->prepare('INSERT INTO anime(title,slug,cover_image,type,status,language,quality,total_episodes,release_year,rating,genres,synopsis,official_by,encoder,published_by,is_pinned,is_featured,seo_title,seo_description,published_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $animeFind = $pdo->prepare('SELECT id FROM anime WHERE slug=? LIMIT 1');
    $epInsert = $pdo->prepare('INSERT INTO episodes(anime_id,title,episode_number,upload_date,notes,sort_order,is_active) VALUES(?,?,?,?,?,?,1)');
    $linkInsert = $pdo->prepare('INSERT INTO episode_links(episode_id,quality,host_name,url,link_type,sort_order,is_active) VALUES(?,?,?,?,?,?,1)');
    $zipInsert = $pdo->prepare('INSERT INTO full_season_links(anime_id,pack_title,episode_range,quality,host_name,file_size,url,sort_order,notes,is_active) VALUES(?,?,?,?,?,?,?,?,?,1)');
    foreach ($demoAnimes as $demo) {
      [$title,$slug,$cover,$type,$status,$language,$quality,$total,$year,$rating,$genres,$synopsis,$official,$encoder,$publishedBy,$pinned,$featured,$seoTitle,$seoDesc,$publishedAt,$episodeCount,$zipPacks] = $demo;
      $animeFind->execute([$slug]);
      $demoAid = (int)$animeFind->fetchColumn();
      if ($demoAid === 0) {
        $animeInsert->execute([$title,$slug,$cover,$type,$status,$language,$quality,$total,$year,$rating,$genres,$synopsis,$official,$encoder,$publishedBy,$pinned,$featured,$seoTitle,$seoDesc,$publishedAt]);
        $demoAid = (int)$pdo->lastInsertId();
      } else {
        $pdo->prepare("UPDATE anime SET cover_image=IF(cover_image IS NULL OR cover_image='', ?, cover_image), is_featured=GREATEST(is_featured, ?), is_pinned=GREATEST(is_pinned, ?) WHERE id=?")->execute([$cover,$featured,$pinned,$demoAid]);
      }
      $existingEpCountStmt = $pdo->prepare('SELECT COUNT(*) FROM episodes WHERE anime_id=?');
      $existingEpCountStmt->execute([$demoAid]);
      if ((int)$existingEpCountStmt->fetchColumn() === 0) {
        $count = max(1, min(8, (int)$episodeCount));
        for ($i=1; $i <= $count; $i++) {
          $date = date('Y-m-d', strtotime($publishedAt . ' +'.($i-1).' days')); 
          $epInsert->execute([$demoAid,'Episode '.str_pad((string)$i,2,'0',STR_PAD_LEFT),$i,$date,'',$i]);
          $eid = (int)$pdo->lastInsertId();
          if ($i <= 3) { $linkInsert->execute([$eid,'','Online Player','https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4','watch',0]); }
          foreach (['480p','720p','1080p'] as $idx=>$q) { $linkInsert->execute([$eid,$q,'Server '.($idx+1),'#','download',$idx+1]); }
        }
      }
      $existingZipCountStmt = $pdo->prepare('SELECT COUNT(*) FROM full_season_links WHERE anime_id=?');
      $existingZipCountStmt->execute([$demoAid]);
      if ((int)$existingZipCountStmt->fetchColumn() === 0) {
        $zi=1; foreach ($zipPacks as $pack) { [$pt,$range,$zq,$host,$size] = $pack; $zipInsert->execute([$demoAid,$pt,$range,$zq,$host,$size,'#',$zi,'']); $zi++; }
      }
    }



    // Safe draft-only watch/download sample for testing the existing player.
    // Source: Internet Archive public-domain item. This post is NOT public by default.
    try {
      $sampleSlug = 'defenders-of-space-public-domain-test';
      $sampleFind = $pdo->prepare('SELECT id FROM anime WHERE slug=? LIMIT 1');
      $sampleFind->execute([$sampleSlug]);
      $sampleId = (int)$sampleFind->fetchColumn();
      $sampleAnimeData = [
        'Defenders of Space — Player Test',
        $sampleSlug,
        'https://archive.org/download/DefendersOfSpace/__ia_thumb.jpg',
        'Movie',
        'Completed',
        'English',
        'Archive Embed, MP4',
        '1',
        '1960',
        '',
        'Anime | Animation | Sci-Fi',
        'A public-domain sci-fi animated film from Internet Archive, added as a draft-only sample to test the existing watch and download buttons without changing the website design.',
        'Internet Archive',
        'animedubhindi',
        'AnimeDubHindi Team',
        'draft',
        0,
        0,
        0,
        'Defenders of Space Player Test',
        'Draft-only sample anime for testing watch online and download links.',
        '2026-06-10 10:00:00'
      ];
      if ($sampleId === 0) {
        $sampleInsert = $pdo->prepare('INSERT INTO anime(title,slug,cover_image,type,status,language,quality,total_episodes,release_year,rating,genres,synopsis,official_by,encoder,published_by,content_status,is_pinned,is_featured,show_zip_section,seo_title,seo_description,published_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $sampleInsert->execute($sampleAnimeData);
        $sampleId = (int)$pdo->lastInsertId();
      } else {
        $sampleUpdate = $pdo->prepare('UPDATE anime SET title=?, cover_image=?, type=?, status=?, language=?, quality=?, total_episodes=?, release_year=?, rating=?, genres=?, synopsis=?, official_by=?, encoder=?, published_by=?, content_status=?, is_pinned=?, is_featured=?, show_zip_section=?, seo_title=?, seo_description=?, published_at=?, updated_at=NOW() WHERE id=?');
        $sampleUpdate->execute([
          $sampleAnimeData[0], $sampleAnimeData[2], $sampleAnimeData[3], $sampleAnimeData[4], $sampleAnimeData[5], $sampleAnimeData[6], $sampleAnimeData[7], $sampleAnimeData[8], $sampleAnimeData[9], $sampleAnimeData[10], $sampleAnimeData[11], $sampleAnimeData[12], $sampleAnimeData[13], $sampleAnimeData[14], $sampleAnimeData[15], $sampleAnimeData[16], $sampleAnimeData[17], $sampleAnimeData[18], $sampleAnimeData[19], $sampleAnimeData[20], $sampleAnimeData[21], $sampleId
        ]);
      }
      if ($sampleId > 0) {
        $epFind = $pdo->prepare('SELECT id FROM episodes WHERE anime_id=? AND episode_number=1 LIMIT 1');
        $epFind->execute([$sampleId]);
        $sampleEpId = (int)$epFind->fetchColumn();
        if ($sampleEpId === 0) {
          $epDraftInsert = $pdo->prepare('INSERT INTO episodes(anime_id,title,episode_number,upload_date,notes,sort_order,is_active) VALUES(?,?,?,?,?,?,1)');
          $epDraftInsert->execute([$sampleId, 'Episode 01', 1, '2026-06-10', '', 1]);
          $sampleEpId = (int)$pdo->lastInsertId();
        } else {
          $pdo->prepare('UPDATE episodes SET title=?, upload_date=?, sort_order=?, is_active=1 WHERE id=?')->execute(['Episode 01', '2026-06-10', 1, $sampleEpId]);
        }
        $pdo->prepare('DELETE FROM episode_links WHERE episode_id=? AND host_name IN (?,?)')->execute([$sampleEpId, 'Internet Archive Player', 'Internet Archive MP4']);
        $sampleLinkInsert = $pdo->prepare('INSERT INTO episode_links(episode_id,quality,host_name,url,link_type,sort_order,is_active) VALUES(?,?,?,?,?,?,1)');
        $sampleLinkInsert->execute([$sampleEpId, '', 'Internet Archive Player', 'https://archive.org/embed/DefendersOfSpace', 'watch', 0]);
        $sampleLinkInsert->execute([$sampleEpId, 'MP4', 'Internet Archive MP4', 'https://archive.org/download/DefendersOfSpace/Defenders_of_space_512kb.mp4', 'download', 1]);

        // Movie sample keeps optional original/archive files hidden by default.
        $pdo->prepare('UPDATE anime SET show_zip_section=0 WHERE id=?')->execute([$sampleId]);
        $zipFind = $pdo->prepare('SELECT id FROM full_season_links WHERE anime_id=? AND host_name=? LIMIT 1');
        $zipFind->execute([$sampleId, 'Internet Archive']);
        if ((int)$zipFind->fetchColumn() === 0) {
          $sampleZipInsert = $pdo->prepare('INSERT INTO full_season_links(anime_id,pack_title,episode_range,quality,host_name,file_size,url,sort_order,notes,is_active) VALUES(?,?,?,?,?,?,?,?,?,1)');
          $sampleZipInsert->execute([$sampleId, 'Archive Download Folder', 'Optional Original Files', 'Archive Files', 'Internet Archive', '', 'https://archive.org/download/DefendersOfSpace', 1, 'Optional extra files; hidden by default from the movie page.']);
        }
      }
    } catch (Throwable $e) {}

    // Sidebar Featured Anime is a manual selection list. Seed it once from old "is_featured" posts only when it is empty.
    try {
      $featuredCount = (int)$pdo->query('SELECT COUNT(*) FROM sidebar_featured_anime')->fetchColumn();
      if ($featuredCount === 0) {
        $seedFeatured = $pdo->query('SELECT id FROM anime WHERE is_featured=1 ORDER BY is_pinned DESC, published_at DESC, id DESC LIMIT 8')->fetchAll(PDO::FETCH_COLUMN);
        $seedStmt = $pdo->prepare('INSERT IGNORE INTO sidebar_featured_anime(anime_id, sort_order, is_active) VALUES(?,?,1)');
        $order = 1;
        foreach ($seedFeatured as $fid) { $seedStmt->execute([(int)$fid, $order++]); }
      }
    } catch (Throwable $e) {}

    // Repair old local demo data: add a Watch Online sample link to sample episodes if it is missing.
    $sampleAnime = $pdo->prepare("SELECT id FROM anime WHERE slug='sample-hero-academy-season-1' LIMIT 1");
    $sampleAnime->execute();
    $sampleAid = (int)$sampleAnime->fetchColumn();
    if ($sampleAid > 0) {
      $sampleEpisodes = $pdo->prepare('SELECT id FROM episodes WHERE anime_id=? ORDER BY episode_number ASC, id ASC');
      $sampleEpisodes->execute([$sampleAid]);
      $watchInsert = $pdo->prepare('INSERT INTO episode_links(episode_id,quality,host_name,url,link_type,sort_order,is_active) VALUES(?,?,?,?,?,?,1)');
      $watchCountStmt = $pdo->prepare("SELECT COUNT(*) FROM episode_links WHERE episode_id=? AND link_type='watch'");
      foreach ($sampleEpisodes->fetchAll(PDO::FETCH_COLUMN) as $demoEpId) {
        $watchCountStmt->execute([(int)$demoEpId]);
        if ((int)$watchCountStmt->fetchColumn() === 0) {
          $watchInsert->execute([(int)$demoEpId,'','Online Player','https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4','watch',0]);
        }
      }
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS security_logs (id BIGINT AUTO_INCREMENT PRIMARY KEY, event_type VARCHAR(80) NOT NULL, detail VARCHAR(255) NULL, ip_hash CHAR(64) NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_security_logs_date (created_at), INDEX idx_security_logs_event (event_type)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (id BIGINT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) NULL, ip_hash CHAR(64) NULL, success TINYINT(1) DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_login_attempts_date (created_at), INDEX idx_login_attempts_ip (ip_hash)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    $pdo->exec("INSERT IGNORE INTO api_import_state(source_name,next_page,per_page) VALUES('anikoto',1,10)");
    $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
    if (!is_dir(__DIR__ . '/storage')) mkdir(__DIR__ . '/storage', 0755, true);
    @file_put_contents(INSTALL_LOCK_FILE, 'Installed at ' . date('c'));
    $ok=true; $message='Database installed/repaired successfully. Installer is now locked on live hosting for security.';
  } catch(Throwable $e) { $message='Install failed: '.$e->getMessage(); }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AnimeDubHindi Installer</title><style>body{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#eef6f7;color:#102033;margin:0}.box{max-width:980px;margin:40px auto;background:#fff;border:1px solid #dbe8e6;border-radius:20px;padding:34px;box-shadow:0 18px 50px rgba(17,34,56,.08)}h1{font-size:36px;margin:0 0 18px}.msg{padding:16px 18px;border-radius:14px;margin:22px 0;font-weight:800}.ok{background:#ecfdf5;color:#047857;border:1px solid #bbf7d0}.bad{background:#fff1f1;color:#b91c1c;border:1px solid #fecaca}.btn{border:0;background:#0e8f88;color:white;border-radius:12px;padding:14px 22px;font-weight:900;cursor:pointer}.links a{display:inline-block;margin:10px 12px 0 0;color:#0e8f88;font-weight:800}</style></head><body><div class="box"><h1>AnimeDubHindi Installer</h1><p>This will create/update the local database using your <b>config.php</b> settings.</p><ul><li>DB: <?= htmlspecialchars(DB_NAME) ?></li><li>User: <?= htmlspecialchars(DB_USER) ?></li><li>Host: <?= htmlspecialchars(DB_HOST) ?></li></ul><?php if($message): ?><div class="msg <?= $ok?'ok':'bad' ?>"><?= htmlspecialchars($message) ?></div><?php endif; ?><form method="post"><?= csrf_field() ?><button class="btn">Install / Repair Database</button></form><p><b>Default admin login:</b> admin / Admin@12345</p><div class="links"><a href="index.php">Open Website</a><a href="admin/">Open Admin Panel</a><a href="install-check.php">Run Install Check</a></div></div></body></html>
