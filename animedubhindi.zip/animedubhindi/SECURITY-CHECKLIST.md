# AnimeDubHindi Security Checklist

This package includes practical hardening for shared PHP/cPanel hosting:

- Hardened session cookies: HttpOnly, SameSite=Lax, strict session mode.
- Admin session regeneration after login.
- Admin session timeout.
- CSRF tokens on admin/public forms and destructive admin actions.
- Login attempt rate limiting.
- Public request/report spam throttling and honeypot field.
- Secure image upload validation: JPG/PNG/WEBP only, max 4MB, real image check.
- Safe external URL validation for redirects/watch/player links.
- Security headers via PHP and .htaccess.
- Directory listing disabled.
- Direct access blocked for config, database, includes, storage, SQL/backup files.
- PHP execution disabled inside uploads.
- Installer lock file created after install on live hosting.
- Security event logging table for important admin auth events.

Before going live:

1. Change `config.php` database credentials.
2. Run `install.php` once.
3. Change the default admin password immediately.
4. On live hosting, delete or rename `install.php` after installation for extra safety.
5. Use HTTPS/SSL.
6. Keep regular database and file backups.
7. Never paste unknown ad/chat scripts unless you trust the network.

No website can be guaranteed impossible to hack. This build applies strong practical protections for this project type.
