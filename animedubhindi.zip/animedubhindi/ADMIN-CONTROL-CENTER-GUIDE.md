# AnimeDubHindi Control Center Guide

The Control Center lets you manage the public website and admin behavior from one page.

## Main controls

- Website identity: site name, live URL, SEO description and brand icon.
- Public access: enable/disable Search, Request Anime, Broken Link Report and Contact pages.
- Header/community: smart header, search, Telegram strip, popup, Telegram and WhatsApp links.
- Homepage: section title, visible post count, Load More and card meta.
- Anime details: show/hide Synopsis, Info, Episodes, ZIP packs and Related Anime.
- Sidebar/ads: manual Featured Anime, channel box, Site Menu and Ad Control master switch.
- Footer: columns, community buttons and back-to-top button.
- Admin behavior: page size, session timeout and analytics retention.

Run `install.php` after uploading this package so new settings are created.


## Security Center
Use Admin → Security to check install lock, protected folders, upload hardening, failed login counts and recent security events.


## SEO Control
Use Admin → SEO Control to manage robots.txt, sitemap.xml, Google/Bing/Yandex/Naver verification, AI crawler access, IndexNow, schema, Open Graph and search submission checklist.


## Layout Control
Use Admin → Layout Control to reorder sidebar blocks like Featured Anime, Community Channels, Advertisement and Site Menu. Lower order number appears higher.
