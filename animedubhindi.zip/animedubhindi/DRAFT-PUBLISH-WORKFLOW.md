# Draft / Publish Workflow

This build includes a professional content workflow for AnimeDubHindi.

## Anime post states

- **Draft**: saved privately in the admin panel. It will not appear on the homepage, search, movies, series, genres, sitemap, or public related anime.
- **Published**: visible on the public website and included in SEO/sitemap output.
- **Unpublished**: hidden from the public website after previously being published.

## Admin controls

Go to:

`Admin → Anime Posts`

You can:

- Save a new anime as draft
- Preview the anime before publishing
- Publish the anime when ready
- Unpublish it anytime
- Re-publish it later
- Search posts by title, genre, language, anime status, or publish status

## Preview

Draft and unpublished posts can be previewed while logged in as admin using the **Preview** button. Public visitors cannot see preview pages.

## Episodes and ZIP links

Episodes, Watch Online links, Download links, and ZIP packs can be added before the anime is published. This lets you prepare the full page first and publish only when ready.

## SEO behavior

Only published anime posts are included in:

- Homepage latest releases
- Search suggestions
- Search results
- Movies/series/genre pages
- Related anime
- Sitemap
- Public featured sidebar

This prevents unfinished drafts from appearing on Google or the public website.
