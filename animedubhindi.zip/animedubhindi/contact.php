<?php
require_once __DIR__ . '/includes/functions.php';
if (!public_feature_enabled('public_contact_enabled','1')) render_public_closed_page('Contact Us', setting('contact_page_message','Contact messages are temporarily unavailable. Please use our community channels for urgent updates.'));
$page = basename(__FILE__, '.php');
$data = get_legal_page_data($page);
$heading = $data['title'];
$page_title = $heading . ' - ' . setting('site_name', 'AnimeDubHindi');
$layoutClass = has_sidebar() ? '' : ' no-sidebar';
require __DIR__ . '/includes/header.php';
?>
<main class="container main-wrap<?= e($layoutClass) ?>">
  <section class="content-card legal-page">
    <div class="breadcrumb"><a href="<?= e(url('index.php')) ?>">Home</a><span>›</span><b><?= e($heading) ?></b></div>
    <header class="legal-hero">
      <span class="legal-kicker">Information</span>
      <h1><?= e($heading) ?></h1>
      <p><?= e($data['intro'] ?? '') ?></p>
    </header>

    <div class="legal-updated">Last updated: <?= date('F j, Y') ?></div>

    <?php foreach (($data['sections'] ?? []) as $section): ?>
      <section class="legal-block">
        <h2><?= e($section['title'] ?? '') ?></h2>
        <?php if (!empty($section['body'])): ?>
          <?php foreach ($section['body'] as $paragraph): ?>
            <p><?= e($paragraph) ?></p>
          <?php endforeach; ?>
        <?php endif; ?>
        <?php if (!empty($section['list'])): ?>
          <ul class="legal-list">
            <?php foreach ($section['list'] as $item): ?>
              <li><?= e($item) ?></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
        <?php if (!empty($section['cta'])): ?>
          <div class="legal-actions clean-channel-actions">
            <a class="btn channel-action telegram" href="<?= e(setting('telegram_link','#')) ?>" target="_blank" rel="nofollow noopener"><img src="<?= e(asset('img/telegram-logo.svg')) ?>" alt="">Open Telegram</a>
            <a class="btn channel-action whatsapp" href="<?= e(setting('whatsapp_link','#')) ?>" target="_blank" rel="nofollow noopener"><img src="<?= e(asset('img/whatsapp-logo.svg')) ?>" alt="">Open WhatsApp</a>
            <a class="btn btn-light" href="<?= e(url('request.php')) ?>">Request Anime</a>
            <a class="btn btn-light" href="<?= e(url('report.php')) ?>">Report Broken Link</a>
          </div>
        <?php endif; ?>
      </section>
    <?php endforeach; ?>

    <div class="legal-note-box">
      <b>Note:</b> This page is written for transparency and site-use guidance. It is not a substitute for legal advice.
    </div>
  </section>
  <?php require __DIR__ . '/includes/sidebar.php'; ?>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
