# Admin Stability Fix

This release improves admin-panel usability and keeps the main website connected to the same database.

## Fixed

- Admin sidebar no longer jumps back to the top after opening lower menu items.
- Sidebar scroll position is remembered across admin pages.
- Admin page scroll position is remembered after save, hide/show, pin/unpin, delete, and form actions.
- Collapsed sidebar hover tooltip shows the menu name clearly outside the sidebar.
- `Site Settings` is renamed to `Advanced Settings` in the admin menu to avoid confusion with `Control Center`.
- Control Center remains the main quick-control page. Advanced Settings remains for detailed fine-tuning.

## Install

1. Replace the old `animedubhindi` folder.
2. Run `/install.php` once.
3. Hard refresh the browser with Ctrl + F5.
4. On live hosting, delete or rename `install.php` after setup.
