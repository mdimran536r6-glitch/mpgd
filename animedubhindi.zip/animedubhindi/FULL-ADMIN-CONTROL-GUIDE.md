# AnimeDubHindi Full Admin Control Guide

This release adds a practical Website Tools area for exports, cleanup, public page switches, content defaults and safe repair.

## Main control pages

- Control Center: quick controls for main website behavior.
- Advanced Settings: detailed site settings.
- Layout Control: sidebar order and share button position.
- Featured Anime: manual featured anime selection.
- Header Menus: main menu and submenu management.
- SEO Control: robots, sitemap, verification codes, analytics codes and index settings.
- Ad Control: ad/script placements.
- Website Tools: export, cleanup and safe repair tools.
- Security: login/session/security status.

## Recommended release steps

1. Run install.php once after upload.
2. Change admin password.
3. Set live URL in Control Center.
4. Add verification/analytics codes in SEO Control.
5. Set ads/scripts in Ad Control.
6. Arrange sidebar in Layout Control.
7. Delete or rename install.php on live hosting.
