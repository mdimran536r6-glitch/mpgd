<?php
require_once __DIR__ . '/includes/functions.php';
$genre = trim($_GET['genre'] ?? '');
$page_title = 'Genres - ' . setting('site_name', 'AnimeDubHindi');
$heading = $genre ? $genre . ' Anime' : 'Anime Genres'; $kicker = 'Browse by mood';
if ($genre) $anime = fetch_anime_list('genres LIKE ?', ['%' . $genre . '%'], 120); else $anime = fetch_anime_list('1', [], 120);
require __DIR__ . '/list-template.php';
