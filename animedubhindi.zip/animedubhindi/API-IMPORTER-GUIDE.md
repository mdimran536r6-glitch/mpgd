# AnimeDubHindi API Importer Guide

Admin path: `Admin -> API Importer`

## What it imports

The importer uses the existing website tables only:

- `anime`
- `episodes`
- `episode_links`
- `api_import_map` for deduplication/internal source tracking
- `api_import_state` for continuing later

Imported anime are saved as `draft`, so they do not show on the public website until you publish them.

## Selected source

### Anikoto API

Default base URL:

```text
http://anikotoapi.site
```

Used endpoints:

```text
GET /recent-anime?page=1&per_page=10
GET /series/{id}
```

The importer uses anime/list/detail data for the cover image. It does not take poster images from video episodes.

## Continue importing later

The importer saves the next page in:

```text
settings.api_import_anikoto_next_page
```

When you return later, click **Import Draft Anime** again and it will continue from the saved page.

## Deduplication

Duplicates are prevented by:

- `source_name + source_id`
- anime `slug`
- anime `title`

## Watch links

If the API returns `embed_url.sub` or `embed_url.dub`, those are saved as `Watch Online` links using the existing `episode_links` table with `link_type='watch'`.

## Downloads

This importer does not generate download links. Add downloads manually only when you have a reliable source.

## Risks

Unofficial anime APIs can stop working, change response structure, get rate limited, or become unavailable. Keep the imported posts as draft and check watch links before publishing.
