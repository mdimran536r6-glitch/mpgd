<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = setting('site_name', 'AnimeDubHindi') . ' - Latest Anime Updates';
$anime = fetch_anime_list('1', [], 240);
$initial_limit = max(12, min(30, (int)setting('latest_initial_limit', '18')));
$layoutClass = has_sidebar() ? '' : ' no-sidebar';
require __DIR__ . '/includes/header.php';
?>
<main class="container main-wrap<?= e($layoutClass) ?>">
  <?php if (ad_control_code('before_latest') !== ''): ?><section class="ad-control-site-slot ad-before-latest"><div class="ad-control-render"><?php render_ad_placement('before_latest'); ?></div></section><?php endif; ?>
  <section class="content-card releases-card">
    <div class="section-head compact-section-head">
      <div><div class="section-kicker"><?= e(setting('homepage_kicker','Fresh Updates')) ?></div><h1 class="section-title"><?= e(setting('homepage_title','Latest Releases')) ?></h1></div>
    </div>
    <?php if (!$anime): ?>
      <div class="empty-state">No anime posts are available right now. Please check back soon.</div>
    <?php else: ?>
    <div class="anime-grid">
      <?php foreach ($anime as $i => $item): ?>
      <article class="anime-card <?= $i >= $initial_limit ? 'hidden-card' : '' ?>">
        <a class="thumb" href="<?= e(anime_link($item)) ?>">
          <img src="<?= e(cover_url($item['cover_image'] ?? null)) ?>" alt="<?= e($item['title']) ?>">
          <?php if (!empty($item['is_pinned']) && setting('show_pinned_badge','1')==='1'): ?><span class="pin-badge">Pinned</span><?php endif; ?>
        </a>
        <div class="anime-card-body">
          <h2 class="anime-title"><a href="<?= e(anime_link($item)) ?>"><?= e($item['title']) ?></a></h2>
          <?php if (setting('card_meta_enabled','1')==='1'): ?><div class="meta-line"><?php if(setting('card_author_enabled','1')==='1'): ?>By <?= e($item['published_by'] ?: setting('site_name','AnimeDubHindi')) ?><?php endif; ?><?php if(setting('card_author_enabled','1')==='1' && setting('card_date_enabled','1')==='1'): ?> <span>/</span> <?php endif; ?><?php if(setting('card_date_enabled','1')==='1'): ?><?= e(date('M j, Y', strtotime($item['published_at'] ?? 'now'))) ?><?php endif; ?></div><?php endif; ?>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
    <?php if(setting('load_more_enabled','1')==='1'): ?><div class="load-more-wrap"><button class="btn btn-light" data-load-more><?= e(setting('load_more_label','Load More')) ?></button></div><?php endif; ?>
    <?php endif; ?>
  </section>
  <?php if (ad_control_code('after_latest') !== ''): ?><section class="ad-control-site-slot ad-after-latest"><div class="ad-control-render"><?php render_ad_placement('after_latest'); ?></div></section><?php endif; ?>
  <?php require __DIR__ . '/includes/sidebar.php'; ?>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
