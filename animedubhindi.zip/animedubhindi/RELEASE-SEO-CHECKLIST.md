# Release SEO Checklist

Before going live:

1. Upload files to public_html.
2. Run install.php once.
3. Open Admin → SEO Control.
4. Confirm Live Website URL is https://www.animedubhindi.xyz.
5. Open /robots.txt and /sitemap.xml.
6. Submit sitemap to Google Search Console and Bing Webmaster.
7. Paste Google/Bing verification codes in SEO Control.
8. Delete or rename install.php and install-check.php on live hosting.
9. Enable SSL/HTTPS.

Robots allows public pages and AI crawlers while blocking admin/private folders.
