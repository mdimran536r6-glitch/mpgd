# AnimeDubHindi Admin Controls Guide

This package includes a complete admin control system. After uploading the package, run `install.php` once to create/repair settings.

## Main admin controls

### Dashboard
- View total anime, episodes, links, ZIP packs, requests and reports.
- Search anime.
- Open edit or episode manager quickly.
- Paginated list so the page does not become too long.

### Anime Posts
- Add, edit, delete anime.
- Upload cover image.
- Add title, slug, synopsis, type, status, language, quality, genres, rating, release year, official by, encoder and SEO text.
- Pin anime so it appears first.
- Mark anime as featured for sidebar slider.
- Show/hide ZIP section per anime.

### Episode Links
- Search/select anime.
- Add/edit/hide/show episodes.
- Add Watch Online link.
- Add multiple download hosts for each quality.
- Add/edit/hide/show ZIP packs or split packs such as EP 01-06, EP 07-12, Full Season.

### Header Menus
- Add main menus.
- Add submenus.
- Disable menu items without deleting them.
- These links can also appear in the sidebar Site Menu box with copy buttons.

### Site Settings
- Brand name, icon and live site URL.
- Maintenance mode.
- Header search on/off.
- Smart header scroll behavior on/off.
- Telegram strip and popup on/off.
- Homepage title, small label, Load More, card author/date and pinned badge controls.
- Anime details page section controls: breadcrumb, meta, synopsis, info, episodes, ZIP packs and related anime.
- Sidebar controls: featured slider, WhatsApp/Telegram box, Site Menu, submenu and copy buttons.
- Advertisement controls: on/off, title, image, click URL, custom HTML and refresh seconds.
- Footer controls: about, quick links, support, legal, community buttons and back-to-top.
- Admin page-size controls for Dashboard, Anime Posts and Requests/Reports.
- Analytics enable/disable and data retention days.

### Analytics
- Clean summary boxes only.
- Filter by date range.
- Export summary.

### Requests & Reports
- Read visitor requests and broken link reports.
- Search messages.
- Pagination prevents long pages.

### Password
- Change default admin password after install.

## Recommended first setup
1. Run `install.php`.
2. Login to `/admin`.
3. Change password.
4. Set live website URL to `https://www.animedubhindi.xyz`.
5. Configure Telegram and WhatsApp links.
6. Update footer text and legal pages.
7. Add your real anime posts and remove demo entries when ready.


## SEO Control
Use Admin → SEO Control to manage robots.txt, sitemap.xml, Google/Bing/Yandex/Naver verification, AI crawler access, IndexNow, schema, Open Graph and search submission checklist.
