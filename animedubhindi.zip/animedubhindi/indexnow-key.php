<?php
require_once __DIR__ . '/includes/functions.php';
header('Content-Type: text/plain; charset=utf-8');
$key = preg_replace('/[^A-Za-z0-9_-]/', '', trim(seo_setting('seo_indexnow_key','')));
echo $key !== '' ? $key : 'indexnow-key-not-set';
