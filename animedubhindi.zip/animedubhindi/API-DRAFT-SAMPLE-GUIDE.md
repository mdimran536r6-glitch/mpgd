# Draft-only API/watch sample

This release adds one draft-only sample anime for testing the existing watch/download flow.

## Sample
- Title: Defenders of Space — Player Test
- Visibility: Draft
- Watch source: Internet Archive embed
- Download source: Internet Archive MP4/download directory

## Important
The sample is not public. It will not appear on the homepage, search, sitemap, featured sidebar, or public lists unless you publish it from Admin → Anime Posts.

## How to test
1. Run `install.php` → Install / Repair Database.
2. Open Admin → Anime Posts.
3. Search `Defenders of Space`.
4. Click Preview.
5. Open Episode 01 → Watch Online.

## Replace later
Admin → Episodes → choose this anime → edit the Watch Online and Download links.
