<?php
require_once __DIR__ . '/includes/functions.php';
$layoutClass = has_sidebar() ? '' : ' no-sidebar';
require __DIR__ . '/includes/header.php';
?>
<main class="container main-wrap<?= e($layoutClass) ?>">
  <section class="content-card releases-card">
    <div class="section-head"><div><div class="section-kicker"><?= e($kicker ?? 'Browse') ?></div><h1 class="section-title"><?= e($heading ?? 'Anime') ?></h1></div></div>
    <?php if (($kicker ?? '') === 'Search' && empty($_GET['q'])): ?>
      <form class="big-search" action="<?= e(url('search.php')) ?>" method="get"><input name="q" placeholder="Search by anime title, genre, language..."><button class="btn">Search</button></form>
    <?php endif; ?>
    <?php if (!$anime): ?><div class="empty-state">No posts found.</div><?php else: ?>
    <div class="anime-grid">
      <?php foreach ($anime as $i => $item): ?>
      <article class="anime-card <?= $i >= 18 ? 'hidden-card' : '' ?>">
        <a class="thumb" href="<?= e(anime_link($item)) ?>"><img src="<?= e(cover_url($item['cover_image'] ?? null)) ?>" alt="<?= e($item['title']) ?>"><?php if (!empty($item['is_pinned'])): ?><span class="pin-badge">Pinned</span><?php endif; ?></a>
        <div class="anime-card-body"><h2 class="anime-title"><a href="<?= e(anime_link($item)) ?>"><?= e($item['title']) ?></a></h2><div class="meta-line">By <?= e($item['published_by'] ?: 'Admin') ?> <span>/</span> <?= e(date('M j, Y', strtotime($item['published_at'] ?? 'now'))) ?></div><div class="tag-row"><span class="tag"><?= e($item['type'] ?: 'Series') ?></span><span class="tag soft"><?= e($item['language'] ?: 'Hindi Dubbed') ?></span></div></div>
      </article>
      <?php endforeach; ?>
    </div>
    <div class="load-more-wrap"><button class="btn btn-light" data-load-more>Load More</button><p class="load-note">Click to show more posts.</p></div>
    <?php endif; ?>
  </section>
  <?php require __DIR__ . '/includes/sidebar.php'; ?>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
