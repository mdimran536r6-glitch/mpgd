<?php
// animedubhindi - shared configuration
// Local XAMPP default: user root, empty password. Change these on live hosting.

define('DB_HOST', 'localhost');
define('DB_NAME', 'animedubhindi_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'animedubhindi');
define('APP_VERSION', '4.0-superfinal');

define('BASE_PATH', __DIR__);
define('UPLOAD_DIR', BASE_PATH . '/uploads/covers/');
define('UPLOAD_URL', 'uploads/covers/');

// Hide PHP notices/warnings from visitors. Fatal errors should still be checked in logs.
error_reporting(E_ALL);
ini_set('display_errors', '0');

// ---- Security hardening ----
ini_set('expose_php', '0');
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_samesite', 'Lax');

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
if (session_status() === PHP_SESSION_NONE) {
    session_name('ADHSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

if (empty($_SESSION['_initiated'])) {
    session_regenerate_id(true);
    $_SESSION['_initiated'] = time();
}

if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header('X-Permitted-Cross-Domain-Policies: none');
    if ($isHttps) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

