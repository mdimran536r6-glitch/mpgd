# Security checked release

This package has been checked for PHP syntax and includes practical hardening for a PHP/MySQL cPanel-style website.

## Included protections

- Admin authentication and session regeneration.
- Stronger admin-only security headers and noindex policy.
- CSRF protection on admin forms/actions and public request/report forms.
- Login rate limiting and login/security audit logs.
- Strong admin password policy.
- Default password warning after login.
- Upload validation for cover images only: JPG, PNG, WEBP.
- PHP/script execution blocked in uploads.
- Direct access blocked for includes, database and storage folders.
- Directory listing disabled.
- Sensitive file extensions blocked.
- Installer lock after install.
- Public analytics avoids raw IP and raw user-agent storage in the tracking function.

## Must-do after uploading live

1. Run `install.php` once.
2. Change the default admin password immediately.
3. Delete or rename `install.php` and `install-check.php`.
4. Enable HTTPS/SSL.
5. Use a strong database password.
6. Keep regular backups.

No website can be guaranteed 100% unhackable, but these controls reduce the common risks for shared PHP hosting.
