<?php
require_once __DIR__ . '/includes/functions.php';
if (!public_feature_enabled('public_search_enabled','1')) render_public_closed_page('Search', 'Search is temporarily disabled. Please browse the latest releases from the homepage.');
$q = trim($_GET['q'] ?? '');
$page_title = 'Search - ' . setting('site_name', 'AnimeDubHindi');
$heading = $q ? 'Search results for: ' . $q : 'Search Anime'; $kicker = 'Search';
if ($q) $anime = fetch_anime_list('(title LIKE ? OR genres LIKE ? OR language LIKE ? OR synopsis LIKE ?)', array_fill(0,4,'%' . $q . '%'), 120); else $anime = [];
require __DIR__ . '/list-template.php';
