# Movie Links + Admin Accordion Update

This update keeps the existing website design and only improves behavior:

- Movie type posts show a Movie Links section instead of Episode Links.
- Movie posts can still use the existing episode/link database internally, but the public page labels it as Movie.
- Watch Online and Download buttons work from the existing player/link system.
- Optional ZIP/original file packs stay hidden unless the admin enables the ZIP/Pack section.
- Anime Posts in the admin panel now use a professional collapsed accordion with arrow controls.
- The admin can open only the anime row they want to manage, then use Preview, Edit, Episodes/Movie Links, Pin, Publish, Unpublish, or Delete.

No layout redesign was made.
