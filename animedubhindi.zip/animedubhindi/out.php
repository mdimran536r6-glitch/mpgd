<?php
require_once __DIR__ . '/includes/functions.php';
$type = strtolower(trim($_GET['type'] ?? 'episode'));
$id = (int)($_GET['id'] ?? 0);
$url = '';
$title = '';
$animeId = null; $episodeId = null; $linkId = null; $zipId = null;
try {
    if ($type === 'zip') {
        $stmt = db()->prepare('SELECT z.*, a.title AS anime_title, a.id AS anime_id FROM full_season_links z JOIN anime a ON a.id=z.anime_id WHERE z.id=? AND z.is_active=1 LIMIT 1');
        $stmt->execute([$id]); $row = $stmt->fetch();
        if ($row) { $url = (string)$row['url']; $title = ($row['anime_title'] ?? '').' - '.($row['pack_title'] ?? 'ZIP Pack'); $animeId=(int)$row['anime_id']; $zipId=(int)$row['id']; }
        track_event('zip_click', ['anime_id'=>$animeId, 'zip_id'=>$zipId, 'title'=>$title, 'page_url'=>$_SERVER['REQUEST_URI'] ?? '', 'extra'=>['host'=>$row['host_name'] ?? '', 'quality'=>$row['quality'] ?? '']]);
    } else {
        $stmt = db()->prepare('SELECT l.*, e.anime_id, e.id AS episode_id, e.episode_number, a.title AS anime_title FROM episode_links l JOIN episodes e ON e.id=l.episode_id JOIN anime a ON a.id=e.anime_id WHERE l.id=? AND l.is_active=1 AND e.is_active=1 LIMIT 1');
        $stmt->execute([$id]); $row = $stmt->fetch();
        if ($row) { $url = (string)$row['url']; $title = ($row['anime_title'] ?? '').' Episode '.($row['episode_number'] ?? '').' - '.($row['host_name'] ?? 'Download'); $animeId=(int)$row['anime_id']; $episodeId=(int)$row['episode_id']; $linkId=(int)$row['id']; }
        track_event('download_click', ['anime_id'=>$animeId, 'episode_id'=>$episodeId, 'link_id'=>$linkId, 'title'=>$title, 'page_url'=>$_SERVER['REQUEST_URI'] ?? '', 'extra'=>['host'=>$row['host_name'] ?? '', 'quality'=>$row['quality'] ?? '']]);
    }
} catch (Throwable $e) { }
$url = safe_external_url($url);
if ($url === '' || $url === '#') {
    $page_title = 'Link unavailable';
    require __DIR__ . '/includes/header.php';
    echo '<main class="container main-wrap no-sidebar"><section class="content-card"><div class="empty-state">This link is not available right now.</div><p><a class="btn btn-light" href="javascript:history.back()">Go back</a></p></section></main>';
    require __DIR__ . '/includes/footer.php';
    exit;
}
header('Location: ' . $url, true, 302);
exit;
